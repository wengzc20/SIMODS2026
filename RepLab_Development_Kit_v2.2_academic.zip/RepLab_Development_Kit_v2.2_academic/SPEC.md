# Compatibility note

The earlier generic workbench specification has been superseded by RepLab Development Kit v2.1.

Read in order:
- `STORY_EXPERIENCE_SPEC.md`
- `PRODUCT_SPEC.md`
- `UI_INTERACTION_SPEC.md`
- `RUN_COMPARE_SPEC.md`
- `TECH_ARCHITECTURE.md`
- `API_CONTRACT.md`
- `DATA_GUIDE.md`
- `AGENT_DESIGN.md`
- `TASKS_2W.md`
- `TEST_PLAN.md`
