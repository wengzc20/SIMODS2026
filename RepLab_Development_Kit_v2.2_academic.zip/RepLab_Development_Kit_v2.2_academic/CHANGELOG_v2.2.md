# Changelog v2.2

- Locked the two-week interface to an experiment-workbench layout.
- Added explicit source badges: PAPER AGGREGATE, LIVE COMPUTED, PUBLIC DATA SUMMARY.
- Added `data/source_registry.json`.
- Prohibited fabricated APPLIES entity scatter/rank-list/rank-link visualizations.
- Locked Paper Evidence vs Live Stress UI states.
- Added A/B run compare and provenance placement rules to visual contract.
- Added source provenance fields to experiment API responses.
- Added visual/data-honesty tests.
- Bundled two 1600x900 UI reference screenshots and their HTML sources.
