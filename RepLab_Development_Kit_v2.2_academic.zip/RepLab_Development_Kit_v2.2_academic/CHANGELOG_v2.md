# v2.0 changes from Codex Starter v1.0

- Home page changed from Paper Overview to interactive Experiment Workspace.
- Product navigation simplified; paper overview is secondary.
- Parameter adjustment is a first-class requirement.
- Information-density limits added.
- Central canvas reduced to maximum two dominant plots.
- Left parameter rail uses accordions.
- Right panel is Evidence & Review, not a general dashboard summary.
- Bottom strip is a diagnostic-stage navigator, not a playback/sprint timeline.
- Added configuration availability rules to prevent mixing evidence across relations/orders.
- Development package made tool-agnostic; Codex-specific start file removed from source-of-truth chain.
- Multi-agent layer retained but moved behind deterministic experiment evidence.
