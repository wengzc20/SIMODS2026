# RepLab v2.1 Test Plan

## Scientific regression P0
- APPLIES full: N=675, active=52, common minimum=623, global ρ=0.999412.
- APPLIES active ρ=0.715480.
- APPLIES inversion=17.41%; Top-K locks 0.222/0.375/0.515.
- APPLIES semantics totals P2=9219, S2=8727, M2=492.
- PROVIDES and UNION relation sensitivity values match the paper lock.
- APPLIES q3/q4 active sensitivity matches the paper lock.
- Frozen null p=0.1055 and quantiles match lock.
- MovieLens and DBLP summaries match lock.

## Story P0
- `/story/missions` loads 7 grounded cases.
- Case presets never create unsupported relation/q combinations.
- Guided mode may de-emphasize evidence but never invent or mutate values.
- Free Lab can access supported evidence without story gating.

## Run/Compare P0
- every run has unique run_id and timestamp;
- source_kind is correct;
- Pin A survives current-run changes;
- diff identifies exact changed parameters;
- multiple-condition comparison shows warning;
- localStorage keeps ≤20 snapshots.

## Data-honesty P0
- no APPLIES row-level vectors in package;
- no fake APPLIES scatter/rank links;
- no fake null histogram when samples unavailable;
- no Top-K/inversion fixed-margin null claim;
- DBLP marked active-only;
- MovieLens windows marked exploratory transferability.

## Reviewer P0
Blocked claims include:
- global ρ≈1 proves redundancy;
- recorded zero proves structural absence;
- p>0.05 proves no higher-order mechanism;
- null audit tests common-minimum effect;
- external evidence is universal validation;
- larger q is inherently better.

## Backend commands
```bash
cd backend
python -m pytest -q
```

## Data validation
```bash
python scripts/validate_data.py
```

## Frontend commands
```bash
cd web
npm install
npm run lint
npm run build
```

## Visual acceptance
At 1600×900:
- no more than 4 KPI cards;
- dominant chart visually larger than secondary panel;
- right rail does not dominate screen;
- run tray visibly communicates experimentation;
- no sprint/development information appears in UI.


## v2.2 UI/data-honesty tests
- APPLIES Paper Evidence page contains visible `PAPER AGGREGATE` label.
- APPLIES Paper Evidence does not render a company-level scatter, company name list, or rank-link chart.
- Stress mode contains visible `LIVE COMPUTED` label and hard non-reconstruction disclaimer.
- Null paper view uses interval/quantiles unless retained samples are actually supplied.
- z control is unavailable in Paper Evidence and active in Public Stress Test.
