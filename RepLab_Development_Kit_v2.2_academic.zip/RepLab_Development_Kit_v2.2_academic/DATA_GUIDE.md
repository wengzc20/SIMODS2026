# RepLab Data Guide v2.1

## 1. Source-of-truth lock
`data/paper_numbers.lock.json`

Source manuscript:
`JSSC_ManuScript_20260813(2).docx`

The lock contains only manuscript-disclosed aggregate/public values.

## 2. Guided story
`data/story_missions.json`

This file defines UX sequence only. It must not become a second statistics database.

## 3. Public synthetic data
Used for interactive deterministic calculations:
- `seed/entities.csv`
- `seed/contexts.csv`
- `seed/affiliations.csv`
- `seed/reversed_active_ranks.csv`
- expected metric/padding files

These may be used for actual charts/rank links because they are included in the package.

## 4. Shipbuilding confidentiality boundary
Never infer or synthesize:
- 52-company APPLIES active vectors
- company identities
- raw incidence edges
- enterprise-specific schema

The paper companion may display manuscript aggregate values only.

## 5. Null-model boundary
The lock contains summary information for the frozen APPLIES q=2 active-Spearman audit.

If retained `C_r` samples are not shipped in this dev kit, use:
- central quantile band
- observed marker
- null mean
- p-value
- ESS / Rhat / chain counts

Do not draw a fabricated histogram.

Do not imply that Top-K or inversion has a frozen null distribution.

## 6. External evidence
MovieLens:
- all ratings
- 1997 Q4
- 1998 Q1

DBLP:
- active-only population by construction

These are manuscript-grounded scenario summaries in the two-week package. Full raw public-data reproduction can remain a later/reproducibility route.


## v2.2 source classes
Read `DATA_SOURCE_POLICY_v2.2.md` and `data/source_registry.json`. `paper_aggregate` is display-only aggregate evidence; `live_computed` is recomputed from synthetic/public seed inputs. Never silently convert one source class into another.
