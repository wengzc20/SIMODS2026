# Development Start — v2.1

## First read
- `STORY_EXPERIENCE_SPEC.md`
- `PRODUCT_SPEC.md`
- `UI_INTERACTION_SPEC.md`
- `RUN_COMPARE_SPEC.md`
- `TECH_ARCHITECTURE.md`

## First implementation target
Make `/` feel like a scientific debugging bench:

1. Guided Case / Free Lab switch.
2. RunSnapshot history tray.
3. Pin A / Compare B.
4. Case 01 → Case 02 APPLIES full vs active.
5. Only after that, add the stress-test curve and later cases.

Do not begin by building a paper overview page.

## Scientific baseline
Never modify `data/paper_numbers.lock.json` without an intentional manuscript evidence re-lock.

Use `data/story_missions.json` for guided UX metadata; do not duplicate statistics into the story file.

## Backend baseline
```bash
cd backend
python -m pytest -q
```

## Data baseline
```bash
python scripts/validate_data.py
```

## Frontend baseline
```bash
cd web
npm install
npm run lint
npm run build
```

## Suggested first coding prompt
```
Read STORY_EXPERIENCE_SPEC.md, PRODUCT_SPEC.md, UI_INTERACTION_SPEC.md,
RUN_COMPARE_SPEC.md, DATA_GUIDE.md, and AGENTS.md.

Implement the v2.1 home workspace in this order:
1. Guided/Free mode switch,
2. story mission banner loaded from /api/v1/story/missions,
3. APPLIES Case 01/02 controls,
4. RunSnapshot tray in localStorage,
5. Pin A / Compare B parameter diff.

Do not create any row-level APPLIES data or fake null distribution.
Run backend tests and frontend build after changes.
```
