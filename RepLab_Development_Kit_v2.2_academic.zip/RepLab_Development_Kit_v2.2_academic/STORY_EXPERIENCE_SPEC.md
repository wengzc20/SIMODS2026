# RepLab Two-Week Story Experience Specification v2.1

## 1. Why the two-week version needs a story

The manuscript is not a sequence of unrelated metrics. It has a clear scientific reversal:

1. a nearly perfect global Spearman value (`0.999412`) appears to support redundancy;
2. the population audit reveals that 623 of 675 companies form a recorded-zero common-minimum block;
3. conditioning on the 52 APPLIES-active companies reduces Spearman to `0.715480`;
4. decision evidence still differs (`17.41%` strict inversions; top-10 Jaccard `0.375`);
5. semantic evidence distinguishes degree, provenance-counted participation, and deduplicated participation;
6. the fixed-margin null audit gives approximate two-sided Monte Carlo `p=0.1055`, which blocks a stronger claim that APPLIES contains exceptional higher-order organization;
7. MovieLens and DBLP then show why population construction matters for transferability.

The product should let the user *discover* this logic by changing experimental conditions, not merely read the final numbers.

## 2. Two modes, one instrument

The home workspace has a mode switch:

- **研究案例 / Guided Case** — default. A manuscript-grounded scientific story with suggested next experiments and progressive disclosure.
- **自由实验 / Free Lab** — all supported controls are available immediately.

Both modes use exactly the same deterministic APIs, evidence records, data locks, charts, and export format. Guided Case is only a declarative layer over the experiment workbench. This preserves long-term compatibility with Network Editor, Theorem Lab, and Research Arena.

## 3. Guided research case: “0.999 能证明什么？”

The guided experience is a seven-part research case. It is not a gamified level system and does not hide the fact that some values are manuscript aggregates.

### Case 1 — 可疑的 0.999
**Question**: `Across 675 companies, ρ = 0.999412. Can k and P2 be treated as interchangeable?`

Default configuration:
- dataset: Shipbuilding
- relation: APPLIES
- q: 2
- population: full
- Top-K: 10
- null: off

Initially emphasize:
- global Spearman 0.999412
- universe N = 675

Do not foreground the active-set result until the user opens Coverage or changes the population.

User action:
- record a provisional claim: `可以替代 / 不可以替代 / 证据不足`;
- inspect Coverage.

Scientific point:
- a global coefficient is one observation, not a redundancy verdict.

### Case 2 — 623 个共同最小值
**Question**: `Who is contributing to the global statistic?`

Reveal:
- active N = 52
- common-minimum N = 623
- common-minimum share = 92.30%

Suggested experiment:
- change population from `full` to `active`;
- run again;
- compare Run A vs Run B.

Expected comparison:
- full/global Spearman = 0.999412
- active Spearman = 0.715480
- active facts are not recomputed by deleting or reordering the active nodes; the estimand/population changes.

Scientific point:
- recorded zero under APPLIES is not verified structural absence outside the focal observed relation layer.

### Case 3 — 只改变覆盖，不改变活跃排序
**Question**: `Can the global rank statistic change while the active ordering is held fixed?`

Switch to the public theorem stress-test dataset. Never imply that the confidential 52-company vectors are reconstructed.

Controls:
- scenario: `micro` or `perfectly reversed`
- common-minimum count z: 0–1000
- Run / Auto-run allowed for this cheap deterministic calculation

Visual requirement:
- primary: `z → global Spearman` curve
- secondary: active rank-link plot that does not move when z changes
- invariant badge: `Active ordering changed: NO`

Scientific point:
- this is the manuscript’s counterfactual padding construction: an analytical interpretation device, not a simulated missing-data experiment.

### Case 4 — 如果我要选 Top-K 呢？
**Question**: `Would a ranking-based decision remain the same?`

Return to APPLIES q=2 and active evidence.

Controls:
- K = 5 / 10 / 20

Show:
- strict inversion rate = 17.41%
- top-5 Jaccard = 0.222
- top-10 Jaccard = 0.375
- top-20 Jaccard = 0.515

Scientific point:
- decision-level summaries answer a different question from global association;
- these observed decision metrics do not have retained fixed-margin null distributions in the frozen rerun.

### Case 5 — 换关系、换阶数，现象还在吗？
**Question**: `Is the discrepancy unique to APPLIES q=2?`

Make the workbench feel like parameter debugging.

Parameter experiments:
- relation: APPLIES → PROVIDES → UNION
- q: 2 → 3 → 4 for APPLIES active-set sensitivity

Expected manuscript-supported values:
- PROVIDES: global 0.9627, active 0.5987, inversion 18.62%
- UNION: global 0.9767, active 0.7259, inversion 15.08%
- APPLIES q3: active 0.6558, inversion 20.82%
- APPLIES q4: active 0.6373, inversion 21.50%

Scientific point:
- this is sensitivity evidence under distinct relation semantics and orders;
- it does not establish that larger q is better or that APPLIES/PROVIDES/UNION are semantically equivalent.

### Case 6 — 不同，不等于“异常”
**Question**: `Does active-set disagreement imply exceptional higher-order organization?`

Enable the APPLIES q=2 fixed-margin null layer.

Show:
- observed active Spearman = 0.7154799251
- pooled sampled-null mean = 0.5709541982
- central sampled 95% interval = [0.3765862222, 0.7287877984]
- retained graphs = 4000 across 4 chains
- approximate plus-one two-sided Monte Carlo p = 0.1055
- split-Rhat = 1.0
- minimum per-chain ESS for Spearman = 525.6299

Reviewer must block:
- `p > 0.05 proves no higher-order mechanism exists.`
- `The degree margins completely determine the network.`
- `The null audit tests the common-minimum effect.`

Scientific point:
- the null audit addresses robustness relative to preserved first-order margins; it is a different question from the deterministic coverage mechanism.

### Epilogue — 总体是估计对象的一部分
**Question**: `Does the diagnostic logic transfer when population construction changes?`

Compare:
- MovieLens all ratings: 943/943 active, global=active Spearman 0.9378
- MovieLens 1997 Q4: 498/943 active, global 0.9872 vs active 0.9219
- MovieLens 1998 Q1: 471/943 active, global 0.9844 vs active 0.8903
- DBLP: active-only by construction, Spearman 0.620725; no natural common-minimum coverage replication

Scientific point:
- external cases are bounded transferability checks, not universal validation.

## 4. Final scientific judgment

At the end, the user writes or selects a one-sentence conclusion. The reviewer maps it to evidence.

Recommended manuscript-faithful verdict:

> High global agreement in the APPLIES full population is strongly affected by a large common-minimum block; active-set and decision-level differences remain, while the selected fixed-margin null audit does not provide compelling evidence that the observed active association is exceptional beyond preserved margins.

The product must not reduce this to a binary “higher-order wins / degree wins” verdict.

## 5. Experiment-debugging feel

### 5.1 Dirty → Run → Snapshot
Every parameter edit sets the workspace to `dirty`. Nothing except cheap stress-test calculations should silently recompute.

The Run action creates a **RunSnapshot** with:
- run_id
- timestamp
- config
- changed parameters relative to the pinned baseline
- metrics
- availability
- evidence IDs
- source version
- interpretation boundaries

### 5.2 Pin A / Compare B
The user can pin any successful run as A. The next run becomes B.

The center canvas shows a compact `What changed?` diff:
- Population: full → active
- Relation: APPLIES → PROVIDES
- q: 2 → 4
- Top-K: 10 → 20
- Null: off → on

Then show only metrics whose comparison is scientifically meaningful.

### 5.3 Run tray
The bottom of the workspace is a horizontal experiment tray, not a sprint timeline.

Each run chip shows:
- `R01`
- dataset/relation/q
- population
- one headline result
- source type: `paper aggregate` / `public deterministic`

Actions:
- Pin as A
- Restore config
- Export JSON
- Open evidence

### 5.4 Guided suggestion
In Guided Case, a `Suggested next probe` card tells the user which single parameter to change next. It does not change the parameter automatically.

Example:
> You have only inspected the full population. Change Population to Active and run again. Keep relation=APPLIES and q=2 fixed.

This makes the product feel like debugging a scientific claim rather than reading a tutorial.

## 6. Progressive disclosure rules

Guided Case can delay emphasis but must never falsify availability.
- Case 1 may visually de-emphasize active-set evidence, but Free Lab can access it immediately.
- Case 2 reveals the coverage composition and prompts population conditioning.
- Null results are not shown as the explanation for Case 1; they answer a later structural-robustness question.
- External data are an epilogue/contrast, not proof of universal prevalence.

## 7. Relationship to the manuscript’s five layers

The official diagnostic layers remain visible as scientific tags on each evidence record:
- Coverage
- Active Association
- Decision
- Semantics
- Robustness

The guided story is a user-experience layer. It does not replace or reorder the scientific definitions in the manuscript.

## 8. Long-term compatibility

All guided-story behavior is stored as declarative metadata (`story_missions.json`). Future features reuse existing contracts:
- Network Editor outputs a graph snapshot that becomes an ExperimentConfig input.
- Theorem Lab outputs deterministic EvidenceRecords and RunSnapshots.
- Research Arena consumes the same evidence IDs and run history.
- A future MCP provider can expose tools without changing RunSnapshot.
- A future A2A gateway can exchange AgentFinding/Artifact objects without changing the experiment core.
