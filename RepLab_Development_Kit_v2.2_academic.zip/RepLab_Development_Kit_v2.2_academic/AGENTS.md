# Repository development rules — RepLab v2.1

These rules apply to humans and AI coding assistants.

1. `data/paper_numbers.lock.json` is the manuscript evidence lock. Do not edit it unless an intentional re-lock is requested.
2. `data/story_missions.json` controls guided UX only. Do not use it as a second statistics database.
3. Do not invent confidential APPLIES row-level data, entity names, scatter points, rankings, incidence edges, or null realizations.
4. Deterministic math/statistics belong in `backend/app/core`; agents interpret EvidenceRecords and do not calculate manuscript facts from memory.
5. The home screen is a story-driven Experiment Workspace, not a paper overview dashboard.
6. The default story must preserve the manuscript logic: coverage mechanism, active/decision differences, semantics, fixed-margin robustness, bounded external transferability.
7. Pin A / Compare B must explicitly show which scientific parameters changed. If multiple dimensions changed, warn against isolated causal interpretation.
8. Unsupported dataset/relation/q combinations must be disabled or rejected. Never substitute evidence from another case.
9. APPLIES q=2 frozen null evidence applies to active-set Spearman only. Do not fabricate decision-level null distributions.
10. Counterfactual common-minimum padding is a deterministic analytical construction, not a missing-data simulation.
11. Keep UI density low-to-medium: at most four headline KPIs and two large panels in the first viewport.
12. Do not place sprint plans, engineering progress, token counters, model marketing, or agent-count vanity metrics in the product UI.
13. Future MCP/A2A integration must remain outside core scientific types. Do not bind ExperimentConfig/RunSnapshot/EvidenceRecord to a vendor protocol.
14. Run scientific regression tests after any change to data, metrics, availability rules, or API contracts.


## v2.2 UI/data-source hard rule
Before changing the workbench UI, read `UI_FINAL_LOCK_v2.2.md` and `DATA_SOURCE_POLICY_v2.2.md`. Do not invent entity-level APPLIES visuals from aggregate numbers.
