# RepLab Technical Architecture v2.1

## 1. Stack

Two-week build keeps the existing stack:

Frontend:
- Next.js 16
- React 19
- TypeScript
- Tailwind CSS v4
- Recharts

Backend:
- Python 3.12+
- FastAPI
- Pydantic
- deterministic scientific core under `backend/app/core`

Agent layer:
- mock reviewer required
- OpenAI Agents SDK optional for live reviewer / later specialist orchestration

Persistence:
- manuscript/public data: JSON/CSV files
- two-week experiment history: browser localStorage
- no database required

## 2. Architectural principle

```text
Scientific data / public synthetic vectors
                ↓
       Deterministic Python Core
                ↓
           EvidenceRecord
                ↓
          Experiment Run
                ↓
           RunSnapshot
          ↙            ↘
   Story UX / Compare   Reviewer
```

Story UX and Reviewer are consumers of evidence. Neither is a numerical source of truth.

## 3. Story layer

`data/story_missions.json` is declarative.

It contains:
- title/question
- preset config
- suggested next probe
- evidence emphasis
- scientific layer tags

It does not duplicate paper statistics.

This is important for future evolution: the story can change without touching scientific code.

## 4. RunSnapshot as continuity contract

RunSnapshot becomes the bridge across product generations.

Two-week companion:
- created by paper/synthetic experiments
- stored in localStorage

Future Network Editor:
- graph snapshot → ExperimentConfig → RunSnapshot

Future Theorem Lab:
- active vectors/assumptions → deterministic RunSnapshot

Future Research Arena:
- specialist agents consume RunSnapshots/EvidenceRecords and produce AgentFindings

Future Research Notebook:
- persists RunSnapshots and claims server-side

## 5. Advanced interoperability roadmap

Do not add MCP/A2A to the two-week implementation.

Keep adapter boundaries:

```python
class ToolProvider(Protocol):
    async def list_tools(self): ...
    async def call_tool(self, name, arguments): ...

class AgentPeer(Protocol):
    async def discover(self): ...
    async def submit_task(self, task): ...
    async def get_task(self, task_id): ...
```

Current:
- LocalToolProvider
- LocalAgentPeer

Future only when there is a real interoperability need:
- MCPToolProvider
- A2AAgentPeer

Core scientific types must not depend on an SDK-specific message format.

## 6. Data honesty

Shipbuilding:
- only manuscript-disclosed aggregates in the development package
- no row-level APPLIES vectors
- no company identifiers
- no enterprise-specific schema

Therefore:
- no fake APPLIES scatter
- no fake entity rank links
- no synthetic null histogram presented as empirical

Stress tests:
- clearly public/synthetic

## 7. Performance expectations

- locked paper run: <150 ms backend target
- public padding run: <100 ms target
- frontend state update: immediate
- live reviewer is asynchronous and must never block deterministic evidence display

## 8. Failure behavior

If live reviewer fails:
- preserve completed RunSnapshot
- show reviewer unavailable
- do not discard scientific output

If unsupported parameter combination is requested:
- 422 with explicit reason
- frontend keeps last successful run visible
