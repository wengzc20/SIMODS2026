from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import os
from .config import AGENT_MODE
from .models import PaddingRequest, ReviewRequest, ExperimentRequest
from .services.data_service import paper_overview, diagnostic_bundle, padding_demo, paper_lock, workbench_options, experiment_run, story_spec
from .agents.review_service import run_mock, run_live

app=FastAPI(title="RepLab API",version="0.1.0")
# 跨域放行来源：部署到新机器时用环境变量 CORS_ORIGINS 覆盖（逗号分隔）。
# 默认向后兼容本地 localhost:3000/3100；127.0.0.1 变体一并放行，避免「页面用 localhost、接口用 127.0.0.1」时被拦。
_cors_raw = os.getenv("CORS_ORIGINS", "http://localhost:3000,http://localhost:3100,http://127.0.0.1:3000,http://127.0.0.1:3100")
_allow_origins = [o.strip() for o in _cors_raw.split(",") if o.strip()]
app.add_middleware(CORSMiddleware, allow_origins=_allow_origins, allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

@app.get("/api/v1/health")
def health():
    return {"status":"ok","agent_mode":AGENT_MODE,"agent_live_available":bool(os.getenv("OPENAI_API_KEY")),"paper_lock":paper_lock()["lock_version"]}


@app.get("/api/v1/workbench/options")
def options(): return workbench_options()

@app.get("/api/v1/story/missions")
def story_missions(): return story_spec()

@app.post("/api/v1/experiment/run")
def run_experiment(req:ExperimentRequest):
    try: return experiment_run(req)
    except KeyError as e: raise HTTPException(422,str(e))

@app.get("/api/v1/paper/overview")
def overview(): return paper_overview()

@app.get("/api/v1/diagnostics/shipbuilding-applies-q2")
def diagnostics(): return diagnostic_bundle()

@app.post("/api/v1/lab/padding")
def lab_padding(req:PaddingRequest):
    try: return padding_demo(req.mode,req.z)
    except KeyError: raise HTTPException(404,"Unknown padding mode")

@app.get("/api/v1/paper/cases/{case_id}")
def paper_case(case_id:str):
    p=paper_lock()
    if case_id=="shipbuilding_applies_q2": return p["shipbuilding_applies_q2"]
    mapping={"movielens_all":"all_ratings","movielens_1997_q4":"1997_Q4","movielens_1998_q1":"1998_Q1"}
    if case_id in mapping: return p["movielens"][mapping[case_id]]
    if case_id=="dblp_active_only": return p["dblp"]
    raise HTTPException(404,"Unknown case_id")

@app.post("/api/v1/review/run")
async def review(req:ReviewRequest):
    if req.mode=="mock": return await run_mock(req.question)
    if not os.getenv("OPENAI_API_KEY"):
        raise HTTPException(503,"Live agent mode requires OPENAI_API_KEY")
    try: return await run_live(req.question,manager=req.mode=="manager")
    except ImportError:
        raise HTTPException(503,"Install backend with the agents extra to enable live mode")
