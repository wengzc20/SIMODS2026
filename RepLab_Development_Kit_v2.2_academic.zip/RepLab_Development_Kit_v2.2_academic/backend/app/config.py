from pathlib import Path
import os

REPO_ROOT = Path(__file__).resolve().parents[2]
DATA_ROOT = REPO_ROOT / "data"
PAPER_LOCK_PATH = DATA_ROOT / "paper_numbers.lock.json"
SEED_ROOT = DATA_ROOT / "seed"
FIXTURE_ROOT = DATA_ROOT / "fixtures"
STORY_PATH = DATA_ROOT / "story_missions.json"
AGENT_MODE = os.getenv("REPLAB_AGENT_MODE", "mock").strip().lower()
