from __future__ import annotations
import csv, json
from datetime import datetime, timezone
from uuid import uuid4
from functools import lru_cache
from ..config import PAPER_LOCK_PATH, SEED_ROOT, STORY_PATH
from ..core.affiliation import load_affiliation
from ..core.representations import compute_all_q2
from ..core.ranks import spearman
from ..core.padding import padding_result


@lru_cache
def story_spec():
    return json.loads(STORY_PATH.read_text(encoding="utf-8"))

SOURCE_LABELS = {
    "paper_aggregate": "PAPER AGGREGATE",
    "live_computed": "LIVE COMPUTED",
    "public_summary": "PUBLIC DATA SUMMARY",
    "live_public": "LIVE PUBLIC DATA",
}

def _run_meta(source_kind: str, provenance_note: list[str] | None = None):
    return {
        "run_id": f"run-{uuid4().hex[:10]}",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "source_kind": source_kind,
        "source_label": SOURCE_LABELS[source_kind],
        "provenance_note": provenance_note or [],
    }

def _story_meta(req):
    if getattr(req, "session_mode", "free") != "guided":
        return None
    mission_id = getattr(req, "story_mission_id", None)
    if not mission_id:
        return None
    for m in story_spec().get("missions", []):
        if m.get("id") == mission_id:
            return {k:m.get(k) for k in ("id","order","title","question","suggested_probe","layer_tags")}
    return None

@lru_cache
def paper_lock():
    return json.loads(PAPER_LOCK_PATH.read_text(encoding="utf-8"))

def paper_overview():
    p=paper_lock(); s=p["shipbuilding_applies_q2"]
    return {
        "case_id":"shipbuilding_applies_q2",
        "population":{"N":s["universe_N"],"active_N":s["active_N"],"common_minimum_N":s["common_minimum_N"],"common_minimum_share":s["common_minimum_share"]},
        "association":{"global_spearman":s["global_spearman"],"active_spearman":s["active_spearman"],"gap":s["global_spearman"]-s["active_spearman"]},
        "boundaries":["recorded zero under the focal relation is not verified structural absence","global association alone is not an equivalence verdict"],
        "source_version":p["lock_version"],
    }

def diagnostic_bundle():
    p=paper_lock(); s=p["shipbuilding_applies_q2"]; n=p["null_model_applies_q2"]
    return {
      "case_id":"shipbuilding_applies_q2","source_version":p["lock_version"],
      "coverage":{"N":s["universe_N"],"active_N":s["active_N"],"common_minimum_N":s["common_minimum_N"],"common_minimum_share":s["common_minimum_share"],
                  "interpretation_boundary":["recorded zero is not verified structural absence"]},
      "association":{"global_spearman":s["global_spearman"],"active_spearman":s["active_spearman"],"gap":s["global_spearman"]-s["active_spearman"],"bootstrap":s["active_bootstrap"],
                     "interpretation_boundary":["does not establish semantic equivalence"]},
      "decision":{"strict_inversion_rate":s["strict_inversion_rate"],"topk_jaccard":s["topk_jaccard"],
                  "interpretation_boundary":["observed descriptive decision metrics; no retained fixed-margin null distributions for these metrics"]},
      "semantics":{"P2_total":s["P2_total"],"S2_total":s["S2_total"],"M2_total":s["M2_total"],
                   "interpretation_boundary":["M2 is an auxiliary semantic descriptor, not an independent primary representation"]},
      "null":{**n,"interpretation_boundary":["not extreme under the selected sampled fixed-margin reference ensemble","does not prove equivalence or absence of higher-order mechanisms","does not test the common-minimum coverage effect"]}
    }

def _csv_rows(name):
    with (SEED_ROOT/name).open("r",encoding="utf-8-sig",newline="") as f: return list(csv.DictReader(f))

def padding_demo(mode:str,z:int):
    if mode=="reversed":
        rows=_csv_rows("reversed_active_ranks.csv")
        x=[float(r["x"]) for r in rows]; y=[float(r["y"]) for r in rows]
    elif mode=="micro":
        data=load_affiliation(SEED_ROOT); m=compute_all_q2(data)
        active=[u for u in data.entities if m[u]["k"]>0]
        x=[m[u]["k"] for u in active]; y=[m[u]["P2"] for u in active]
    else: raise KeyError(mode)
    result=padding_result(x,y,z)
    return {"mode":mode,**result,"x":x,"y":y,"source":"public synthetic/stress-test data"}

def workbench_options():
    return {
        "datasets": [
            {"id":"shipbuilding","label":"Shipbuilding","relations":["APPLIES","PROVIDES","UNION"],"q":[2,3,4],"relation_q":{"APPLIES":[2,3,4],"PROVIDES":[2],"UNION":[2]}},
            {"id":"movielens_all","label":"MovieLens · All ratings","relations":["ratings"],"q":[2]},
            {"id":"movielens_1997_q4","label":"MovieLens · 1997 Q4","relations":["ratings"],"q":[2]},
            {"id":"movielens_1998_q1","label":"MovieLens · 1998 Q1","relations":["ratings"],"q":[2]},
            {"id":"dblp_active","label":"DBLP · active-only","relations":["author-paper"],"q":[2]},
        ],
        "representations":["k","P2","S2"],
        "metrics":["spearman","kendall_tau_b","pearson","strict_inversion","topk_jaccard"],
        "top_k_locked":[5,10,20],
        "stress_scenarios":["micro","reversed"],
        "source_version":paper_lock()["lock_version"],
    }

def experiment_run(req):
    p=paper_lock()
    source=p["lock_version"]
    boundaries=list(p.get("claim_boundaries", []))
    availability={"coverage":False,"association":False,"decision":False,"semantics":False,"null":False}
    metrics={}
    population={}
    evidence=[]

    if req.mode=="stress":
        scenario=req.stress_scenario or "reversed"
        z=req.z or 0
        pad=padding_demo(scenario,z)
        availability.update({"association":True,"decision":True})
        metrics.update({"active_spearman":pad["active_spearman"],"global_spearman":pad["global_spearman"],"active_ordering_changed":pad["active_ordering_changed"]})
        population.update({"active_N":pad["active_n"],"common_minimum_N":z,"total_N":pad["total_n"]})
        evidence.append({"id":"stress-padding","kind":"deterministic","source":"public synthetic/stress-test data","population":"synthetic active + common minima","payload":metrics.copy(),"interpretation_boundary":["not a reconstruction of confidential APPLIES active vectors"],"source_version":"public-demo-v1"})
        meta=_run_meta("live_computed", ["Recomputed from public/synthetic seed vectors in the development kit.", "Not a reconstruction of confidential APPLIES active vectors."])
        return {**meta,"story":_story_meta(req),"config":req.model_dump(),"availability":availability,"population":population,"metrics":metrics,"evidence":evidence,"boundaries":["Public deterministic theorem stress test; not a reconstruction of confidential APPLIES active vectors."],"source_version":"public-demo-v1"}

    if req.dataset_id=="shipbuilding":
        rel=req.relation.upper()
        if rel not in p["relation_sensitivity"]: raise KeyError(f"unsupported relation {rel}")
        if rel in ("PROVIDES", "UNION") and req.q != 2:
            raise KeyError(f"{rel} paper evidence is available only for q=2")
        rs=p["relation_sensitivity"][rel]
        availability.update({"coverage":True,"association":True,"decision":True})
        population={"active_N":rs["active_N"],"common_minimum_share":rs.get("common_zero_share")}
        metrics={"global_spearman":rs["global_spearman"],"active_spearman":rs["active_spearman"],"strict_inversion_rate":rs["active_inversion_rate"]}
        if rel=="APPLIES":
            population.update({"total_N":p["shipbuilding_applies_q2"]["universe_N"],"common_minimum_N":p["shipbuilding_applies_q2"]["common_minimum_N"]})
            if req.q in (3,4):
                oq=p["order_sensitivity_applies"][str(req.q)]
                metrics={"active_spearman":oq["active_spearman"],"strict_inversion_rate":oq["strict_inversion_rate"]}
                availability.update({"coverage":True,"association":True,"decision":True,"semantics":False,"null":False})
            elif req.q==2:
                s=p["shipbuilding_applies_q2"]
                metrics.update({"global_spearman":s["global_spearman"],"active_spearman":s["active_spearman"],"strict_inversion_rate":s["strict_inversion_rate"],"topk_jaccard":s["topk_jaccard"].get(str(req.top_k)),"gap":s["global_spearman"]-s["active_spearman"],"P2_total":s["P2_total"],"S2_total":s["S2_total"],"M2_total":s["M2_total"]})
                availability["semantics"]=True
                if req.null_enabled:
                    n=p["null_model_applies_q2"]
                    metrics.update({"null_p":n["reported_p"],"null_observed":n["observed_spearman"],"null_mean":n["pooled_null_mean"],"null_quantiles":n["quantiles"],"null_retained":n["retained_graphs"]})
                    availability["null"]=True
        evidence.append({"id":"paper-case","kind":"paper_aggregate","source":"paper_numbers.lock.json","population":req.population,"payload":metrics.copy(),"interpretation_boundary":boundaries,"source_version":source})
    elif req.dataset_id.startswith("movielens"):
        key={"movielens_all":"all_ratings","movielens_1997_q4":"1997_Q4","movielens_1998_q1":"1998_Q1"}[req.dataset_id]
        m=p["movielens"][key]
        availability.update({"coverage":True,"association":True,"decision":True})
        population={"total_N":m["universe_N"],"active_N":m["active_N"],"inactive_share":m["inactive_share"]}
        metrics={"global_spearman":m["global_spearman"],"active_spearman":m["active_spearman"],"strict_inversion_rate":m["strict_inversion_rate"],"topk_jaccard":m["top10_jaccard"] if req.top_k==10 else None}
        evidence.append({"id":"movielens-paper","kind":"paper_aggregate","source":"paper_numbers.lock.json","population":req.population,"payload":metrics.copy(),"interpretation_boundary":["calendar-window evidence is exploratory transferability evidence"],"source_version":source})
    elif req.dataset_id=="dblp_active":
        d=p["dblp"]
        availability.update({"association":True,"decision":True})
        population={"active_N":d["authors"],"population_mode":"active-only"}
        pct={5:"5pct",10:"10pct",20:"20pct"}
        metrics={"active_spearman":d["spearman_k_P2"],"topk_jaccard":d["topk_jaccard"].get(pct.get(req.top_k,"10pct"))}
        evidence.append({"id":"dblp-paper","kind":"paper_aggregate","source":"paper_numbers.lock.json","population":"active-only","payload":metrics.copy(),"interpretation_boundary":["DBLP does not provide a natural common-minimum coverage replication"],"source_version":source})
    else:
        raise KeyError(f"unsupported dataset {req.dataset_id}")

    if metrics.get("topk_jaccard") is None: metrics.pop("topk_jaccard",None)
    if req.dataset_id == "shipbuilding":
        meta=_run_meta("paper_aggregate", ["Displayed from data/paper_numbers.lock.json.", "No confidential APPLIES row-level vectors are present in this package."])
    else:
        meta=_run_meta("public_summary", ["Displayed from manuscript-locked aggregate summaries for a public dataset.", "P0 does not redistribute the original public dataset."])
    return {**meta,"story":_story_meta(req),"config":req.model_dump(),"availability":availability,"population":population,"metrics":metrics,"evidence":evidence,"boundaries":boundaries,"source_version":source}
