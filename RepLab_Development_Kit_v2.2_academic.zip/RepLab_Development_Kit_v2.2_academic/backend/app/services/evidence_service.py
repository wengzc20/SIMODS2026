from ..models import EvidenceRecord
from .data_service import diagnostic_bundle, paper_lock

def locked_evidence() -> list[EvidenceRecord]:
    d=diagnostic_bundle(); version=d["source_version"]
    return [
      EvidenceRecord(id="cov-001",kind="coverage",source="paper_numbers.lock.json",population="full APPLIES company universe",payload=d["coverage"],interpretation_boundary=d["coverage"]["interpretation_boundary"],source_version=version),
      EvidenceRecord(id="assoc-001",kind="association",source="paper_numbers.lock.json",population="full vs APPLIES-active",payload=d["association"],interpretation_boundary=d["association"]["interpretation_boundary"],source_version=version),
      EvidenceRecord(id="dec-001",kind="decision",source="paper_numbers.lock.json",population="APPLIES-active",payload=d["decision"],interpretation_boundary=d["decision"]["interpretation_boundary"],source_version=version),
      EvidenceRecord(id="sem-001",kind="semantics",source="paper_numbers.lock.json",population="APPLIES q=2",payload=d["semantics"],interpretation_boundary=d["semantics"]["interpretation_boundary"],source_version=version),
      EvidenceRecord(id="null-001",kind="null",source="paper_numbers.lock.json",population="APPLIES-active fixed-margin reference ensemble",payload=d["null"],interpretation_boundary=d["null"]["interpretation_boundary"],source_version=version),
    ]
