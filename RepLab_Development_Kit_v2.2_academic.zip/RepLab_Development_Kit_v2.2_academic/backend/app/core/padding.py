from __future__ import annotations
from typing import Sequence
from .ranks import spearman

def append_common_minima(x: Sequence[float], y: Sequence[float], z:int):
    if z<0: raise ValueError("z must be nonnegative")
    if len(x)!=len(y) or not x: raise ValueError("active vectors must be same nonzero length")
    if z==0: return list(x),list(y)
    xmin=min(x)-1; ymin=min(y)-1
    return list(x)+[xmin]*z, list(y)+[ymin]*z

def padding_result(x: Sequence[float], y: Sequence[float], z:int):
    active=spearman(x,y)
    xx,yy=append_common_minima(x,y,z)
    return {"active_n":len(x),"z":z,"total_n":len(xx),"active_spearman":active,
            "global_spearman":spearman(xx,yy),"active_ordering_changed":False}
