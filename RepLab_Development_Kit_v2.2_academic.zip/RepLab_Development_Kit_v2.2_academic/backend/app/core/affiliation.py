from dataclasses import dataclass
from pathlib import Path
import csv

@dataclass(frozen=True)
class AffiliationData:
    entities: list[str]
    contexts: list[str]
    edges: list[tuple[str,str]]

def _read_csv(path: Path):
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        yield from csv.DictReader(f)

def load_affiliation(seed_root: Path) -> AffiliationData:
    entities=[r["entity_id"] for r in _read_csv(seed_root/"entities.csv")]
    contexts=[r["context_id"] for r in _read_csv(seed_root/"contexts.csv")]
    edges=[(r["entity_id"],r["context_id"]) for r in _read_csv(seed_root/"affiliations.csv")]
    return AffiliationData(entities,contexts,edges)
