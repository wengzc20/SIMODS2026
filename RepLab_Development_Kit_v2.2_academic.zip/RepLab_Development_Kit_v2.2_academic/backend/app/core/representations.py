from __future__ import annotations
from collections import defaultdict
from itertools import combinations
from math import comb
from .affiliation import AffiliationData

def compute_k(data: AffiliationData) -> dict[str,int]:
    out={u:0 for u in data.entities}
    for u,_ in data.edges: out[u]+=1
    return out

def _members_by_context(data: AffiliationData) -> dict[str,list[str]]:
    d=defaultdict(list)
    for u,t in data.edges: d[t].append(u)
    return d

def compute_P2(data: AffiliationData) -> dict[str,int]:
    members=_members_by_context(data)
    out={u:0 for u in data.entities}
    for _,us in members.items():
        contribution=comb(len(us)-1,2) if len(us)>=3 else 0
        for u in us: out[u]+=contribution
    return out

def compute_S2(data: AffiliationData) -> dict[str,int]:
    members=_members_by_context(data)
    triples=set()
    for us in members.values():
        for tri in combinations(sorted(set(us)),3): triples.add(tri)
    out={u:0 for u in data.entities}
    for tri in triples:
        for u in tri: out[u]+=1
    return out

def compute_all_q2(data: AffiliationData):
    k=compute_k(data); p=compute_P2(data); s=compute_S2(data)
    return {u:{"k":k[u],"P2":p[u],"S2":s[u],"M2":p[u]-s[u]} for u in data.entities}
