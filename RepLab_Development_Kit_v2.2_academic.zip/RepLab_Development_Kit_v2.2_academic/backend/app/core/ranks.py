from __future__ import annotations
import math
from typing import Sequence

class DegenerateVectorError(ValueError):
    pass

def midranks(values: Sequence[float]) -> list[float]:
    n = len(values)
    order = sorted(range(n), key=lambda i: (values[i], i))
    ranks = [0.0] * n
    a = 0
    while a < n:
        b = a + 1
        v = values[order[a]]
        while b < n and values[order[b]] == v:
            b += 1
        # 1-based positions a+1 ... b
        rank = ((a + 1) + b) / 2.0
        for k in range(a, b):
            ranks[order[k]] = rank
        a = b
    return ranks

def pearson(x: Sequence[float], y: Sequence[float]) -> float:
    if len(x) != len(y) or len(x) < 2:
        raise ValueError("vectors must have equal length >= 2")
    mx = sum(x) / len(x); my = sum(y) / len(y)
    dx = [v-mx for v in x]; dy = [v-my for v in y]
    sx = sum(v*v for v in dx); sy = sum(v*v for v in dy)
    if sx <= 0 or sy <= 0:
        raise DegenerateVectorError("correlation undefined for a constant vector")
    return sum(a*b for a,b in zip(dx,dy)) / math.sqrt(sx*sy)

def spearman(x: Sequence[float], y: Sequence[float]) -> float:
    return pearson(midranks(x), midranks(y))
