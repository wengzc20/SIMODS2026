from __future__ import annotations
from typing import Sequence

def strict_inversion_rate(x: Sequence[float], y: Sequence[float]) -> dict[str,float|int|None]:
    if len(x)!=len(y): raise ValueError("length mismatch")
    inv=0; comp=0
    for i in range(len(x)):
        for j in range(i+1,len(x)):
            dx=x[i]-x[j]; dy=y[i]-y[j]
            if dx==0 or dy==0: continue
            comp+=1
            if dx*dy<0: inv+=1
    return {"inversions":inv,"comparable_pairs":comp,"rate":(inv/comp if comp else None)}

def tie_aware_topk_ids(ids: Sequence[str], scores: Sequence[float], k:int) -> set[str]:
    if len(ids)!=len(scores): raise ValueError("length mismatch")
    if not 1 <= k <= len(ids): raise ValueError("invalid k")
    boundary=sorted(scores, reverse=True)[k-1]
    return {i for i,s in zip(ids,scores) if s>=boundary}

def jaccard(a:set[str],b:set[str]) -> float:
    return 1.0 if not a and not b else len(a&b)/len(a|b)
