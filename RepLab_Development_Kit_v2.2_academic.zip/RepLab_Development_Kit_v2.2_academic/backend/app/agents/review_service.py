from __future__ import annotations
import json, os, uuid
from ..models import AgentNote, ReviewResponse
from ..services.evidence_service import locked_evidence

REQUIRED_BLOCKED = [
    "rho=0.9994 并不能证明两种表示等价",
    "p>0.05 并不能证明不存在高阶机制",
    "623 家企业并非没有真实关联",
]

async def run_mock(question:str) -> ReviewResponse:
    ev=locked_evidence()
    outputs=[
      AgentNote(agent="Coverage Analyst",summary="The common-minimum block occupies 92.30% of the stated full population, so population composition is material to interpretation.",evidence_ids=["cov-001"]),
      AgentNote(agent="Statistics Analyst",summary="Global and APPLIES-active Spearman differ materially; the global coefficient alone cannot establish interchangeability among active companies.",evidence_ids=["assoc-001"]),
      AgentNote(agent="Decision Analyst",summary="Observed active decision summaries differ, including strict inversions and incomplete Top-K overlap.",evidence_ids=["dec-001"]),
      AgentNote(agent="Reviewer",summary="The evidence supports a population-conditioned interpretation, not an unconditional equivalence verdict or proof of absent higher-order mechanisms.",evidence_ids=[e.id for e in ev],
                allowed_claims=["总体相关性高度受所述评估总体构成的影响。","在所选固定边际抽样参考集合中，观测到的活跃层 Spearman 并不极端。"],
                blocked_claims=REQUIRED_BLOCKED,
                unresolved=["表示方式的选择仍依赖于具体任务。"])
    ]
    return ReviewResponse(run_id=str(uuid.uuid4()),mode="mock",evidence=ev,agent_outputs=outputs,
        allowed_claims=outputs[-1].allowed_claims,blocked_claims=outputs[-1].blocked_claims,unresolved=outputs[-1].unresolved)

async def run_live(question:str, manager:bool=False) -> ReviewResponse:
    # Lazy import keeps offline paper demo independent of agent dependency/API key.
    from agents import Agent, Runner
    ev=locked_evidence()
    evidence_json=json.dumps([e.model_dump() for e in ev],ensure_ascii=False)
    base=("Never invent numerical values. Use only supplied EvidenceRecords. "
          "Every factual claim containing a number must cite an evidence_id. "
          "Do not reveal chain-of-thought; return only the requested structured review.")

    coverage=Agent(name="Coverage Analyst",instructions=base+" Focus only on population coverage and recorded-zero boundaries.",output_type=AgentNote)
    stats=Agent(name="Statistics Analyst",instructions=base+" Focus on global-vs-active association and decision statistics; do not interpret null p-values as absence proofs.",output_type=AgentNote)
    decision=Agent(name="Decision Analyst",instructions=base+" Focus on strict inversions and tie-aware Top-K implications.",output_type=AgentNote)
    reviewer=Agent(name="Reviewer",instructions=base+" Audit claims for population omission, structural-zero overclaim, equivalence overclaim, and p-value misuse. Produce allowed_claims, blocked_claims, unresolved.",output_type=AgentNote)

    prompt=f"Research question: {question}\nEvidenceRecords:\n{evidence_json}"
    if manager:
        orchestrator=Agent(
            name="PI Orchestrator",
            instructions=base+" You MUST call all three analyst tools and then the reviewer tool. Return a concise final synthesis, not new numbers.",
            tools=[
                coverage.as_tool(tool_name="coverage_review",tool_description="Interpret coverage evidence."),
                stats.as_tool(tool_name="statistics_review",tool_description="Interpret association evidence."),
                decision.as_tool(tool_name="decision_review",tool_description="Interpret decision evidence."),
                reviewer.as_tool(tool_name="reviewer_audit",tool_description="Audit the evidence-bounded scientific claims."),
            ],
        )
        result=await Runner.run(orchestrator,prompt)
        note=AgentNote(agent="PI Orchestrator",summary=str(result.final_output),evidence_ids=[e.id for e in ev],unresolved=["See SDK trace for nested tool-agent events."])
        return ReviewResponse(run_id=str(uuid.uuid4()),mode="manager",evidence=ev,agent_outputs=[note],allowed_claims=[],blocked_claims=REQUIRED_BLOCKED,unresolved=note.unresolved)

    notes=[]
    for agent in (coverage,stats,decision):
        r=await Runner.run(agent,prompt)
        notes.append(r.final_output)
    review_prompt=prompt+"\nSpecialist notes:\n"+json.dumps([n.model_dump() for n in notes],ensure_ascii=False)
    rr=await Runner.run(reviewer,review_prompt)
    notes.append(rr.final_output)
    final=rr.final_output
    # Safety floor: canonical blocked claims remain blocked even if the model omits them.
    blocked=list(dict.fromkeys([*final.blocked_claims,*REQUIRED_BLOCKED]))
    return ReviewResponse(run_id=str(uuid.uuid4()),mode="live",evidence=ev,agent_outputs=notes,
                          allowed_claims=final.allowed_claims,blocked_claims=blocked,unresolved=final.unresolved)
