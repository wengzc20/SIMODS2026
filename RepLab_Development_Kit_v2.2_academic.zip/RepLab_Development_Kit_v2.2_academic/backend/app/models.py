from typing import Any, Literal
from pydantic import BaseModel, Field


class SourceInfo(BaseModel):
    source_kind: Literal["paper_aggregate", "live_computed", "public_summary", "live_public"]
    source_label: str
    source_version: str
    provenance_note: list[str] = Field(default_factory=list)

class EvidenceRecord(BaseModel):
    id: str
    kind: str
    source: str
    population: str
    payload: dict[str, Any]
    interpretation_boundary: list[str] = Field(default_factory=list)
    source_version: str

class PaddingRequest(BaseModel):
    mode: Literal["micro", "reversed"] = "reversed"
    z: int = Field(ge=0, le=10000)

class ReviewRequest(BaseModel):
    case_id: str = "shipbuilding_applies_q2"
    question: str = "Can degree replace P2 for the current APPLIES evaluation population?"
    mode: Literal["mock", "live", "manager"] = "mock"

class AgentNote(BaseModel):
    agent: str
    summary: str
    evidence_ids: list[str]
    allowed_claims: list[str] = Field(default_factory=list)
    blocked_claims: list[str] = Field(default_factory=list)
    unresolved: list[str] = Field(default_factory=list)

class ReviewResponse(BaseModel):
    run_id: str
    mode: str
    evidence: list[EvidenceRecord]
    agent_outputs: list[AgentNote]
    allowed_claims: list[str]
    blocked_claims: list[str]
    unresolved: list[str]

class ExperimentRequest(BaseModel):
    session_mode: Literal["guided", "free"] = "guided"
    story_mission_id: str | None = None
    dataset_id: str = "shipbuilding"
    relation: str = "APPLIES"
    q: int = Field(default=2, ge=1, le=10)
    representation_a: str = "k"
    representation_b: str = "P2"
    population: Literal["full", "active", "eligible"] = "full"
    mode: Literal["paper", "stress"] = "paper"
    stress_scenario: Literal["micro", "reversed"] | None = None
    z: int | None = Field(default=None, ge=0, le=10000)
    top_k: int = Field(default=10, ge=1, le=1000)
    metrics: list[str] = Field(default_factory=lambda: ["spearman", "strict_inversion", "topk_jaccard"])
    null_enabled: bool = True
    reviewer_enabled: bool = False
