import csv, json
from pathlib import Path
import pytest
from app.config import SEED_ROOT
from app.core.affiliation import load_affiliation
from app.core.representations import compute_all_q2
from app.core.ranks import spearman, midranks
from app.core.padding import padding_result
from app.core.decisions import strict_inversion_rate, tie_aware_topk_ids, jaccard

def rows(name):
    with (SEED_ROOT/name).open("r",encoding="utf-8-sig",newline="") as f: return list(csv.DictReader(f))

def test_micro_metrics_exact():
    data=load_affiliation(SEED_ROOT); got=compute_all_q2(data)
    for r in rows("micro_expected_metrics.csv"):
        u=r["entity_id"]
        assert got[u]=={k:int(r[k]) for k in ("k","P2","S2","M2")}

def test_micro_spearman_summary():
    data=load_affiliation(SEED_ROOT); m=compute_all_q2(data)
    active=[u for u in data.entities if m[u]["k"]>0]
    x=[m[u]["k"] for u in active]; y=[m[u]["P2"] for u in active]
    allx=[m[u]["k"] for u in data.entities]; ally=[m[u]["P2"] for u in data.entities]
    exp=json.loads((SEED_ROOT/"micro_expected_summary.json").read_text())
    assert spearman(x,y)==pytest.approx(exp["active_spearman_k_P2"],abs=1e-12)
    assert spearman(allx,ally)==pytest.approx(exp["global_spearman_k_P2"],abs=1e-12)

def test_reversed_padding_fixture():
    active=rows("reversed_active_ranks.csv")
    x=[float(r["x"]) for r in active]; y=[float(r["y"]) for r in active]
    assert spearman(x,y)==pytest.approx(-1.0)
    for r in rows("reversed_padding_expected.csv"):
        got=padding_result(x,y,int(r["z_common_minima"]))
        assert got["global_spearman"]==pytest.approx(float(r["spearman"]),abs=1e-12)

def test_decision_tie_rules():
    ids=["a","b","c","d"]
    x=[4,3,3,1]; y=[4,2,3,1]
    sx=tie_aware_topk_ids(ids,x,2)
    assert sx=={"a","b","c"}
    sy=tie_aware_topk_ids(ids,y,2)
    assert sy=={"a","c"}
    assert jaccard(sx,sy)==pytest.approx(2/3)
    out=strict_inversion_rate([2,2,1],[1,2,3])
    assert out["comparable_pairs"]==2
