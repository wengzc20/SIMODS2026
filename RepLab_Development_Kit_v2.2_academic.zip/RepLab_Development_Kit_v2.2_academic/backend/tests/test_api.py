from fastapi.testclient import TestClient
from app.main import app

c=TestClient(app)

def test_health():
    assert c.get("/api/v1/health").json()["status"]=="ok"

def test_overview_lock_values():
    d=c.get("/api/v1/paper/overview").json()
    assert d["population"]=={"N":675,"active_N":52,"common_minimum_N":623,"common_minimum_share":0.923}
    assert d["association"]["global_spearman"]==0.999412
    assert d["association"]["active_spearman"]==0.71548

def test_padding_reversed_100():
    d=c.post("/api/v1/lab/padding",json={"mode":"reversed","z":100}).json()
    assert abs(d["global_spearman"]-0.9961186581646798)<1e-12
    assert d["active_spearman"]==-1.0
    assert d["active_ordering_changed"] is False

def test_mock_review_blocks_overclaims():
    d=c.post("/api/v1/review/run",json={"mode":"mock"}).json()
    assert any("p>0.05" in s for s in d["blocked_claims"])
    assert any("等价" in s for s in d["blocked_claims"])

def test_workbench_options():
    r=c.get('/api/v1/workbench/options')
    assert r.status_code==200
    assert any(d['id']=='shipbuilding' for d in r.json()['datasets'])

def test_experiment_applies_q2():
    r=c.post('/api/v1/experiment/run',json={"dataset_id":"shipbuilding","relation":"APPLIES","q":2,"representation_a":"k","representation_b":"P2","population":"full","mode":"paper","top_k":10,"metrics":["spearman"],"null_enabled":True,"reviewer_enabled":False})
    assert r.status_code==200
    d=r.json()
    assert d['metrics']['global_spearman']==0.999412
    assert d['metrics']['active_spearman']==0.71548
    assert d['metrics']['topk_jaccard']==0.375
    assert d['metrics']['null_p']==0.1055

def test_story_missions_grounded():
    r=c.get('/api/v1/story/missions')
    assert r.status_code==200
    d=r.json()
    assert d['title']=='0.999 能证明什么？'
    assert d['missions'][0]['id']=='case-01'
    assert any(m['id']=='case-06' for m in d['missions'])


def test_guided_run_has_story_and_unique_metadata():
    body={"session_mode":"guided","story_mission_id":"case-02","dataset_id":"shipbuilding","relation":"APPLIES","q":2,"population":"active","mode":"paper","top_k":10,"null_enabled":False}
    a=c.post('/api/v1/experiment/run',json=body).json()
    b=c.post('/api/v1/experiment/run',json=body).json()
    assert a['story']['id']=='case-02'
    assert a['source_kind']=='paper_aggregate'
    assert a['created_at']
    assert a['run_id']!=b['run_id']


def test_unsupported_relation_q_is_rejected():
    r=c.post('/api/v1/experiment/run',json={"dataset_id":"shipbuilding","relation":"PROVIDES","q":3,"population":"active","mode":"paper","top_k":10,"null_enabled":False})
    assert r.status_code==422


def test_workbench_relation_q_matrix():
    d=c.get('/api/v1/workbench/options').json()
    ship=next(x for x in d['datasets'] if x['id']=='shipbuilding')
    assert ship['relation_q']['APPLIES']==[2,3,4]
    assert ship['relation_q']['PROVIDES']==[2]


def test_source_provenance_metadata():
    r = c.post('/api/v1/experiment/run', json={
        'dataset_id':'shipbuilding','relation':'APPLIES','q':2,'population':'full','mode':'paper','top_k':10,'null_enabled':False
    })
    assert r.status_code == 200
    body=r.json()
    assert body['source_kind']=='paper_aggregate'
    assert body['source_label']=='PAPER AGGREGATE'
    assert body['provenance_note']

    r2 = c.post('/api/v1/experiment/run', json={
        'dataset_id':'shipbuilding','relation':'APPLIES','q':2,'population':'full','mode':'stress','stress_scenario':'reversed','z':100,'top_k':10,'null_enabled':False
    })
    assert r2.status_code == 200
    body2=r2.json()
    assert body2['source_kind']=='live_computed'
    assert body2['source_label']=='LIVE COMPUTED'
    assert any('not a reconstruction' in x.lower() for x in body2['provenance_note'])


def test_public_summary_source_metadata():
    r=c.post('/api/v1/experiment/run',json={"dataset_id":"movielens_1997_q4","relation":"ratings","q":2,"population":"full","mode":"paper","top_k":10,"null_enabled":False})
    assert r.status_code==200
    body=r.json()
    assert body['source_kind']=='public_summary'
    assert body['source_label']=='PUBLIC DATA SUMMARY'
