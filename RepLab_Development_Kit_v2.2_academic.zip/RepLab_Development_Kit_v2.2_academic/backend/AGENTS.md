# Backend-specific Codex instructions
- `app/core/` must be deterministic and must not import any LLM/agent package.
- `app/agents/` may import OpenAI Agents SDK; it consumes EvidenceRecords, not raw confidential data.
- Every public math function needs a unit test with an explicit numeric fixture.
- Preserve exact tie semantics: Spearman uses midranks; Top-K is tie-aware at the cutoff; strict inversions ignore pairs tied in either representation.
- Do not silently convert NaN/undefined correlations to zero. Return a typed undefined/error state.
