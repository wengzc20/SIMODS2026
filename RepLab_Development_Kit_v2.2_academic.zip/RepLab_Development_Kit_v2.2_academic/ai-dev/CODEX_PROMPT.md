Read PRODUCT_SPEC.md, UI_INTERACTION_SPEC.md, TECH_ARCHITECTURE.md, DATA_GUIDE.md, TASKS_2W.md and AGENTS.md.
Do not change paper_numbers.lock.json.
First replace the existing paper-overview home route with the Experiment Workspace shell. Preserve scientific evidence boundaries and report all changed files and tests.
