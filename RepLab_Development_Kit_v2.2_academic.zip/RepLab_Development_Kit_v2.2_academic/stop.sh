#!/usr/bin/env bash
BACKEND_PORT="${REPLAB_BACKEND_PORT:-8000}"
FRONTEND_PORT="${REPLAB_FRONTEND_PORT:-3000}"
for p in "$BACKEND_PORT" "$FRONTEND_PORT"; do
  pid=$(lsof -ti tcp:$p 2>/dev/null || true)
  if [ -n "$pid" ]; then kill -9 $pid; echo "已停止端口 $p"; else echo "端口 $p 无进程"; fi
done
