# Data Source & Visualization Policy v2.2

This policy is a hard scientific-integrity constraint for RepLab.

## Source classes

| source_kind | UI badge | Computation | P0 example |
|---|---|---|---|
| paper_aggregate | PAPER AGGREGATE | no row-level recomputation | Shipbuilding APPLIES results |
| live_computed | LIVE COMPUTED | deterministic Python core | synthetic common-minimum stress test |
| public_summary | PUBLIC DATA SUMMARY | display locked manuscript aggregates | MovieLens/DBLP scenario summaries |
| live_public | LIVE PUBLIC DATA | future local public-data recomputation | future MovieLens/DBLP reproduction |

## Non-negotiable boundary

The development kit does not contain confidential APPLIES entity-level observations. It must not manufacture a visual that implies otherwise.

For `paper_aggregate` shipbuilding views, do not render:
- company scatterplots;
- company names;
- individual k/P2 values;
- entity-level rank links;
- a null histogram without sample values.

For `live_computed` stress tests, render synthetic/public vectors freely but mark them as such.

## Provenance contract

Every RunSnapshot response must include:
- `source_kind`
- `source_label`
- `source_version`
- at least one `provenance_note`

Every EvidenceRecord must be traceable to either the paper lock, a seed file, or a future public-data manifest.
