# RepLab Product Specification v2.1

## 1. Product position

RepLab is a **story-driven scientific experiment companion for the manuscript**, not a paper dashboard.

The manuscript provides the scientific case. The product turns that case into an instrument the user can operate:

> suspect a result → change one condition → run → compare → challenge the interpretation → make a defensible claim

The first two-week release must feel like experimental debugging. The user should be changing population boundaries, relation semantics, higher-order order, decision thresholds, common-minimum padding, and robustness layers—not scrolling through a static summary.

### 1.1 Scientific anchor
The two-week experience is built around the manuscript’s bounded claim:
- global agreement can be inflated by a shared strict-minimum block;
- active ordering and decisions can remain different;
- statistical agreement, decision consistency, and semantic consistency are distinct judgments;
- a fixed-margin null audit answers a structural-robustness question, not the coverage question;
- external datasets provide bounded transferability checks, not universal validation.

### 1.2 Default user experience
The home route `/` opens **Guided Research Case**.

A clear toggle switches to **Free Lab**.

Guided mode tells a scientific story but never changes the underlying computation. Free Lab exposes the same controls immediately.

## 2. The two-week story

The guided case is titled:

# `0.999 能证明什么？`

It progresses through:
1. 可疑的 0.999
2. 623 个共同最小值
3. 只改变覆盖，不改变活跃排序
4. 如果我要选 Top-K 呢？
5. 换关系、换阶数，现象还在吗？
6. 不同，不等于“异常”
7. Epilogue：总体是估计对象的一部分

Full definitions and manuscript-faithful values are in `STORY_EXPERIENCE_SPEC.md` and `data/story_missions.json`.

## 3. Main product shell

Desktop reference: 1600×900.

Stable regions:

1. **Top command bar**
   - Guided Case / Free Lab toggle
   - dataset / relation / q
   - Run
   - Pin A
   - Compare
   - Reset to paper baseline
   - Export

2. **Left Lab Controls**
   - scientific parameters only
   - no development status
   - no agent vanity controls

3. **Center Experiment Canvas**
   - research question banner
   - at most 4 headline KPIs
   - one dominant visualization
   - compact secondary panel
   - `What changed?` compare card when A is pinned

4. **Right Claim & Evidence rail**
   - provisional user claim
   - current evidence
   - evidence boundaries
   - reviewer result when invoked

5. **Bottom Run Tray**
   - horizontal experiment history R01, R02, ...
   - restore/pin/export actions
   - not a sprint timeline

6. **Scientific layer chips**
   - Coverage
   - Active Association
   - Decision
   - Semantics
   - Robustness

These chips classify evidence and filter the center/right panels. They preserve the manuscript’s five-layer framework.

## 4. Density rules

- maximum 4 KPI cards in the default first viewport;
- maximum 2 large visualization panels at once;
- left rail default open sections ≤ 2;
- advanced controls collapsed;
- right rail top evidence rows ≤ 4 before scrolling;
- run tray one line, horizontally scrollable;
- story prompt ≤ 90 Chinese characters in the main canvas;
- no full paper abstract, contribution list, sprint plan, or AI architecture diagram on the home screen.

## 5. Core modes

### 5.1 Guided Research Case
Progressive disclosure + suggested next probe.

The user is encouraged to change one controlled parameter at a time. The system records a provisional claim before the full evidence is shown.

### 5.2 Free Lab
All manuscript-supported controls are available immediately.

Supported paper cases:
- Shipbuilding APPLIES q=2
- Shipbuilding PROVIDES
- Shipbuilding UNION
- Shipbuilding APPLIES q=3/q=4 active sensitivity
- MovieLens all / 1997 Q4 / 1998 Q1
- DBLP active-only

### 5.3 Public Theorem Stress Test
Synthetic/public vectors only.

Controls:
- scenario: micro / perfectly reversed
- z: 0–1000 P0, extend to 10000 later
- metric: Spearman P0
- optional Pearson/Kendall P1 if implementation is verified

Hard label:
> Public deterministic theorem demo. Not a reconstruction of confidential APPLIES active vectors.

## 6. Experiment-debugging mechanics

### 6.1 Dirty state
Any scientific parameter change marks the workspace dirty.

### 6.2 RunSnapshot
Every Run produces a snapshot with config + evidence + provenance.

### 6.3 Pin A / Compare B
A user can pin a successful run. Current run becomes B.

`What changed?` shows:
- exact parameter changes
- scientifically comparable metric deltas
- warning if multiple scientific dimensions changed

### 6.4 Suggested Next Probe
Guided mode offers one next controlled experiment.
It never changes parameters automatically.

### 6.5 Run Tray
Each run chip includes:
- run number
- relation/q/population
- headline metric
- source type

## 7. Manuscript-grounded parameter knobs

### Population boundary
- full
- active
- eligible only where supported

### Relation semantics
- APPLIES
- PROVIDES
- UNION sensitivity construction

### Higher-order order
- q=2/3/4 where manuscript evidence exists

### Decision threshold
- K=5/10/20 for locked paper aggregates

### Common-minimum augmentation
- z slider only in public/synthetic stress-test mode

### Null robustness
- enabled only for APPLIES q=2 active Spearman frozen audit

### External population construction
- MovieLens all vs calendar windows
- DBLP active-only contrast

## 8. Scientific interaction rules

### 8.1 Population change
Changing full → active must be visually treated as a change in evaluation population, not “cleaning bad data.”

### 8.2 Relation/q change
Relation and order sensitivity are distinct from the common-minimum proof. Do not imply APPLIES/PROVIDES/UNION are semantically interchangeable.

### 8.3 z change
The active rank-link geometry remains unchanged by construction.

### 8.4 Decision metrics
Top-K and inversion are descriptive for the observed APPLIES graph. The frozen rerun does not provide their fixed-margin null distributions.

### 8.5 Null
The APPLIES q=2 null audit:
- does not test the common-minimum mechanism;
- does not prove equivalence;
- does not prove absence of higher-order mechanisms;
- is an approximate MCMC-based Monte Carlo diagnostic, not an exact randomization test.

### 8.6 External data
MovieLens calendar windows are exploratory temporal sensitivity analyses. DBLP is active-only by construction.

## 9. Center views

Segmented scientific views:
- Coverage
- Association
- Decision
- Semantics
- Robustness

Context-specific experimental views:
- Padding Curve
- Active Rank Links
- Run Compare
- External Contrast

Only views supported by current evidence are enabled.

## 10. Right rail

### Your Claim
Three quick states:
- 可以替代
- 不可以替代
- 证据不足

Also allow a one-sentence custom claim.

### Evidence
Up to four most relevant EvidenceRecords.

### Boundary
One or two manuscript-faithful interpretation constraints.

### Reviewer
Mock reviewer is P0; live reviewer is optional.
Reviewer maps claims to evidence and boundaries. It never changes numerical results.

## 11. Secondary routes

Two-week P0 only needs:
- `/` experiment workspace
- `/data` reproducibility/data boundaries

Optional P1:
- `/paper` manuscript map
- `/review` advanced evidence/trace view

Do not fragment the two-week build into many top-level pages.

## 12. Product exclusions

Never show in the user product:
- two-week schedule
- backlog / Git status
- token usage
- model picker by default
- agent count
- “AI confidence”
- fake scatter points for confidential APPLIES entities
- fake null distributions
- fake decision-level null evidence

## 13. Long-term continuity

The v2.1 contracts must remain reusable by the full lab:
- `ExperimentConfig`
- `RunSnapshot`
- `EvidenceRecord`
- `ScientificClaim`
- `ReviewDecision`

Future Network Editor creates ExperimentConfigs.
Future Theorem Lab creates deterministic RunSnapshots.
Future Research Arena consumes EvidenceRecords/RunSnapshots.
MCP/A2A remain adapters at the perimeter, not core data models.


## v2.2 UI-lock override
The home screen remains the experiment workbench. `UI_FINAL_LOCK_v2.2.md` is now the canonical visual contract. Every result panel must expose a source badge. Paper-aggregate shipbuilding views cannot use entity-level plots or named tables.
