const puppeteer = require("puppeteer-core");

const CHROME = "C:\\Users\\Administrator\\.cache\\puppeteer\\chrome\\win64-150.0.7871.24\\chrome-win64\\chrome.exe";
const URL = "http://localhost:3100";
const OUT = "D:\\workbuddy\\202608_RepLab\\RepLab_Development_Kit_v2.2\\screenshots";

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function clickByText(page, selector, text) {
  const handles = await page.$$(selector);
  for (const h of handles) {
    const t = await page.evaluate((el) => el.textContent || "", h);
    if (t.includes(text)) { await h.click(); return true; }
  }
  return false;
}
async function zoomShot(page, selector, file) {
  const el = await page.$(selector);
  if (!el) { console.log("zoom MISS:", selector); return; }
  await el.evaluate((n) => n.scrollIntoView({ block: "center" }));
  await sleep(400);
  await el.screenshot({ path: `${OUT}\\${file}` });
  console.log("zoom done:", file);
}

(async () => {
  const browser = await puppeteer.launch({
    executablePath: CHROME,
    headless: true,
    args: ["--no-sandbox", "--disable-setuid-sandbox", "--disable-dev-shm-usage", "--force-color-profile=srgb"],
  });
  const page = await browser.newPage();
  await page.setViewport({ width: 1600, height: 1000, deviceScaleFactor: 1.5 });
  page.on("pageerror", (e) => console.log("PAGEERR:", e.message));
  page.on("console", (m) => { if (m.type() === "error") console.log("CONSOLEERR:", m.text()); });

  console.log("goto...");
  await page.goto(URL, { waitUntil: "networkidle0", timeout: 60000 });
  await page.waitForSelector(".storyRibbon .case", { timeout: 30000 });
  await sleep(2500);

  // --- S1: Case-01 landing (full workspace) ---
  await page.screenshot({ path: `${OUT}\\01_landing_case01.png` });
  console.log("S1 done");

  // --- Zoom shots of each region (on landing page) ---
  await zoomShot(page, ".storyRibbon", "z_ribbon.png");
  await zoomShot(page, ".commandBar", "z_commandbar.png");
  await zoomShot(page, ".labRail", "z_leftrail.png");
  await zoomShot(page, ".evidenceRail", "z_evidencerail.png");
  await zoomShot(page, ".runTray", "z_runtray.png");

  // --- S2: Coverage tab (92.30% reveal) ---
  await clickByText(page, ".layerTabs button", "Coverage");
  await sleep(1500);
  await page.screenshot({ path: `${OUT}\\02_coverage_case01.png` });
  console.log("S2 done");

  // --- S3: Case-02 Pin A (full) + Active + Compare A/B ---
  const ribbons = await page.$$(".storyRibbon .case");
  if (ribbons[1]) { await ribbons[1].click(); await sleep(2000); }
  await clickByText(page, ".commandBar button", "Pin A");
  await sleep(500);
  await clickByText(page, ".seg button", "Active");
  await sleep(400);
  await clickByText(page, ".commandBar button", "运行实验");
  await sleep(2500);
  await clickByText(page, ".commandBar button", "比较 A/B");
  await sleep(1200);
  await page.screenshot({ path: `${OUT}\\03_case02_active_compare.png` });
  console.log("S3 done");

  // --- S4: Case-03 Stress + raise z ---
  const ribbons2 = await page.$$(".storyRibbon .case");
  if (ribbons2[2]) { await ribbons2[2].click(); await sleep(2500); }
  await page.evaluate(() => {
    const el = document.querySelector('input[type=range]');
    if (el) { el.value = "500"; el.dispatchEvent(new Event("input", { bubbles: true })); }
  });
  await sleep(3000);
  await page.screenshot({ path: `${OUT}\\04_case03_stress.png` });
  console.log("S4 done");

  // --- S5: Case-04 Decision (Top-K Jaccard) ---
  const ribbons3 = await page.$$(".storyRibbon .case");
  if (ribbons3[3]) { await ribbons3[3].click(); await sleep(2500); }
  await clickByText(page, ".layerTabs button", "Decision");
  await sleep(1500);
  await page.screenshot({ path: `${OUT}\\05_case04_decision.png` });
  console.log("S5 done");

  // --- S5b: Case-05 Sensitivity (PROVIDES relation, q=3) ---
  const ribbons3b = await page.$$(".storyRibbon .case");
  if (ribbons3b[4]) { await ribbons3b[4].click(); await sleep(2500); }
  await clickByText(page, ".labRail select", "PROVIDES");
  await sleep(300);
  await clickByText(page, ".labRail select", "q = 3");
  await sleep(300);
  await clickByText(page, ".commandBar button", "运行实验");
  await sleep(2500);
  await page.screenshot({ path: `${OUT}\\08_case05_sensitivity.png` });
  console.log("S5b done");

  // --- S6: Case-06 Null + Reviewer ---
  const ribbons4 = await page.$$(".storyRibbon .case");
  if (ribbons4[5]) { await ribbons4[5].click(); await sleep(2500); }
  await clickByText(page, ".layerTabs button", "Robustness");
  await sleep(1800);
  await clickByText(page, ".evidenceRail button", "Reviewer");
  await sleep(2500);
  await page.screenshot({ path: `${OUT}\\06_case06_null_reviewer.png` });
  console.log("S6 done");

  // --- S7: Free Lab mode ---
  await clickByText(page, ".modeSwitch button", "自由实验");
  await sleep(2000);
  await page.screenshot({ path: `${OUT}\\07_free_lab.png` });
  console.log("S7 done");

  await browser.close();
  console.log("ALL DONE");
})().catch((e) => { console.error("FATAL", e); process.exit(1); });
