"""Generate RepLab v2.2 Operation Manual Word Document with screenshots."""
import os
from docx import Document
from docx.shared import Inches, Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT

SCR = os.path.dirname(__file__)
DOCX = os.path.join(os.path.dirname(os.path.dirname(__file__)), "RepLab_v2.2_界面操作手册.docx")

doc = Document()

# ── Styles ──
style = doc.styles["Normal"]
style.font.name = "Microsoft YaHei"
style.font.size = Pt(10.5)
style.paragraph_format.space_after = Pt(6)

for name, size in [("Heading 1", 18), ("Heading 2", 14), ("Heading 3", 12)]:
    s = doc.styles[name]
    s.font.name = "Microsoft YaHei"
    s.font.size = Pt(size)
    s.font.bold = True
    s.font.color.rgb = RGBColor(0x1a, 0x1a, 0x2e)

# ── Helper ──
def img(filename, width=Inches(6.2)):
    path = os.path.join(SCR, filename)
    if not os.path.exists(path):
        doc.add_paragraph(f"[图片缺失: {filename}]")
        return False
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run()
    run.add_picture(path, width=width)
    p2 = doc.add_paragraph()
    p2.alignment = WD_ALIGN_PARAGRAPH.CENTER
    cap = p2.add_run(f"图：{filename.replace('.png','').replace('_',' ')}")
    cap.font.size = Pt(9)
    cap.font.color.rgb = RGBColor(0x88, 0x88, 0x88)
    return True

def h1(t): doc.add_heading(t, level=1)
def h2(t): doc.add_heading(t, level=2)
def h3(t): doc.add_heading(t, level=3)
def p(t, bold=False):
    r = doc.add_paragraph().add_run(t); r.bold = bold; return r
def bullet(items):
    for item in items: doc.add_paragraph(item, style="List Bullet")
def table(headers, rows):
    t = doc.add_table(rows=1+len(rows), cols=len(headers))
    t.style = "Table Grid"
    for i, h in enumerate(headers): t.rows[0].cells[i].text = h
    for ri, row in enumerate(rows):
        for ci, val in enumerate(row): t.rows[ri+1].cells[i].text = str(val)

# ══════════════════════════════════════
# TITLE PAGE
# ══════════════════════════════════════
for _ in range(3): doc.add_paragraph()
t = doc.add_paragraph(); t.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = t.add_run("RepLab v2.2\n界面操作手册"); run.font.size = Pt(28); run.bold = True; run.font.color.rgb = RGBColor(0x07,0x13,0x1c)
t2 = doc.add_paragraph(); t2.alignment = WD_ALIGN_PARAGRAPH.CENTER
r2 = t2.add_run("\nNetwork Representation Research Lab\n论文挑战模式 · 科研叙事实验平台"); r2.font.size = Pt(14); r2.font.color.rgb = RGBColor(0x55,0xc8,0x92)
t3 = doc.add_paragraph(); t3.alignment = WD_ALIGN_PARAGRAPH.CENTER
t3.add_run("\n━━━━━━━━━━━━━━━━━━━━\n").font.color.rgb = RGBColor(0x31,0xc3,0xd9)
meta = doc.add_paragraph(); meta.alignment = WD_ALIGN_PARAGRAPH.CENTER
m = meta.add_run("适用版本：story-20260816-v2.1 | 访问地址：http://localhost:3100\n设计理念：一个 10–15 分钟的科研叙事，连续 6 个实验卡 + 1 个 Epilogue，两次认知反转")
m.font.size = Pt(10); m.font.color.rgb = RGBColor(0x86,0xa7,0xb4)
doc.add_page_break()

# ══════════════════════════════════════
# 一、界面总览
# ══════════════════════════════════════
h1("一、界面总览")
p("整个工作区是一个 CSS Grid 四行/三列布局（有 Ribbon 时为四行），从上到下、从左到右依次是：")
img("01_landing_case01.png", Inches(6.5))
p("▲ 图 1-1：完整工作区（Case-01 默认视图）", bold=True)

h2("1.1 布局结构")
layout_text = """\
┌──────────────────────────────────────────────────────────────┐
│  [① 故事导航 Ribbon]  01 可疑的 0.999 › 02 共同最小值 › …   │  ← 仅「研究案例」模式显示
├──────┬───────────────────────────────────┬───────────────────┤
│      │  [② 命令栏 Command Bar]           │                   │
│      │  [研究案例|自由实验] 数据集 关系 q  │                   │
│  ③   │  ▶运行 PinA 比较A/B 论文基线 导出  │       ⑤          │
│ 左侧 │                                   │    右侧           │
│ 实验 ├───────────────────────────────────┤  结论与证据        │
│ 控制 │  [④ 中央实验区 Center Lab]         │                   │
│ Rail │  ┌─────────────┬──────────────┐   │  · 来源标签        │
│      │  │ 研究问题     │ Suggested    │   │  · 临时结论(三选一)│
│      │  │ KPI 卡片 ×4  │ next probe   │   │  · 当前证据卡片栈  │
│      │  ├─────────────┴──────────────┤   │  · 解释边界        │
│      │  │ [实验画布]    │ [参数变更]   │   │  · Reviewer 审查  │
│      │  │ (5层Tab切换)  │ A/B比较      │   │                   │
│      │  └─────────────┬──────────────┘   │                   │
├──────┴────────────────┴──────────────────┴───────────────────┤
│  [⑥ 实验历史托盘 Run Tray]                                     │
│  R01·A  R02  R03 ...  |  [快速实验按钮组]                      │
└──────────────────────────────────────────────────────────────┘"""
code_p = doc.add_paragraph()
run = code_p.add_run(layout_text.strip())
run.font.name = "Consolas"; run.font.size = Pt(8)

h2("1.2 六大专区功能定位")
table(
    ["编号", "区域名称", "DOM 类名", "核心职责"],
    [
        ["①", "故事导航", ".storyRibbon", "7 个幕的快速跳转与完成标记"],
        ["②", "命令栏", ".commandBar", "模式切换 + 参数选择 + 运行/Pin/导出"],
        ["③", "左侧控制台", ".labRail", "Representation 选择 / Population / Top-K / Stress 控制"],
        ["④", "中央实验区", ".centerLab", "研究问题标题 + KPI 指标卡 + 五层证据可视化 + A/B 比较"],
        ["⑤", "右侧证据栏", ".evidenceRail", "来源证明 + 临时结论选择 + 证据卡片栈 + 解释边界 + Reviewer"],
        ["⑥", "底部托盘", ".runTray", "运行历史 chip 流 + 快捷实验入口"],
    ]
)

# ══════════════════════════════════════
# 二、各区域详解
# ══════════════════════════════════════
h1("二、各区域详解")

h2("2.1 ① 故事导航 Ribbon")
p("仅在「研究案例」模式下可见。一行胶囊形按钮，用 › 箭头连接七个幕：")
p("01 可疑的 0.999 › 02 共同最小值 › 03 活跃层差异 › 04 Top-K › 05 敏感性 › 06 Null › 07 Epilogue")
img("z_ribbon.png", Inches(6))
p("▲ 图 2-0：Ribbon 七幕导航 —— 当前激活幕高亮，已完成幕有灰色标记", bold=True)
bullet([
    "当前激活：青色底 + 青色边框 + 白字 —— 正在操作的幕",
    "已完成：灰蓝色文字 —— 历史记录中已存在该幕的运行结果",
    "未触达：默认暗色 —— 尚未运行过",
])
p("点击任意幕 → 自动灌入预设参数 → 自动运行。幕后编号与标签对照见第三节。")

h2("2.2 ② 命令栏 Command Bar")
p("位于 Ribbon 下方。包含以下元素：")
img("z_commandbar.png", Inches(5.5))
p("▲ 图 2-1a：命令栏 —— 模式切换 + 数据集/关系/q 选择 + 6 个操作按钮", bold=True)

h3("(A) 模式切换器")
p("「研究案例」（Guided Case）：默认模式，显示 Ribbon 和 Case 列表，每次切幕自动灌参数。")
p("「自由实验」（Free Lab）：隐藏 Ribbon 和 Case 列表，所有参数手动控制，底部变为纯实验历史流 R01/R02/R03…。")

h3("(B) 数据集 / 关系 / 阶数选择")
p("数据集下拉（shipbuilding / movielens_1997_q4 / dblp）、关系下拉（APPLIES / PROVIDES）、阶数 q 下拉。切换数据集时自动联动关系和 q。")

h3("(C) 操作按钮组")
table(
    ["按钮", "文本", "功能", "启用条件"],
    [
        ["主运行", "▶ 运行实验 *", "POST /experiment/run 并刷新中央区", "始终启用（* 表示参数已改未运行）"],
        ["Pin A", "Pin A", "固定当前结果为比较基线 A", "必须有运行结果"],
        ["比较 A/B", "比较 A/B", "展开右侧 diff 视图", "必须 Pin 了 A 且当前 ≠ A"],
        ["论文基线", "论文基线", "一键回到 Case-01 配置", "始终启用"],
        ["导出", "导出", "下载 JSON（A/B+claim+review+history）", "始终启用"],
    ]
)

h2("2.3 ③ 左侧实验控制台")
img("z_leftrail.png", Inches(4.5))
p("▲ 图 2-1b：左侧实验控制台 —— 对象与表示 / 实验变量 / Research Case 列表", bold=True)
p("分为三个控制组：")

h3("(A) 对象与表示")
bullet([
    "Representation A：锁定 degree k（不可改）",
    "Representation B：锁定 provenance P₂（不可改）",
    "实验模式：「论文证据」（paper，从论文聚合统计取数）/「公开压力测试」（stress，实时计算）",
])

h3("(B) 实验变量")
bullet([
    "Population 分段按钮：Full（675 家企业，ρ≈0.9994）/ Active（52 家企业，ρ≈0.7155）",
    "Top-K 下拉：5 / 10 / 20",
    "Scenario（仅 stress）：完全反向 / 微型网络",
    "z 滑块（仅 stress）：0–1000，注入共同严格最小值数量",
    "Null evidence 复选框：启用 Robustness 层（Monte Carlo p-value）",
])

h3("(C) Research Case 列表")
p("仅研究案例模式显示。列出 7 个幕，点击 = 点击 Ribbon 同名按钮 = 灌入预设参数并自动运行。")

h2("2.4 ④ 中央实验区")
p("自上而下三层：研究问题头部 → KPI 指标卡 → 实验画布（五层 Tab + 右侧辅助面板）。")

h3("研究问题头部")
bullet([
    "元信息行：RESEARCH CASE XX / FREE LAB + 来源徽章（论文结果/现场计算/公开数据）",
    "h1 标题：幕标题",
    "问题陈述：该幕的核心科研问题",
    "Suggested next probe：仅 Guided 模式，每幕不同的下一步探索建议",
])

h3("KPI 指标卡")
p("根据当前幕 emphasis 字段动态显示最多 4 张卡片。各幕对照：")
table(
    ["幕", "KPI 1", "KPI 2", "KPI 3", "KPI 4"],
    [
        ["01", "总体 N = 675", "全体 Spearman = 0.9994", "—", "—"],
        ["02", "活跃对象 = 52", "共同最小值 = 623", "占比 = 92.30%", "活跃 Spearman = 0.7155"],
        ["03", "活跃 Spearman", "全局 Spearman", "Active ordering changed", "—"],
        ["04", "严格逆转率", "Top-10 Jaccard", "—", "—"],
        ["05", "活跃 Spearman", "严格逆转率", "—", "—"],
        ["06", "Observed ρ", "Null mean", "Monte Carlo p", "Retained graphs"],
    ]
)

h3("五层 Tab 切换")
table(
    ["Tab", "内部 ID", "显示内容", "何时可用"],
    [
        ["Coverage", "coverage", "总体构成条形图（Active vs CM 三元分解）+ 大数字", "始终"],
        ["Association", "association", "Full ρ → Active ρ 对比 + CM 占比", "始终（默认）"],
        ["Decision", "decision", "严格逆转率 + Top-K Jaccard", "始终"],
        ["Semantics", "semantics", "ΣP₂ / ΣS₂ / ΣM₂ 语义表示总量", "后端返回时"],
        ["Robustness", "null", "MC 区间 + Observed + p-value", "Null 启用时"],
    ]
)

h3("主视图（按模式分支）")
p("Paper + Association（默认）：Full ρ 0.9994 → Active ρ 0.7155 大数字对比 + CM 占比。")
img("02_coverage_case01.png", Inches(5.5))
p("▲ 图 2-1：Coverage Tab —— 揭示 92.30% 的共同最小值才是 0.999 的真正来源", bold=True)

p("Stress 模式（公开压力测试）：左半 Recharts 折线图（z vs global ρ）+ 右半 SVG 二部图 RankLinksView（5 节点 rank 置换连线）+ Invariant 徽章。")
img("04_case03_stress.png", Inches(5.5))
p("▲ 图 2-2：Stress 模式 —— z 滑至 500 时全局 ρ 从 -1 升向 1，但活跃排序不变（invariant 徽章）", bold=True)

h3("右侧辅助面板（参数变更 / A/B 比较）")
p("默认状态提示「先运行基线并 Pin A」。开启 A/B 比较后展示：改动的参数列表 + 可比指标增量 Δ + 多条件同时改变时的边界警告。")
img("03_case02_active_compare.png", Inches(5.5))
p("▲ 图 2-3：A/B 比较视图 —— Pin A(Full) 后切 Active 运行 B，右侧展示 population 差异与指标变化", bold=True)

h2("2.5 ⑤ 右侧结论与证据栏")
img("z_evidencerail.png", Inches(4.5))
p("▲ 图 2-4a：右侧证据栏 —— 五个区块自上而下排列", bold=True)
p("自上而下五个区块：来源证明 → 临时结论 → 证据卡片栈 → 解释边界 → Reviewer。")

h3("(A) 来源证明 SourceBadge")
p("颜色编码：论文结果（深蓝底浅蓝字）/ 现场计算（深绿底青绿字）/ 公开数据（深紫底淡紫字）。悬浮 title 显示第三层数据来源说明。下方动态生成中文结论叙述（按 population/mode 不同而变化）。")

h3("(B) 临时结论（三选一）")
bullet([
    "可以替代（replace）—— 认为 degree 与 P₂ 可互换",
    "不可以替代（not_replace）—— 认为二者不可互换",
    "证据不足（insufficient，默认）—— 认为当前证据不足以判断",
])

h3("(C) 当前证据卡片栈")
p("每张卡片两行：上层证据层标签（Coverage/Association/Decision/Semantics/Robustness），下层具体数值。最多 4 张。")

h3("(D) 解释边界")
p("金黄色边框提醒「不要过度外推」。内容由后端 boundaries 数组动态返回。")

h3("(E) Reviewer 审查")
p("提交后返回三个区块：允许的表述（绿色）/ 被拒绝的表述（红色）/ 未决问题（灰色）。底部 muted 小字为证据范围免责声明。")
img("06_case06_null_reviewer.png", Inches(5.5))
p("▲ 图 2-4：Case-06 Null 层 + Reviewer 结果 —— Robustness Tab 显示 MC 区间与 p≈0.1055，Reviewer 给出审查意见", bold=True)

h2("2.6 ⑥ 底部实验历史托盘")
img("z_runtray.png", Inches(5.5))
p("▲ 图 2-5：底部实验历史托盘 —— chip 流 + 清空确认 + 快速实验按钮", bold=True)
p("三栏布局：[标题列] [chip 流式区] [快速实验按钮]。每个 chip 显示 RXX 序号 + 关系/q/总体 + 按 population 对应的 Spearman 头条。支持 Pin 标记（紫色竖条）、点击回灌、清空历史（两步确认）。快速实验按钮提供 6 种常用参数一键设置。")

# ══════════════════════════════════════
# 三、六幕叙事走读
# ══════════════════════════════════════
h1("三、六幕叙事走读 —— 两次认知反转")

p("以下是按照设计稿定义的 Challenge 01–06 + Final 完整操作流程。每一步都标注具体要点哪个 UI 元素。前置条件：打开页面后 Case-01 自动加载并运行。")

h2("Challenge 01：你相信 0.999 吗？")
p("设计意图：页面先只给 675 和 0.999412，让学生先做判断。「Degree 和 P₂ 是否基本等价？」")
bullet([
    "观察 KPI 卡片：全体 Spearman = 0.9994 / 总体 N = 675",
    "看 Association 视图：Full 0.9994 → Active 0.7155",
    "在右侧「你的临时结论」里做一个选择（此时直觉可能选「可以替代」）",
    "阅读 Suggested next probe → 点击 Coverage Tab → 看到 Active 只占 7.7%，CM 占 92.3%",
])
p("教学要点：0.999 这个数字本身不解释任何东西——关键是谁在贡献它。")

h2("Challenge 02：谁在制造 0.999？")
p("设计意图：打开 Coverage，623/675 突然显示出来。亲手把 Population 从 Full 切到 Active，观察相关下降。")
bullet([
    "点击 Ribbon 「02 共同最小值」→ 参数自动灌入并运行",
    "观察 KPI：活跃对象=52 / 共同最小值=623 / 占比=92.30% / 活跃 Spearman=0.7155",
    "Pin 当前结果为 A（命令栏 Pin A 按钮）",
    "只改一个条件：Population Full → Active",
    "点 ▶ 运行实验 → 生成 R02（chip 显示 Active Spearman=0.715480）",
    "点击「比较 A/B」→ 右侧展开参数变更 + 可比指标",
])
p("教学要点：623 个共同最小值（占 92.30%）才是 0.999 的真正来源。聚焦 52 家活跃企业后 ρ 断崖跌到 0.7155。")

h2("Challenge 03：事实真的改变了吗？")
p("设计意图：左边 global correlation 在变，右边 52 个 active ranking 一根线都没动。第一次真正「看见」论文定理。")
bullet([
    "点击 Ribbon 「03 活跃层差异」→ 自动切换到 stress 模式 + active 总体 + z=0",
    "主视图出现：左侧共同最小值压力曲线 + 右侧 Active rank links 二部图",
    "将 z 滑块从 0 拖到 100 / 500 / 1000 → 全局 ρ 从 -1 升向 1",
    "Invariant 徽章始终显示 Active ordering changed: NO",
])
p("教学要点：增加共同最小值可任意操纵全局 ρ，但活跃层排序完全不受影响。全局 ρ 是假象，活跃层 ρ 才是真实信号。")

h2("Challenge 04：如果我要选前 10 家呢？")
p("设计意图：切到 Decision view。不是再给一个 ρ，而是两份 Top-10 名单摊开，Jaccard = 0.375。")
bullet([
    "点击 Ribbon 「04 Top-K」→ 回到 paper 模式 + active 总体",
    "确保 Top-K = 10，点击 Decision Tab",
    "看到：严格逆转率 17.41% / Top-10 Jaccard 0.375",
    "尝试切换 Top-K 为 5 和 20，观察 Jaccard 变化",
])
img("05_case04_decision.png", Inches(5.5))
p("▲ 图 3-1：Decision Tab —— 即使忽略 Spearman 的欺骗性，Top-10 名单重叠度不到 38%", bold=True)

h2("Challenge 05：那高阶网络是不是更厉害？")
p("设计意图：故意设置的第二个陷阱。换 PROVIDES / q=3 / q=4，现象仍然存在。排除巧合解释。")
bullet([
    "点击 Ribbon 「05 敏感性」→ 自动设为 paper 模式 + Population 切到 Active + APPLIES q=2（Association 卡显示 active ρ = 0.715480）",
    "按 Suggested probe 一次只改一个条件：Relation APPLIES→PROVIDES → 回 APPLIES → q=2→3→4",
    "每次运行后观察 Association 卡：全局 ρ 与 active ρ（活跃总体 Spearman）的差异",
])
img("08_case05_sensitivity.png", Inches(5.5))
p("▲ 图 3-2：敏感性测试 —— 保持 Population=Active，切到 PROVIDES 关系后，活跃总体 Spearman（active ρ）进一步降至 0.5987（低于 APPLIES 的 0.715480），现象不因关系类型消失，反而更突出", bold=True)

h2("Challenge 06：不同，不等于「异常」")
p("设计意图：开启 Null 出现第二次反转。再用 Reviewer 审查过度结论。")
bullet([
    "点击 Ribbon 「06 Null」→ 自动勾选 Null evidence 复选框",
    "点击 Robustness Tab → 查看 MC 区间 (2.5% / mean / 97.5%) + Observed + p ≈ 0.1055",
    "关键解读：p > 0.05 意味着在零假设下观察到这样的活跃层差异并不异常",
    "在右侧选择临时结论 → 点击「提交一句话给 Reviewer 审查」",
    "Reviewer 返回：过度推断被降级；未决问题保留",
])
p("教学要点：第二次反转——活跃层确实不同（第一次反转），但这种不同不一定意味着异常高阶组织（第二次反转把过度推断拉回来）。")

h2("Final：你现在敢怎么写结论？")
p("给三句话让学生选。正确答案显然是第 3 句——前两句都犯了单一数字过度推断的错误：")
bullet([
    '"两种表示等价；" ← 过度推断',
    '"高阶表示显著优于 Degree；" ← 过度推断',
    '"全局高一致受到共同最小值影响，但活跃层存在差异，且当前 null evidence 不支持异常高阶组织。" ✓',
])
p("最终步骤：回顾全部 6 次 chip → 逐个点击回顾 → 最终确定临时结论 → 最后一次提交 Reviewer → 导出 JSON。")

h2("Epilogue（第 7 幕）：跨域迁移")
p("MovieLens 与 DBLP 解释为什么 population construction 本身就是 estimand 的一部分。这是 bounded transferability，不是 universal validation。")

# ══════════════════════════════════════
# 四、自由实验模式
# ══════════════════════════════════════
h1("四、自由实验模式 Free Lab")

p("切换到「自由实验」后的变化：")
table(
    ["元素", "Guided Case", "Free Lab"],
    [
        ["Ribbon 导航", "显示 7 个幕", "隐藏"],
        ["Case 列表", "显示", "隐藏"],
        ["中央标题", "幕标题 + 问题", "固定「自由实验」+ 引导语"],
        ["Suggested probe", "显示", "不显示"],
        ["所有参数", "幕预设灌入", "完全手动"],
        ["底部托盘", "关联幕 ID", "纯实验历史流 R01/R02/R03…"],
]
)
img("07_free_lab.png", Inches(5.5))
p("▲ 图 4-1：Free Lab 模式 —— Ribbon 和 Case 列表隐藏，所有参数手动调节", bold=True)
p("典型工作流：默认加载 Case-01 → 运行 R01 → Pin R01 为 A → 只改 Population → 跑 R02 → 页面直接回答 What changed? 这就是「调试实验」的感觉。")

# ══════════════════════════════════════
# 五、交互元素索引
# ══════════════════════════════════════
h1("五、交互元素索引")

table(
    ["#", "UI 元素", "位置", "类型", "触发效果"],
    [
        ["1", "Ribbon 幕按钮", "①顶部", "button", "applyMission → 灌参数+auto-run"],
        ["2", "模式切换", "②最左", "button pair", "setSessionMode → 显隐 Ribbon"],
        ["3", "数据集下拉", "②", "select", "切 dataset → 联动 relation+q"],
        ["4", "关系下拉", "②", "select", "切 relation → 联动 q"],
        ["5", "阶数 q 下拉", "②", "select", "切 q"],
        ["6", "▶ 运行实验", "②", "button", "run() → POST /experiment/run"],
        ["7", "Pin A", "②", "button", "pinCurrent() → 固定基线"],
        ["8", "比较 A/B", "②", "button", "setShowCompare(true)"],
        ["9", "论文基线", "②", "button", "resetBaseline() → 回 Case-01"],
        ["10", "导出", "②", "button", "exportRun() → 下载 JSON"],
        ["11", "Representation A/B", "③左侧", "select disabled", "锁定不可改"],
        ["12", "实验模式", "③左侧", "select", "paper ↔ stress"],
        ["13", "Population", "③左侧", "seg button", "Full ↔ Active"],
        ["14", "Top-K", "③左侧", "select", "5/10/20"],
        ["15", "Scenario/z/Null", "③左侧(stress)", "select/range/check", "stress 专属控件"],
        ["16", "Research Case", "③左侧(Guided)", "button list", "同 #1"],
        ["17", "五层 Tab", "④中央", "button group", "setLayer() → 切主视图"],
        ["18", "临时结论三选一", "⑤右侧", "button group", "setClaim()"],
        ["19", "提交 Reviewer", "⑤右侧", "button", "runReview() → POST /review/run"],
        ["20", "运行历史 chip", "⑥底部", "button", "restoreRun(r) → 回灌参数"],
        ["21", "清空历史", "⑥底部", "button (两步)", "清空 history+Pin"],
        ["22", "快速实验按钮×6", "⑥底部", "button", "一键设常用参数组合"],
    ]
)

# ══════════════════════════════════════
# 六、验收对齐
# ══════════════════════════════════════
h1("六、验收对齐")

p("本手册描述的界面行为与以下文档保持一致：")
bullet([
    "《RepLab_UI锁稿与开发设计_v2.2.docx》—— 布局规格（Grid 四行/三列）、Ribbon 七幕、五层 Tab",
    "《RepLab_v2.2_理想操作说明与开发验收手册.docx》—— 50 项 API 断言（N=675 ρ=0.999412 / Active 52 ρ=0.71548 / CM=623 92.30% / p=0.1055）",
    "设计稿 Image 1 —— 六幕 Challenge 叙事结构 + Final 三句话",
    "设计稿 Image 2 —— 两次反转的认知设计",
    "设计稿 Image 3 —— Guided Case / Free Lab 双模式 + ExperimentConfig→RunSnapshot→EvidenceRecord 主干",
    "设计稿 Image 4 —— 七步故事收成（Pin A/B / Coverage 揭示 / stress test / Top-K / sensitivity / Null / Epilogue）",
])

# ══════════════════════════════════════
# SAVE
# ══════════════════════════════════════
doc.save(DOCX)
print(f"DONE: {DOCX}")
