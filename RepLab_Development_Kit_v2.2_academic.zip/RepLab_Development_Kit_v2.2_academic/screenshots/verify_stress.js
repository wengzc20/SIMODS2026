const puppeteer = require("puppeteer-core");
const CHROME = "C:\\Users\\Administrator\\.cache\\puppeteer\\chrome\\win64-148.0.7778.167\\chrome-win64\\chrome.exe";

const SETTER = `(el, value) => {
  const proto = el.tagName === "SELECT" ? HTMLSelectElement.prototype : HTMLInputElement.prototype;
  const setter = Object.getOwnPropertyDescriptor(proto, "value").set;
  setter.call(el, value);
  el.dispatchEvent(new Event("input", { bubbles: true }));
  el.dispatchEvent(new Event("change", { bubbles: true }));
}`;

(async () => {
  const browser = await puppeteer.launch({
    executablePath: CHROME,
    headless: "new",
    args: ["--no-sandbox", "--disable-setuid-sandbox", "--disable-gpu"],
  });
  const page = await browser.newPage();
  await page.setViewport({ width: 1600, height: 1000, deviceScaleFactor: 1.5 });
  page.on("console", (m) => { if (m.type() === "error" && !m.text().includes("404")) console.log("PAGE-ERR:", m.text()); });

  await page.goto("http://localhost:3100", { waitUntil: "networkidle0", timeout: 60000 });
  await page.waitForSelector("main", { timeout: 30000 });
  await new Promise((r) => setTimeout(r, 800));

  await page.evaluate(() => {
    const b = [...document.querySelectorAll("button")].find((x) => x.textContent.includes("Free Lab"));
    if (b) b.click();
  });
  await new Promise((r) => setTimeout(r, 800));

  const modeSet = await page.evaluate((setterSrc) => {
    const setNative = eval("(" + setterSrc + ")");
    const s = [...document.querySelectorAll("select")].find((x) => [...x.options].some((o) => o.value === "stress"));
    if (!s) return false;
    setNative(s, "stress");
    return true;
  }, SETTER);
  console.log("mode=stress set:", modeSet);
  await new Promise((r) => setTimeout(r, 600));

  async function setZandRun(z, file) {
    await page.evaluate((setterSrc, zz) => {
      const setNative = eval("(" + setterSrc + ")");
      const r = document.querySelector('input[type="range"]');
      setNative(r, String(zz));
    }, SETTER, z);
    await new Promise((r) => setTimeout(r, 400));
    const clicked = await page.evaluate(() => {
      const b = [...document.querySelectorAll("button")].find((x) => x.textContent.includes("运行实验"));
      if (b) { b.click(); return true; }
      return false;
    });
    console.log(`z=${z} run clicked:`, clicked);
    await new Promise((r) => setTimeout(r, 2500));
    await page.screenshot({ path: file });
  }

  await setZandRun(100, "verify_stress_z100.png");
  await setZandRun(900, "verify_stress_z900.png");

  await browser.close();
  console.log("DONE");
})().catch((e) => { console.error("FATAL", e); process.exit(1); });
