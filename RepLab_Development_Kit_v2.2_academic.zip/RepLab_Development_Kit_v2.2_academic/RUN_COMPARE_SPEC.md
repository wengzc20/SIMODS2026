# Run / Compare / Reproducibility Specification v2.1

## 1. Core types

### ExperimentConfig
Scientific controls only. Do not include presentation state.

```ts
export type ExperimentConfig = {
  datasetId: string;
  relation: string;
  q: number;
  representationA: "k" | "P2" | "S2";
  representationB: "k" | "P2" | "S2";
  population: "full" | "active" | "eligible";
  mode: "paper" | "stress";
  stressScenario?: "micro" | "reversed";
  z?: number;
  topK: number;
  nullEnabled: boolean;
};
```

### RunSnapshot

```ts
export type RunSnapshot = {
  runId: string;
  createdAt: string;
  storyMissionId?: string;
  config: ExperimentConfig;
  availability: Record<string, boolean>;
  population: Record<string, unknown>;
  metrics: Record<string, unknown>;
  evidenceIds: string[];
  boundaries: string[];
  sourceVersion: string;
  sourceKind: "paper_aggregate" | "public_deterministic";
};
```

### RunDiff

```ts
export type RunDiff = {
  fromRunId: string;
  toRunId: string;
  changedParameters: Array<{key:string; from:unknown; to:unknown}>;
  comparableMetrics: Array<{key:string; from:number; to:number; delta:number}>;
  warnings: string[];
};
```

## 2. Comparison safety

Do not show a numeric delta as if it were a controlled experiment when multiple scientific dimensions changed.

If more than one of `dataset, relation, q, population, representation` changes, add:

> Multiple scientific conditions changed. Treat this as a descriptive comparison, not an isolated parameter effect.

Null p-values are not comparable to coverage deltas. Decision metrics are not automatically null-tested.

## 3. Reproducibility metadata

Every RunSnapshot exposes:
- source file/version;
- whether values were computed from public deterministic data or loaded from manuscript aggregate lock;
- random seed where applicable;
- statement that APPLIES row-level data are not included.

## 4. Persistence for the two-week build

Use browser `localStorage` for the run tray. No database required.

Key:
`replab.runSnapshots.v2`

Limit:
20 runs; evict oldest non-pinned run first.

## 5. Export

Export a single JSON containing:
- schema_version
- app_version
- pinned_run_A
- current_run_B
- run_diff
- evidence references
- user provisional claim
- reviewer result, if run

This export becomes the compatibility bridge to the future Research Notebook.
