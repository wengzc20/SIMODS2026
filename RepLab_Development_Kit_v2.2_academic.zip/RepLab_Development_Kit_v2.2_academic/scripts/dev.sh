#!/usr/bin/env bash
set -e
echo "Backend: cd backend && python -m venv .venv && source .venv/bin/activate && pip install -e '.[dev,agents]' && uvicorn app.main:app --reload --port 8000"
echo "Frontend: cd web && cp -n .env.local.example .env.local || true; npm install; npm run dev"
