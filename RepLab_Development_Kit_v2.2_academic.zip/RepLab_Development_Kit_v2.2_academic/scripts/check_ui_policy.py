from pathlib import Path
root=Path(__file__).resolve().parents[1]
ws=(root/'web/components/ExperimentWorkspace.tsx').read_text(encoding='utf-8')
source=(root/'web/components/SourceBadge.tsx').read_text(encoding='utf-8')
assert 'SourceBadge' in ws
# 用户界面只显示人能读懂的来源标签，不直接暴露内部 provenance 枚举
assert '论文结果' in source
assert '现场计算' in source
# 开发自证语言（数据保密说明、内部枚举）不得出现在用户可见的渲染路径
assert '本页不会伪造' not in ws
assert 'not a reconstruction of confidential APPLIES active vectors' not in ws
assert 'SOURCE UNKNOWN' not in ws
print('UI source-policy check: PASS')
