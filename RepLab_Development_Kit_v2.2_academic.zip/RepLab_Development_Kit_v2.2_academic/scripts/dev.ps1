Write-Host "Start backend in one terminal:"
Write-Host "  cd backend; python -m venv .venv; .\\.venv\\Scripts\\Activate.ps1; pip install -e '.[dev,agents]'; uvicorn app.main:app --reload --port 8000"
Write-Host "Start frontend in another terminal:"
Write-Host "  cd web; Copy-Item .env.local.example .env.local -ErrorAction SilentlyContinue; npm install; npm run dev"
