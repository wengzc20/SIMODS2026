from pathlib import Path
import csv,json,math,sys
ROOT=Path(__file__).resolve().parents[1]
SEED=ROOT/"data"/"seed"
LOCK=json.loads((ROOT/"data"/"paper_numbers.lock.json").read_text(encoding="utf-8"))
STORY=json.loads((ROOT/"data"/"story_missions.json").read_text(encoding="utf-8"))

def rows(name):
    with (SEED/name).open("r",encoding="utf-8-sig",newline="") as f:return list(csv.DictReader(f))

errors=[]
ents={r['entity_id'] for r in rows('entities.csv')}; ctx={r['context_id'] for r in rows('contexts.csv')}
for r in rows('affiliations.csv'):
    if r['entity_id'] not in ents: errors.append(f"unknown entity {r['entity_id']}")
    if r['context_id'] not in ctx: errors.append(f"unknown context {r['context_id']}")
for r in rows('micro_expected_metrics.csv'):
    if int(r['M2']) != int(r['P2'])-int(r['S2']): errors.append(f"M2 mismatch {r['entity_id']}")
agg=json.loads((SEED/'shipbuilding_public_aggregates.json').read_text(encoding='utf-8'))
s=LOCK['shipbuilding_applies_q2']
for key,ak in [('N','universe_N'),('active_N','active_N'),('common_minimum_N','common_minimum_N'),('global_spearman','global_spearman'),('active_spearman','active_spearman')]:
    if agg[key]!=s[ak]: errors.append(f"aggregate/lock mismatch {key}: {agg[key]} != {s[ak]}")
if round(LOCK['null_model_applies_q2']['plus_one_two_sided_p'],4)!=0.1055: errors.append('null p display mismatch')
if STORY.get('source_lock') != LOCK.get('lock_version'): errors.append('story source_lock does not match paper lock')
if len(STORY.get('missions',[])) != 7: errors.append('guided story must contain 7 cases including epilogue')
ids=[m.get('id') for m in STORY.get('missions',[])]
if len(ids)!=len(set(ids)): errors.append('duplicate story mission id')
if errors:
    print('FAIL');print('\n'.join('- '+e for e in errors));sys.exit(1)
print('PASS: data package and paper lock are internally consistent')


registry=json.loads((ROOT/'data'/'source_registry.json').read_text(encoding='utf-8'))
assert 'paper_aggregate' in registry['source_kinds']
assert registry['source_kinds']['paper_aggregate']['interactive'] is False
assert registry['source_kinds']['live_computed']['interactive'] is True
print('Source registry: PASS')
