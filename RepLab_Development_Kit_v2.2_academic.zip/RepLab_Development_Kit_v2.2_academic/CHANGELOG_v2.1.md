# RepLab v2.1 redesign — story-driven experimental companion

## Product change
- The workspace is no longer framed as a generic parameter dashboard.
- Default mode is a guided scientific case: “0.999 能证明什么？”
- Free Lab remains available and uses the same deterministic engine.
- The manuscript’s scientific reversal is now the primary UX narrative.

## Interaction change
- Added provisional user claim.
- Added Suggested Next Probe.
- Added Pin A / Compare B.
- Added RunSnapshot and experiment run tray.
- Added controlled parameter diff and “What changed?” summary.
- Bottom strip is run history; five diagnostic layers remain scientific tags/tabs.

## Scientific change
- Story explicitly separates:
  1. coverage mechanism,
  2. active/decision disagreement,
  3. semantic distinction,
  4. fixed-margin robustness,
  5. external transferability.
- Counterfactual padding is labeled analytical/deterministic, not an empirical missing-data simulation.
- Frozen null audit is restricted to APPLIES q=2 active Spearman.
- No null distributions are invented for inversion or Top-K.

## Architecture continuity
- Same Next.js / React / FastAPI / Python core.
- Existing ExperimentRequest and EvidenceRecord remain compatible.
- Added optional mission/session metadata only.
- No MCP/A2A dependency added to the two-week build.
