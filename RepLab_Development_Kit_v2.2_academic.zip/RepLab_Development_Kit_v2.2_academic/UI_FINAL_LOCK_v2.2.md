# RepLab v2.2 UI Lock Specification

Status: **LOCKED for the two-week Paper Companion build**.

This document overrides visual ambiguities in v2.1. Product/scientific behavior in `PRODUCT_SPEC.md`, `STORY_EXPERIENCE_SPEC.md`, `DATA_GUIDE.md` and `API_CONTRACT.md` remains in force.

## 1. Product identity

RepLab is a **scientific experiment workbench**, not a paper dashboard and not an agent chat room.

The first viewport must communicate three things:
1. I can change a scientific condition.
2. I can run the experiment and compare it with a previous run.
3. Every displayed result tells me whether it is paper aggregate evidence or a live recomputation.

## 2. Locked desktop shell (1600×900 reference)

- Top command bar: 64 px.
- Guided-case ribbon: 48 px below top bar.
- Left experiment rail: 280 px.
- Center canvas: fluid, target 900–960 px.
- Right evidence/reviewer rail: 300 px.
- Bottom run tray: 112 px.
- Main gaps: 12–14 px.
- Default panel radius: 12 px.
- No more than 4 headline KPI cards at once.
- No more than 2 large scientific panels at once.

At widths <1440 px, the right rail becomes a drawer. Do not compress all three columns.

## 3. Locked information hierarchy

### Top command bar
`RepLab | Guided Case / Free Lab | Dataset | Relation | q | Run | Pin A | Compare | Reset | Export`

No sprint status, agent count, model selector or development progress appears here.

### Guided-case ribbon
A horizontal scientific story ribbon:
`可疑的 0.999 → 共同最小值 → 活跃层差异 → Top-K → 敏感性 → Null → Epilogue`

Only the current and completed missions are emphasized. This is a research narrative, not a project timeline.

### Left rail: Experiment Controls
Visible controls are scientific only:
- dataset
- relation
- q
- mode (`Paper Evidence` / `Public Stress Test`)
- population
- Top-K
- Null toggle when supported
- stress scenario + z only in live-computed stress mode

At most six controls are expanded. Advanced settings remain collapsed.

### Center canvas
Order:
1. research-question card;
2. 2–4 KPI cards;
3. active scientific view;
4. A/B compare card only when A has been pinned;
5. bottom run history.

### Right rail
Order:
1. source/provenance badge;
2. evidence summary;
3. interpretation boundary;
4. Reviewer action/result.

Agents are invoked on demand. Do not show a permanent roster in the default workbench.

## 4. Source badge is mandatory

Every scientific result panel must render one of the following badges:

- `PAPER AGGREGATE`
- `LIVE COMPUTED`
- `PUBLIC DATA SUMMARY`
- future `LIVE PUBLIC DATA`

The badge must be visible without opening a tooltip.

### `PAPER AGGREGATE`
Displayed from `data/paper_numbers.lock.json`. It is not recomputed from APPLIES row-level data.

### `LIVE COMPUTED`
Recomputed by `backend/app/core/*` from synthetic/public inputs supplied in the development kit.

## 5. Data-honesty visualization rules

### Shipbuilding APPLIES in Paper Evidence mode
Allowed:
- N / active / common-minimum aggregate cards;
- common-minimum population bar/donut;
- full vs active Spearman comparison;
- delta-rho;
- inversion percentage;
- Top-5/10/20 Jaccard bars;
- P2/S2/M2 aggregate totals;
- relation and q sensitivity using manuscript aggregate values;
- null quantile interval with observed marker, null mean, p, chains, ESS.

Forbidden:
- company-level scatterplot;
- named company Top-K table;
- active entity rank-link diagram presented as APPLIES data;
- per-company tooltips;
- null histogram unless actual retained null samples are added to the package.

### Public Stress Test
Allowed and encouraged:
- z slider;
- padding curve recomputed live;
- active rank links from synthetic vectors;
- `Active ordering changed: NO` invariant;
- fully reversed and micro-network scenarios.

Hard subtitle:
`Public deterministic theorem demo - not a reconstruction of confidential APPLIES active vectors.`

## 6. Locked two-state visual reference

The package contains:
- `design/01_ui_lock_paper_evidence.png`
- `design/02_ui_lock_live_stress.png`
- HTML sources used to render both.

The screenshots are the visual direction. If a screenshot appears to conflict with this written source/visualization policy, **this document wins**.

## 7. Guided Case state transitions

### Mission 01 - 可疑的 0.999
Show only enough evidence to create the question:
- N=675
- global Spearman=0.999412
- source = PAPER AGGREGATE
Ask user for provisional claim before revealing active result.

### Mission 02 - 623 个共同最小值
Reveal:
- active N=52
- common minimum N=623 / 92.30%
Suggested probe: Pin full-population run as A, switch Population to Active, Run B.

### Mission 03 - 只改变覆盖，不改变活跃排序
Switch to Public Stress Test.
- source = LIVE COMPUTED
- z slider active
- synthetic reversed/micro vectors only
- active rank geometry remains fixed while global Spearman changes.

### Mission 04 - Top-K
Return to Paper Evidence for APPLIES aggregate decision metrics.
- K=5/10/20 selectable
- show Jaccard value/bar, not confidential company names.

### Mission 05 - Sensitivity debugging
Relation APPLIES/PROVIDES/UNION and q=2/3/4 where supported.
Warn when more than one scientific dimension changed between A and B.

### Mission 06 - Different != exceptional
Enable frozen APPLIES q=2 null evidence.
Show quantile interval and observed marker; do not fabricate a sampled distribution.
Reviewer rejects overclaims.

### Mission 07 - Epilogue
Use MovieLens and DBLP aggregate/public summaries to show why population construction matters.

## 8. Run/compare behavior

- Parameter edit -> dirty state.
- `Run` -> immutable `RunSnapshot`.
- `Pin A` pins one snapshot.
- Current successful run becomes B.
- Compare shows exact config diff first, metric deltas second.
- If >1 scientific dimension differs, show amber warning: `Multiple scientific conditions changed; do not attribute the difference to a single factor.`
- Run tray stores at least 20 snapshots client-side in P0.

## 9. Density and animation

- animations 150–250 ms;
- no neon pulsing;
- do not animate KPI numbers continuously;
- padding curve updates smoothly only in LIVE COMPUTED mode;
- when Guided mode advances, controls that become relevant may highlight once, then return to normal.

## 10. Definition of visual done

The P0 UI is visually complete only when:
- the first viewport feels like an experiment instrument;
- the user can identify the variable they can change within 5 seconds;
- `PAPER AGGREGATE` vs `LIVE COMPUTED` is never ambiguous;
- APPLIES paper mode contains no fabricated entity-level plot/table;
- the story ribbon is scientific, not project-management UI;
- the Reviewer appears as a scientific claim checker, not as the main character.
