# Data dictionary

- `entity_id`: stable synthetic entity identifier.
- `context_id`: stable synthetic affiliation-context identifier.
- `relation`: relation label; `DEMO` in the synthetic network.
- `k`: first-order entity degree.
- `P2`: provenance-counted second-order participation.
- `S2`: deduplicated second-order participation.
- `M2`: `P2-S2`, provenance multiplicity gap.
- `common_minimum_N`: entities sharing the same strict minimum in both compared representations.
- `global_spearman`: midrank Spearman over the stated full universe.
- `active_spearman`: midrank Spearman over entities active under the focal relation.
