# Public-data acquisition notes

The manuscript uses DBLP and MovieLens as external affiliation evidence. Do not redistribute their raw files inside this seed pack.

- DBLP: use the monthly snapshot specified by the submission manuscript and preserve native author-paper identity.
- MovieLens 100K: use the complete 943-user universe and retain user-movie rating contexts.

Before submission, pin download date, checksum, filters, and conversion command in the project research log.
