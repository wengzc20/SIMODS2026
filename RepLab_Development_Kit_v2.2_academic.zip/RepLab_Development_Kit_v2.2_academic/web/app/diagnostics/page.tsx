import {apiGet} from "@/lib/api";

// 五层诊断页只读锁定证据；结构由后端 diagnostic_bundle 决定，这里只做强类型读取。
type Metrics = Record<string, unknown>;
type NullStat = {
  observed_spearman: number;
  pooled_null_mean: number;
  reported_p: number;
  retained_graphs: number;
};
type DiagnosticsBundle = {
  coverage: Metrics;
  association: Metrics;
  decision: Metrics;
  semantics: Metrics;
  null: NullStat;
};

export default async function Diagnostics(){
  const d = await apiGet<DiagnosticsBundle>("/diagnostics/shipbuilding-applies-q2");
  const nl = d.null;
  return <div className="space-y-5"><h1 className="text-3xl font-semibold">五层诊断</h1><div className="grid grid-cols-5 gap-3">{["Coverage","Association","Decision","Semantics","Null"].map((x,i)=><div className="metric" key={x}><span className="text-[var(--cyan)]">0{i+1}</span><div className="mt-2 font-semibold">{x}</div></div>)}</div><section className="grid grid-cols-2 gap-4"><div className="panel p-6"><h2 className="text-xl font-semibold">Coverage</h2><pre className="muted mt-4 whitespace-pre-wrap text-sm">{JSON.stringify(d.coverage,null,2)}</pre></div><div className="panel p-6"><h2 className="text-xl font-semibold">Association</h2><pre className="muted mt-4 whitespace-pre-wrap text-sm">{JSON.stringify(d.association,null,2)}</pre></div><div className="panel p-6"><h2 className="text-xl font-semibold">Decision</h2><pre className="muted mt-4 whitespace-pre-wrap text-sm">{JSON.stringify(d.decision,null,2)}</pre></div><div className="panel p-6"><h2 className="text-xl font-semibold">Semantics</h2><pre className="muted mt-4 whitespace-pre-wrap text-sm">{JSON.stringify(d.semantics,null,2)}</pre></div></section><section className="panel p-6"><h2 className="text-xl font-semibold">Null robustness</h2><div className="mt-4 grid grid-cols-4 gap-3"><div className="metric">Observed<strong>{nl.observed_spearman.toFixed(6)}</strong></div><div className="metric">Null mean<strong>{nl.pooled_null_mean.toFixed(6)}</strong></div><div className="metric">Approx. p<strong>{nl.reported_p.toFixed(4)}</strong></div><div className="metric">Retained<strong>{nl.retained_graphs}</strong></div></div><p className="mt-5 text-sm text-[var(--amber)]">在所选固定边际采样参考集合下，观测 active Spearman 不处于极端区域；这不证明表示等价，也不证明不存在高阶机制。</p></section></div>;
}
