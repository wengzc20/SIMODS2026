import "./globals.css";import {AppHeader} from "@/components/AppHeader";
export const metadata={title:"RepLab",description:"Interactive network representation experiment workbench"};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="zh-CN"><body><AppHeader/><main>{children}</main></body></html>}
