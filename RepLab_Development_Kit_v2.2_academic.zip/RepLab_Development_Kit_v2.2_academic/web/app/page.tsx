import ExperimentWorkspace from "@/components/ExperimentWorkspace";
export default function Home(){return <ExperimentWorkspace/>}
