"use client";import {useState} from "react";import {apiPost} from "@/lib/api";

// 研究审查页只消费 Reviewer 的结构化输出，不参与任何数值计算。
type EvidenceItem = { id: string; kind: string; population: string };
type ReviewData = {
  evidence: EvidenceItem[];
  allowed_claims: string[];
  blocked_claims: string[];
  agent_outputs: unknown[];
};

export default function Review(){
  const[d,setD]=useState<ReviewData|null>(null);
  const[busy,setBusy]=useState(false);
  async function run(){
    setBusy(true);
    try{
      setD(await apiPost<ReviewData>("/review/run",{mode:"mock",case_id:"shipbuilding_applies_q2",question:"Can degree replace P2 for the current APPLIES evaluation population?"}));
    }finally{setBusy(false)}
  }
  return <div className="space-y-5"><h1 className="text-3xl font-semibold">研究审查</h1><p className="muted">Agent 只解释 EvidenceRecord；数值事实来自锁定证据或确定性工具。</p><button className="btn" onClick={run} disabled={busy}>{busy?"审查中...":"运行研究审查"}</button>{d&&<div className="grid grid-cols-[1fr_1fr] gap-4"><section className="panel p-5"><h2 className="font-semibold">Evidence Board</h2>{d.evidence.map((e)=><div className="mt-3 rounded-lg border border-[var(--border)] p-3" key={e.id}><span className="text-[var(--cyan)]">{e.id}</span><div className="muted mt-1 text-sm">{e.kind} · {e.population}</div></div>)}</section><section className="space-y-4"><div className="panel p-5"><h2 className="text-[var(--success)]">允许的表述</h2>{d.allowed_claims.map((x)=><p className="mt-2 text-sm" key={x}>• {x}</p>)}</div><div className="panel p-5"><h2 className="text-[var(--red)]">被拒绝的表述</h2>{d.blocked_claims.map((x)=><p className="mt-2 text-sm" key={x}>• {x}</p>)}</div></section><details className="panel col-span-2 p-5"><summary className="cursor-pointer">高级：Agent / trace 事件</summary><pre className="muted mt-4 overflow-auto text-sm">{JSON.stringify(d.agent_outputs,null,2)}</pre></details></div>}</div>;
}
