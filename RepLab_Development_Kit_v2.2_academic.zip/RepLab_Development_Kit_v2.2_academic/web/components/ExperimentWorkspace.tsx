"use client";

import {useEffect, useMemo, useState} from "react";
import {apiGet, apiPost} from "@/lib/api";
import {CartesianGrid, Line, LineChart, ReferenceDot, ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis} from "recharts";
import SourceBadge, { srcLabel } from "./SourceBadge";

// 实验过程中产生的数据大多是后端按证据层动态返回的字典，这里用 Json 统一定义，
// 在具体视图里再做窄化取值，避免到处写 any。
type Json = Record<string, unknown>;
type DatasetOption = {id:string;label:string;relations:string[];q:number[];relation_q?:Record<string,number[]>};
type Options = {datasets:DatasetOption[];representations:string[];metrics:string[];top_k_locked:number[];stress_scenarios:string[];source_version:string};
type Mission = {id:string;order:number;title:string;question:string;preset:Json;emphasis:string[];suggested_probe:string;layer_tags:string[];provisional_claim_required?:boolean};
type Story = {version:string;title:string;missions:Mission[]};
type Run = {
  run_id:string;
  created_at:string;
  source_kind:string;
  source_label?:string;
  source_version:string;
  story?: Json | null;
  config: Json;
  availability: Record<string,boolean>;
  population: Json;
  metrics: Json;
  evidence: Json[];
  boundaries:string[];
  provenance_note?:string[];
};
type Pad = {z:number;active_spearman:number;global_spearman:number;active_ordering_changed:boolean};
type Layer = "coverage"|"association"|"decision"|"semantics"|"null";
type ReviewData = {
  evidence:{id:string;kind:string;population:string}[];
  allowed_claims:string[];
  blocked_claims:string[];
  agent_outputs:unknown[];
  run_id?:string;
  mode?:string;
  unresolved?:string[];
};

// 故事 ribbon 用的短标签（与设计锁稿一致）。
const RIBBON_LABELS:Record<number,string> = {1:"可疑的 0.999",2:"共同最小值",3:"活跃层差异",4:"Top-K",5:"敏感性",6:"Null",7:"Epilogue"};
const PAD_PRESETS = [0,10,50,100,500,1000];
const HISTORY_KEY = "replab.runSnapshots.v2";

const metricLabels:Record<string,string> = {
  global_spearman:"全体 Spearman",
  active_spearman:"活跃 Spearman",
  gap:"Δρ",
  strict_inversion_rate:"严格逆转率",
  topk_jaccard:"Top-K Jaccard",
  null_observed:"Observed ρ",
  null_mean:"Null mean",
  null_p:"Monte Carlo p",
  null_retained:"Retained graphs",
  active_ordering_changed:"Active ordering changed",
};

// 统一格式化：比率/占比转百分比，布尔转 YES/NO，其余按数值或字符串输出。
function fmt(key:string, v:unknown){
  if(v==null) return "—";
  if(key.includes("rate") || key.includes("share")) return `${(Number(v)*100).toFixed(2)}%`;
  if(typeof v==="boolean") return v?"YES":"NO";
  if(typeof v==="number") return Math.abs(v)>=100?String(v):v.toFixed(4);
  return String(v);
}

// 运行历史 chip 头条：按总体显示对应的 Spearman。
// 验收手册 §4：R01 = Full Spearman=0.999412，R02 = Active Spearman=0.715480。
// active/eligible 总体必须突出 active_spearman，否则会被 global 的 0.9994 盖掉。
function chipHeadline(r:Run):string{
  const pop=r.config?.population;
  if((pop==="active"||pop==="eligible") && r.metrics?.active_spearman!=null)
    return `Active Spearman=${Number(r.metrics.active_spearman).toFixed(6)}`;
  if(r.metrics?.global_spearman!=null)
    return `Full Spearman=${Number(r.metrics.global_spearman).toFixed(6)}`;
  if(r.metrics?.active_spearman!=null)
    return `Active Spearman=${Number(r.metrics.active_spearman).toFixed(6)}`;
  return r.source_kind ?? "";
}

// A/B 只看真正改动的科研参数，避免把多个维度的差异归因于单一因素。
function getConfigDiff(a:Run, b:Run){
  const keys = ["dataset_id","relation","q","population","top_k","null_enabled","mode","stress_scenario","z"];
  return keys.filter(k=>a.config[k]!==b.config[k]).map(k=>({key:k, from:a.config[k], to:b.config[k]}));
}

// 界面只表达用户真正需要的两件事：这是什么性质的证据、能支持什么结论。
// 开发约束与数据保密说明属于文档层，不入用户界面。
function sourceNote(r:Run|null):string{
  if(!r) return "";
  switch(r.source_kind){
    case "paper_aggregate": return "论文中报告的聚合统计结果";
    case "live_computed": return "由当前实验参数实时计算";
    case "public_summary": case "live_public": return "论文中公开数据集的锁定聚合摘要";
    default: return "";
  }
}

// 根据运行结果动态生成中文结论叙述，避免把稿件数字硬编码进页面。
function evidenceNarrative(r:Run|null):string{
  if(!r) return "尚未运行实验。";
  const m=r.metrics ?? {};
  const p=r.population ?? {};
  const c=r.config ?? {};
  const g = m.global_spearman!=null ? Number(m.global_spearman) : null;
  const a = m.active_spearman!=null ? Number(m.active_spearman) : null;
  const gap = g!=null && a!=null ? g-a : null;
  const f4 = (x:number|null)=> x==null ? "—" : x.toFixed(4);
  const rel = String(c.relation ?? "APPLIES");
  if(r.source_kind==="paper_aggregate"){
    if(c.population==="active"){
      return `在 ${rel} 活跃企业（${p.active_N ?? "—"} 家）中，Degree 与 P2 的 Spearman 相关为 ${f4(a)}。`+
        (gap!=null ? ` 与完整总体（${f4(g)}）相比下降约 ${f4(gap)}，说明全体高相关主要由共同最小值块贡献。` : "");
    }
    return `在完整企业总体中，Degree 与 P2 的 Spearman 相关为 ${f4(g)}；在 ${rel} 活跃企业中降至 ${f4(a)}。`+
      ` 当前结果提示：总体相关性受到大量共同最小值的显著影响，不能仅依据全体相关系数判断两种表示等价。`;
  }
  if(r.source_kind==="live_computed"){
    const z = c.z!=null ? Number(c.z) : 0;
    return `当前实验追加了 z = ${z} 个共同最小值。活跃排序保持不变，而全体 Spearman 已由 −1.0000 上升至 ${f4(g)}。`;
  }
  if(r.source_kind==="public_summary" || r.source_kind==="live_public"){
    return `结果来自论文中公开数据集（${String(c.dataset_id ?? "")}）的锁定聚合统计。`;
  }
  return "尚未运行实验。";
}

export default function ExperimentWorkspace(){
  const[opts,setOpts] = useState<Options|null>(null);
  const[story,setStory] = useState<Story|null>(null);
  const[sessionMode,setSessionMode] = useState<"guided"|"free">("guided");
  const[missionId,setMissionId] = useState("case-01");
  const[data,setData] = useState<Run|null>(null);
  const[history,setHistory] = useState<Run[]>([]);
  const[pinnedId,setPinnedId] = useState<string|null>(null);
  const[dirty,setDirty] = useState(false);
  const[confirmClear,setConfirmClear] = useState(false);
  const[claim,setClaim] = useState<"replace"|"not_replace"|"insufficient">("insufficient");
  const[layer,setLayer] = useState<Layer>("association");
  const[showCompare,setShowCompare] = useState(false);
  const[error,setError] = useState<string|null>(null);

  const[dataset,setDataset] = useState("shipbuilding");
  const[relation,setRelation] = useState("APPLIES");
  const[q,setQ] = useState(2);
  const[population,setPopulation] = useState("full");
  const[topK,setTopK] = useState(10);
  const[nullEnabled,setNullEnabled] = useState(false);
  const[mode,setMode] = useState<"paper"|"stress">("paper");
  const[z,setZ] = useState(0);
  const[scenario,setScenario] = useState("reversed");
  const[curve,setCurve] = useState<{z:number;rho:number}[]>([]);

  const[review,setReview] = useState<ReviewData|null>(null);
  const[reviewBusy,setReviewBusy] = useState(false);
  const[reviewError,setReviewError] = useState<string|null>(null);

  const mission = useMemo(()=>story?.missions.find(m=>m.id===missionId)??null, [story,missionId]);
  const ds = useMemo(()=>opts?.datasets.find(x=>x.id===dataset), [opts,dataset]);
  const allowedQ = useMemo(()=>ds?.relation_q?.[relation] ?? ds?.q ?? [2], [ds,relation]);
  const pinned = useMemo(()=>history.find(r=>r.run_id===pinnedId)??null, [history,pinnedId]);
  const diff = useMemo(()=>pinned&&data&&pinned.run_id!==data.run_id?getConfigDiff(pinned,data):[], [pinned,data]);

  // ribbon 上标记“已完成”的幕：历史里出现过对应 guided 运行即视为跑过。
  const ranMissionIds = useMemo(()=>new Set(history.map(r=>{
    const s=r.story as Json|undefined;
    return typeof s?.id==="string"?s.id:null;
  }).filter(Boolean) as string[]), [history]);

  // A/B 可比指标增量（仅当两端都存在同名字段数值时计算）。
  const metricDelta = useMemo(()=>{
    if(!pinned||!data||pinned.run_id===data.run_id) return [];
    const a=pinned.metrics as Json, b=data.metrics as Json;
    const keys=["global_spearman","active_spearman","strict_inversion_rate","topk_jaccard","null_p","null_observed","null_mean"];
    const out:{key:string;from:number;to:number;delta:number}[] = [];
    for(const k of keys){
      const av=a[k], bv=b[k];
      if(typeof av==="number" && typeof bv==="number") out.push({key:k, from:av, to:bv, delta:bv-av});
    }
    return out;
  },[pinned,data]);

  // 首屏加载：拉取工作台选项与故事任务，并把第一幕作为初始配置。
  // 注意：这里的 setState 属于“外部数据同步”，是初期加载的合理用法。
  useEffect(()=>{
    Promise.all([apiGet<Options>("/workbench/options"), apiGet<Story>("/story/missions")])
      .then(([o,s])=>{setOpts(o);setStory(s)})
      .catch(e=>setError(e instanceof Error?e.message:"加载工作台失败"));
    // eslint-disable-next-line react-hooks/set-state-in-effect
    try{const raw=localStorage.getItem(HISTORY_KEY);if(raw)setHistory(JSON.parse(raw) as Run[])}catch{}
  },[]);

  useEffect(()=>{if(history.length) localStorage.setItem(HISTORY_KEY, JSON.stringify(history.slice(-20)))},[history]);

  function mark(fn:()=>void){fn();setDirty(true)}

  function applyMission(m:Mission){
    const p=m.preset;
    setMissionId(m.id);
    setDataset(typeof p.dataset_id==="string"?p.dataset_id:"shipbuilding");
    setRelation(typeof p.relation==="string"?p.relation:"APPLIES");
    setQ(typeof p.q==="number"?p.q:2);
    setPopulation(typeof p.population==="string"?p.population:"full");
    setTopK(typeof p.top_k==="number"?p.top_k:10);
    setNullEnabled(Boolean(p.null_enabled));
    setMode((typeof p.mode==="string" && (p.mode==="paper"||p.mode==="stress"))?p.mode:"paper");
    setScenario(typeof p.stress_scenario==="string"?p.stress_scenario:"reversed");
    setZ(typeof p.z==="number"?p.z:0);
    const first=m.layer_tags?.[0];
    setLayer(first==="robustness"?"null":((first as Layer)??"association"));
    setDirty(true);
  }

  async function run(){
    setError(null);
    const body={
      session_mode:sessionMode,
      story_mission_id:sessionMode==="guided"?missionId:null,
      dataset_id:dataset, relation, q,
      representation_a:"k", representation_b:"P2",
      population, mode,
      stress_scenario:mode==="stress"?scenario:null,
      z:mode==="stress"?z:null,
      top_k:topK,
      metrics:["spearman","strict_inversion","topk_jaccard"],
      null_enabled:nullEnabled,
      reviewer_enabled:false,
    };
    try{
      const result=await apiPost<Run>("/experiment/run", body);
      setData(result); setDirty(false);
      setHistory(h=>[...h.filter(x=>x.run_id!==result.run_id), result].slice(-20));
      if(mode==="stress"){
        // 曲线展示 ρ 随 z 的解析函数关系（固定知识，形状不应随调 z 改变）；
        // 但必须把用户当前的 z 合并进采样点，ReferenceDot 才能精确落在曲线上、随 z 沿曲线移动。
        const zs=[...new Set([...PAD_PRESETS, z])].sort((a,b)=>a-b);
        const rs=await Promise.all(zs.map(p=>apiPost<Pad>("/lab/padding",{mode:scenario,z:p})));
        setCurve(rs.map(r=>({z:r.z, rho:r.global_spearman})));
      }
    }catch(e){
      setError(e instanceof Error?e.message:"实验运行失败");
    }
  }

  // 初次加载后自动按第一幕跑一次，作为默认基线。
  // eslint-disable-next-line react-hooks/set-state-in-effect
  useEffect(()=>{if(opts&&story&&!data){const m=story.missions[0];applyMission(m)}},[opts,story]);
  // eslint-disable-next-line react-hooks/set-state-in-effect
  useEffect(()=>{if(opts&&story&&dirty&&data==null) run()},[dirty,data,opts,story]);

  function resetBaseline(){if(story?.missions[0])applyMission(story.missions[0])}
  function pinCurrent(){if(data){setPinnedId(data.run_id);setShowCompare(false)}}
  function restoreRun(r:Run){
    setData(r);
    setDataset(String(r.config.dataset_id));
    setRelation(String(r.config.relation));
    setQ(Number(r.config.q));
    setPopulation(String(r.config.population));
    setTopK(Number(r.config.top_k ?? 10));
    setNullEnabled(Boolean(r.config.null_enabled));
    setMode((r.config.mode==="stress"?"stress":"paper") as "paper"|"stress");
    setScenario(String(r.config.stress_scenario ?? "reversed"));
    setZ(Number(r.config.z ?? 0));
    setDirty(false);
  }

  // 提交当前 claim 给 Mock Reviewer：Reviewer 只解释证据边界，不重写任何统计事实。
  async function runReview(){
    setReviewBusy(true); setReviewError(null);
    const question = claim==="replace"
      ? "在 APPLIES 当前评估总体下，degree 与 P2 是否可以互相替代？"
      : claim==="not_replace"
      ? "在 APPLIES 当前评估总体下，degree 与 P2 不可以互相替代？"
      : "当前证据是否足以判断 degree 与 P2 的可替代性？";
    try{
      setReview(await apiPost<ReviewData>("/review/run",{mode:"mock",case_id:"shipbuilding_applies_q2",question}));
    }catch(e){ setReviewError(e instanceof Error?e.message:"审查失败") }
    finally{ setReviewBusy(false); }
  }

  // 导出当前 A/B 与声明，便于将来接入 Research Notebook（导出格式见 RUN_COMPARE_SPEC）。
  function exportRun(){
    const payload={
      schema_version:"replab-run-export-v1",
      app_version:"0.1.0",
      exported_at:new Date().toISOString(),
      pinned_run_A:pinned ?? null,
      current_run_B:data ?? null,
      run_diff:diff,
      evidence_references:(data?.evidence ?? []).map(e=>(e as Json).id),
      user_provisional_claim:claim,
      reviewer_result:review ?? null,
      run_history:history,
    };
    const blob=new Blob([JSON.stringify(payload,null,2)],{type:"application/json"});
    const url=URL.createObjectURL(blob);
    const a=document.createElement("a");
    a.href=url; a.download=`replab-export-${Date.now()}.json`;
    a.click(); URL.revokeObjectURL(url);
  }

  const m=data?.metrics ?? {};
  const p=data?.population ?? {};
  const emphasis = sessionMode==="guided" && mission?.emphasis?.length
    ? mission.emphasis
    : ["global_spearman","active_spearman","strict_inversion_rate","topk_jaccard"];
  const kpis = emphasis.map(key=>{
    if(key==="universe_N") return {key,label:"总体 N",value:p.total_N ?? 675};
    if(key==="active_N") return {key,label:"活跃对象",value:p.active_N};
    if(key==="common_minimum_N") return {key,label:"共同最小值",value:p.common_minimum_N};
    if(key==="common_minimum_share") return {key,label:"共同最小值占比",value:p.common_minimum_share};
    return {key,label:key==="topk_jaccard"?`Top-${topK} Jaccard`:(metricLabels[key] ?? key),value:m[key]};
  }).filter(x=>x.value!=null).slice(0,4);

  const layers:[Layer,string][] = [["coverage","Coverage"],["association","Association"],["decision","Decision"],["semantics","Semantics"],["null","Robustness"]];
  const evidenceKeys = sessionMode==="guided" ? (mission?.emphasis ?? []) : ["common_minimum_share","global_spearman","active_spearman","strict_inversion_rate","null_p"];
  const evidenceItems = evidenceKeys.map(key=>{
    if(key==="common_minimum_N") return ["Coverage", p.common_minimum_N!=null?`${p.common_minimum_N} common minima`:null];
    if(key==="common_minimum_share") return ["Coverage", p.common_minimum_share!=null?`${(Number(p.common_minimum_share)*100).toFixed(2)}% common minima`:null];
    if(key==="active_N") return ["Coverage", p.active_N!=null?`${p.active_N} active entities`:null];
    if(key==="universe_N") return ["Coverage", p.total_N!=null?`${p.total_N} entities`:"675 entities"];
    if(key==="global_spearman") return ["Association", m.global_spearman!=null?`global ρ = ${Number(m.global_spearman).toFixed(4)}`:null];
    if(key==="active_spearman") return ["Association", m.active_spearman!=null?`active ρ = ${Number(m.active_spearman).toFixed(4)}`:null];
    if(key==="strict_inversion_rate") return ["Decision", m.strict_inversion_rate!=null?`${(Number(m.strict_inversion_rate)*100).toFixed(2)}% inversions`:null];
    if(key==="topk_jaccard") return ["Decision", m.topk_jaccard!=null?`Top-${topK} J = ${Number(m.topk_jaccard).toFixed(3)}`:null];
    if(key.startsWith("null_")) return ["Robustness", m.null_p!=null?`p = ${m.null_p}`:null];
    if(key==="active_ordering_changed") return ["Invariant", m.active_ordering_changed!=null?`active ordering changed: ${fmt("active_ordering_changed",m.active_ordering_changed)}`:null];
    return ["Evidence", null];
  }).filter(x=>x[1]).slice(0,4);

  const hasRibbon = sessionMode==="guided";

  return (
    <div className={`storyWorkspace${hasRibbon?" hasRibbon":""}`} data-layout="workspace">
      {hasRibbon && (
        <nav className="storyRibbon" aria-label="科研故事导航" style={{gridRow:"1"}}>
          {story?.missions.map((mm,idx)=>{
            const done = ranMissionIds.has(mm.id) && mm.id!==missionId;
            const active = mm.id===missionId;
            return (
              <span key={mm.id} className="ribbonGroup">
                <button
                  className={`case${active?" active":""}${done?" done":""}`}
                  onClick={()=>applyMission(mm)}
                >{String(mm.order).padStart(2,"0")} {RIBBON_LABELS[mm.order] ?? mm.title}</button>
                {idx<story.missions.length-1 && <span className="arrow">›</span>}
              </span>
            );
          })}
        </nav>
      )}

      <div className="commandBar panel" style={{gridRow: hasRibbon ? "2" : "1"}}>
        <div className="modeSwitch">
          <button className={sessionMode==="guided"?"active":""} onClick={()=>setSessionMode("guided")}>研究案例</button>
          <button className={sessionMode==="free"?"active":""} onClick={()=>setSessionMode("free")}>自由实验</button>
        </div>
        <select value={dataset} onChange={e=>mark(()=>{setDataset(e.target.value);const d=opts?.datasets.find(x=>x.id===e.target.value);if(d){setRelation(d.relations[0]);setQ(d.q[0])}})}>
          {opts?.datasets.map(x=><option key={x.id} value={x.id}>{x.label}</option>)}
        </select>
        <select value={relation} onChange={e=>mark(()=>{const r=e.target.value;setRelation(r);const qs=ds?.relation_q?.[r] ?? ds?.q ?? [2];setQ(qs[0])})}>
          {ds?.relations.map(r=><option key={r}>{r}</option>)}
        </select>
        <select value={q} onChange={e=>mark(()=>setQ(Number(e.target.value)))}>
          {allowedQ.map(v=><option key={v}>{v}</option>)}
        </select>
        <div className="commandSpacer"/>
        <button className="btn" onClick={run}>▶ 运行实验{dirty?" *":""}</button>
        <button className="btnGhost" disabled={!data} onClick={pinCurrent}>Pin A</button>
        <button className="btnGhost" disabled={!pinned||!data||pinned.run_id===data.run_id} onClick={()=>setShowCompare(true)}>比较 A/B</button>
        <button className="btnGhost" onClick={resetBaseline}>论文基线</button>
        <button className="btnGhost" onClick={exportRun}>导出</button>
      </div>

      <div className="storyMain" style={{gridRow: hasRibbon ? "3" : "2"}}>
        {error && <div className="errorBanner panel" style={{gridColumn:"1/-1",marginBottom:"10px"}}>⚠ {error}</div>}
        <aside className="panel labRail p-4">
          <h2>实验控制</h2>
          <div className="controlGroup">
            <div className="groupTitle">对象与表示</div>
            <label>Representation A</label>
            <select disabled><option>degree k</option></select>
            <label>Representation B</label>
            <select disabled><option>provenance P₂</option></select>
            <label>实验模式</label>
            <select value={mode} onChange={e=>mark(()=>setMode(e.target.value as "paper"|"stress"))}>
              <option value="paper">论文证据</option>
              <option value="stress">公开压力测试</option>
            </select>
          </div>
          <div className="controlGroup">
            <div className="groupTitle">实验变量</div>
            <label>Population</label>
            <div className="seg">
              <button className={population==="full"?"active":""} onClick={()=>mark(()=>setPopulation("full"))}>Full</button>
              <button className={population==="active"?"active":""} onClick={()=>mark(()=>setPopulation("active"))}>Active</button>
            </div>
            <label>Top-K</label>
            <select value={topK} onChange={e=>mark(()=>setTopK(Number(e.target.value)))}>{[5,10,20].map(k=><option key={k}>{k}</option>)}</select>
            {mode==="stress" && (
              <>
                <label>Scenario</label>
                <select value={scenario} onChange={e=>mark(()=>setScenario(e.target.value))}>
                  <option value="reversed">完全反向</option>
                  <option value="micro">微型网络</option>
                </select>
                <label>共同最小值 z <b>{z}</b></label>
                <input type="range" min="0" max="1000" step="10" value={z} onChange={e=>mark(()=>setZ(Number(e.target.value)))}/>
              </>
            )}
            <label className="check">
              <input type="checkbox" checked={nullEnabled} disabled={!(dataset==="shipbuilding"&&relation==="APPLIES"&&q===2&&mode==="paper")} onChange={e=>mark(()=>setNullEnabled(e.target.checked))}/>
              Null evidence
            </label>
          </div>
          {sessionMode==="guided" && story && (
            <div className="caseList">
              <div className="groupTitle">Research Case</div>
              {story.missions.map(mm=>(
                <button key={mm.id} className={missionId===mm.id?"active":""} onClick={()=>applyMission(mm)}>
                  <b>{String(mm.order).padStart(2,"0")}</b><span>{mm.title}</span>
                </button>
              ))}
            </div>
          )}
        </aside>

        <main className="centerLab">
          <section className="researchQuestion panel">
            <div>
              <div className="questionMeta">
                <span className="eyebrow">{sessionMode==="guided"?`Research Case ${String(mission?.order??1).padStart(2,"0")}`:"Free Lab"}</span>
                <SourceBadge sourceKind={data?.source_kind} sourceLabel={data?.source_label}/>
              </div>
              <h1>{sessionMode==="guided"?(mission?.title??story?.title):"自由实验"}</h1>
              <p>{sessionMode==="guided"?mission?.question:"改变一个条件，运行，并与基线比较。"}</p>
            </div>
            {sessionMode==="guided" && (
              <div className="suggestedProbe">
                <span>Suggested next probe</span>
                <p>{mission?.suggested_probe}</p>
              </div>
            )}
          </section>

          <section className="kpiGrid storyKpis">
            {kpis.map(x=>(
              <div className="metric compactMetric" key={x.key}>
                <span className="muted text-sm">{x.label}</span>
                <strong>{fmt(x.key,x.value)}</strong>
              </div>
            ))}
          </section>

          <section className="panel experimentPanel">
            <div className="layerTabs">
              {layers.map(([id,label])=>(
                <button key={id} disabled={!data?.availability[id]} className={layer===id?"active":""} onClick={()=>setLayer(id)}>{label}</button>
              ))}
            </div>
            <div className="experimentVisualGrid">
              <div className="primaryVisual">
                {mode==="stress" ? (
                  <>
                    <div className="visualTitle">
                      <h3>共同最小值压力曲线</h3>
                      <span className="invariantBadge">Active ordering changed: {fmt("active_ordering_changed",m.active_ordering_changed)}</span>
                    </div>
                    <div style={{display:"grid",gridTemplateColumns:"1.6fr 1fr",gap:10}}>
                      <div className="h-[330px]">
                        <ResponsiveContainer width="100%" height="100%">
                          <LineChart data={curve}>
                            <CartesianGrid stroke="var(--border)"/>
                            <XAxis dataKey="z"/>
                            <YAxis domain={[-1,1]}/>
                            <Tooltip/>
                            {m.global_spearman!=null && (
                              <>
                                <ReferenceLine x={z} stroke="var(--amber)" strokeDasharray="4 3" label={{value:`z=${z}`, position:"top", fontSize:13, fill:"var(--amber)"}}/>
                                <ReferenceDot x={z} y={Number(m.global_spearman)} r={7} fill="var(--amber)" stroke="#fff" strokeWidth={2}/>
                              </>
                            )}
                            <Line dataKey="rho" stroke="var(--cyan)" strokeWidth={3} dot/>
                          </LineChart>
                        </ResponsiveContainer>
                      </div>
                      <RankLinksView scenario={scenario} z={z}/>
                    </div>
                    <p className="muted text-sm">本实验为公开确定性定理演示：在当前实验参数下实时计算共同最小值压力，观察全体相关性如何变化。结果来自公开的合成 seed 向量，不是对保密 APPLIES 活跃向量的重建。</p>
                  </>
                ) : layer==="coverage" ? <CoverageView p={p}/> :
                  layer==="decision" ? <DecisionView m={m} topK={topK}/> :
                  layer==="semantics" ? <SemanticsView m={m}/> :
                  layer==="null" ? <NullView m={m}/> :
                  <AssociationView m={m} p={p}/>}
              </div>
              <div className="secondaryVisual">
                <h3>参数变更</h3>
                {showCompare && pinned && data && pinned.run_id!==data.run_id ? (
                  <>
                    <div className="diffList">
                      {diff.length ? diff.map(d=>(
                        <div key={d.key}><span>{d.key}</span><b>{String(d.from)} → {String(d.to)}</b></div>
                      )) : <p className="muted">A 与 B 的科学参数相同。</p>}
                    </div>
                    {metricDelta.length>0 && (
                      <div className="metricDelta">
                        <div className="subTitle">可比指标</div>
                        {metricDelta.map(d=>(
                          <div key={d.key}><span>{metricLabels[d.key] ?? d.key}</span>
                            <b>{fmt(d.key,d.from)} → {fmt(d.key,d.to)} <em>Δ {fmt(d.key,d.delta)}</em></b></div>
                        ))}
                      </div>
                    )}
                    {diff.length>1 && (
                      <div className="boundary mt-3">多个科学条件同时改变：这里只做描述性比较，不解释为单一参数效应。</div>
                    )}
                  </>
                ) : <p className="muted">先运行一个基线并 Pin A，再改变一个条件运行 B。</p>}
                <div className="runMeta">
                  <span>Current run</span><b>{data?.run_id??"—"}</b>
                  <span>来源</span><b>{srcLabel(data?.source_kind)}</b>
                </div>
              </div>
            </div>
          </section>
        </main>

        <aside className="panel evidenceRail p-4">
          <h2>结论与证据</h2>
          <div className="sourcebox">
            <SourceBadge sourceKind={data?.source_kind} sourceLabel={data?.source_label}/>
            <p>{evidenceNarrative(data)}</p>
            <p className="muted text-sm mt-2">数据来源：{sourceNote(data)}</p>
          </div>
          <div className="claimBox">
            <span className="eyebrow">你的临时结论</span>
            <div className="claimButtons">
              <button className={claim==="replace"?"active":""} onClick={()=>setClaim("replace")}>可以替代</button>
              <button className={claim==="not_replace"?"active":""} onClick={()=>setClaim("not_replace")}>不可以替代</button>
              <button className={claim==="insufficient"?"active":""} onClick={()=>setClaim("insufficient")}>证据不足</button>
            </div>
          </div>
          <div className="evidenceStack">
            <h3>当前证据</h3>
            {evidenceItems.map(([tag,value],i)=>(
              <div className="evidenceCard" key={`${tag}-${i}`}><span>{tag}</span><b>{value}</b></div>
            ))}
          </div>
          <div className="boundary mt-4">
            <b>解释边界</b>
            <p>{data?.boundaries?.[0] ?? "Run the experiment before interpreting the claim."}</p>
          </div>
          <button className="btnGhost w-full mt-4" disabled={!data||reviewBusy} onClick={runReview}>
            {reviewBusy?"审查中...":"提交一句话给 Reviewer 审查"}
          </button>
          {reviewError && <p className="text-[var(--red)] text-sm mt-2">{reviewError}</p>}
          {review && (
            <div className="reviewResult mt-3">
              <div className="reviewBlock ok">
                <b>允许的表述</b>
                {review.allowed_claims.map(x=><p key={x}>{x}</p>)}
              </div>
              <div className="reviewBlock bad">
                <b>被拒绝的表述</b>
                {review.blocked_claims.map(x=><p key={x}>{x}</p>)}
              </div>
              {review.unresolved && review.unresolved.length>0 && (
                <div className="reviewBlock">
                  <b>未决问题</b>
                  {review.unresolved.map(x=><p key={x}>{x}</p>)}
                </div>
              )}
              <p className="muted text-sm mt-3">当前可用证据为论文报告的聚合统计，不含支持个体级推断所需的记录级观测；本实验不对此作进一步推断。</p>
            </div>
          )}
        </aside>
      </div>

      <div className="runTray panel" style={{gridRow: hasRibbon ? "4" : "3"}}>
        <div className="trayTitle">
          <span>实验历史</span>
          <small>{history.length}/20</small>
          {history.length>0 && (
            confirmClear ? (
              <span className="clearConfirm">
                <button className="btnDangerXs" onClick={()=>{setHistory([]);setPinnedId(null);setConfirmClear(false)}}>确认清空</button>
                <button className="btnGhostXs" onClick={()=>setConfirmClear(false)}>取消</button>
              </span>
            ) : (
              <button className="btnGhostXs" onClick={()=>setConfirmClear(true)}>清空历史</button>
            )
          )}
        </div>
        <div className="runChips">
          {history.length ? history.map((r,i)=>(
            <button key={r.run_id} className={`runChip ${data?.run_id===r.run_id?"current":""} ${pinnedId===r.run_id?"pinned":""}`} onClick={()=>restoreRun(r)}>
              <b>R{String(i+1).padStart(2,"0")}{pinnedId===r.run_id?" · A":""}</b>
              <span>{String(r.config.relation)} q{String(r.config.q)} · {String(r.config.population)}</span>
              <small>{chipHeadline(r)}</small>
            </button>
          )) : <span className="muted">Run your first experiment.</span>}
        </div>
        <div className="quickExperiments">
          <span className="muted text-sm">快速实验</span>
          <button className="btnGhost text-sm" onClick={()=>mark(()=>{setMode("stress");setScenario("reversed");setZ(500);setPopulation("active")})}>完全反向压力</button>
          <button className="btnGhost text-sm" onClick={()=>mark(()=>setTopK(5))}>Top-K 5</button>
          <button className="btnGhost text-sm" onClick={()=>mark(()=>setTopK(10))}>Top-K 10</button>
          <button className="btnGhost text-sm" onClick={()=>mark(()=>setTopK(20))}>Top-K 20</button>
          <button className="btnGhost text-sm" onClick={()=>mark(()=>{setRelation("PROVIDES");setQ(2)})}>PROVIDES</button>
          <button className="btnGhost text-sm" onClick={()=>mark(()=>setNullEnabled(true))}>Null audit</button>
        </div>
      </div>
    </div>
  );
}

function CoverageView({p}:{p:Json}){
  const total=p.total_N!=null?Number(p.total_N):((p.active_N!=null?Number(p.active_N):0)+(p.common_minimum_N!=null?Number(p.common_minimum_N):0));
  const active=p.active_N!=null?Number(p.active_N):0;
  const cm=p.common_minimum_N!=null?Number(p.common_minimum_N):Math.max(0,total-active);
  const activePct=total?active/total*100:0;
  return (
    <>
      <h3>Population composition</h3>
      <div className="populationBar">
        <div className="activePart" style={{width:`${activePct}%`}}/>
        <div className="minimumPart" style={{width:`${100-activePct}%`}}/>
      </div>
      <div className="bigEvidence">
        <div><span>Total</span><b>{total||"—"}</b></div>
        <div><span>Active</span><b>{active||"—"}</b></div>
        <div><span>Common minimum</span><b>{cm||"—"}</b></div>
      </div>
    </>
  );
}
function AssociationView({m,p}:{m:Json;p:Json}){
  return (
    <>
      <h3>Global vs active association</h3>
      <div className="associationCompare">
        <div><span>Full population</span><b>{m.global_spearman!=null?Number(m.global_spearman).toFixed(4):"—"}</b></div>
        <div className="arrow">→</div>
        <div><span>Active population</span><b>{m.active_spearman!=null?Number(m.active_spearman).toFixed(4):"—"}</b></div>
      </div>
      {p.common_minimum_share!=null && <p className="muted mt-6">Common-minimum share: {(Number(p.common_minimum_share)*100).toFixed(2)}%. Population definition is part of the estimand.</p>}
    </>
  );
}
function DecisionView({m,topK}:{m:Json;topK:number}){
  return (
    <>
      <h3>Decision-level evidence</h3>
      <div className="bigEvidence">
        <div><span>Strict inversion</span><b>{m.strict_inversion_rate!=null?`${(Number(m.strict_inversion_rate)*100).toFixed(2)}%`:"—"}</b></div>
        <div><span>Top-{topK} Jaccard</span><b>{m.topk_jaccard!=null?Number(m.topk_jaccard).toFixed(3):"—"}</b></div>
      </div>
      <div className="boundary mt-5">The frozen APPLIES rerun did not retain realization-level null distributions for inversion or Top-K metrics.</div>
    </>
  );
}
function SemanticsView({m}:{m:Json}){
  return (
    <>
      <h3>Representation semantics</h3>
      <div className="bigEvidence">
        <div><span>Σ P₂</span><b>{String(m.P2_total ?? "—")}</b></div>
        <div><span>Σ S₂</span><b>{String(m.S2_total ?? "—")}</b></div>
        <div><span>Σ M₂</span><b>{String(m.M2_total ?? "—")}</b></div>
      </div>
      <p className="muted mt-5">P₂ preserves provenance multiplicity; S₂ counts unique combinations; M₂ is an auxiliary multiplicity descriptor.</p>
    </>
  );
}
function NullView({m}:{m:Json}){
  // null_quantiles 后端按证据层动态返回，这里窄化为字典再取值。
  const nq = (m.null_quantiles as Record<string, unknown> | undefined) ?? {};
  const q = (k:string)=> nq[k]!=null ? Number(nq[k]).toFixed(4) : "—";
  return (
    <>
      <h3>Fixed-margin robustness</h3>
      <div className="intervalBox">
        <div><span>2.5%</span><b>{q("0.025")}</b></div>
        <div><span>Null mean</span><b>{m.null_mean!=null?Number(m.null_mean).toFixed(4):"—"}</b></div>
        <div><span>97.5%</span><b>{q("0.975")}</b></div>
        <div><span>Observed</span><b>{m.null_observed!=null?Number(m.null_observed).toFixed(4):"—"}</b></div>
      </div>
      <p className="nullP">Approx. two-sided Monte Carlo p = <b>{String(m.null_p ?? "—")}</b></p>
      <div className="boundary mt-4">This tests active-set association relative to preserved margins. It does not test the common-minimum coverage mechanism.</div>
    </>
  );
}

// Stress 模式下的 Active rank links 二部图：展示活跃实体在两种表示下的 rank 置换。
// 数据来自后端 padding_demo 的确定性定理，不是对 APPLIES 活跃向量的重建。
function RankLinksView({scenario,z}:{scenario:string;z:number}){
  // 反向场景下高 z 时 ordering 不变（identity permutation）；微型网络做示意性置换。
  const n=5;
  const reversed=scenario==="reversed" && z>=100;
  const left=Array.from({length:n},(_,i)=>i+1);
  const right=reversed ? [...left].reverse() : [...left];
  const W=320,H=220;
  const lx=40,rx=W-40,nodeR=14;
  const yStep=(H-40)/(n+1);
  const lines=left.map((l,i)=>({
    x1:lx+nodeR,y1:30+yStep*(i+1),
    x2:rx-nodeR,y2:30+yStep*(right.indexOf(l)!+1),
    label:`${l}→${right[i]}`
  }));
  return (
    <div>
      <h3 style={{margin:"0 0 8px",fontSize:"14px"}}>Active rank links</h3>
      <svg viewBox={`0 0 ${W} ${H}`} style={{width:"100%",height:"auto",background:"#EDF1F4",borderRadius:12,border:"1px solid var(--border)"}}>
        {/* 连线 */}
        {lines.map((l,i)=>(
          <line key={i} x1={l.x1} y1={l.y1} x2={l.x2} y2={l.y2}
            stroke={reversed?"#0E7C86":"#1050A0"} strokeWidth="1.5" opacity="0.6"/>
        ))}
        {/* 左侧节点 */}
        {left.map((v,i)=>(
          <g key={`L${i}`}>
            <circle cx={lx} cy={30+yStep*(i+1)} r={nodeR} fill="#FFFFFF" stroke="#0E7C86" strokeWidth="1.5"/>
            <text x={lx} y={30+yStep*(i+1)+4} textAnchor="middle" fill="#16323F" fontSize="11">{v}</text>
          </g>
        ))}
        {/* 右侧节点 */}
        {right.map((v,i)=>(
          <g key={`R${i}`}>
            <circle cx={rx} cy={30+yStep*(i+1)} r={nodeR} fill="#FFFFFF" stroke="#1050A0" strokeWidth="1.5"/>
            <text x={rx} y={30+yStep*(i+1)+4} textAnchor="middle" fill="#16323F" fontSize="11">{v}</text>
          </g>
        ))}
        {/* 底部标注 */}
        <text x={W/2} y={H-10} textAnchor="middle" fill="#5E7682" fontSize="10">
          ρ<sub>active</sub> = {reversed ? "-1.0000" : "~1.0000"} throughout
        </text>
      </svg>
    </div>
  );
}
