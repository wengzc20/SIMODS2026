// 三层分离：用户界面只显示人能读懂的来源标签；内部 provenance 枚举（paper_aggregate 等）
// 与开发自证说明不暴露给普通用户，仅在悬浮提示（title）里作为数据来源说明出现。
type Props = { sourceKind?: string; sourceLabel?: string }

// 内部枚举 → 界面可读标签
const DISPLAY: Record<string, string> = {
  paper_aggregate: "论文结果",
  live_computed: "现场计算",
  public_summary: "公开数据",
  live_public: "公开数据",
};
// 悬浮说明（第三层：数据来源与证据范围，不喧宾夺主）
const TIP: Record<string, string> = {
  paper_aggregate: "来自锁定研究结果的聚合统计，本实验页面不进行记录级重算。",
  live_computed: "由当前实验参数通过确定性 Python 核心实时计算。",
  public_summary: "论文中公开数据集的锁定聚合摘要。",
  live_public: "由公开数据实时计算。",
};

export function srcLabel(sourceKind?: string): string {
  return DISPLAY[sourceKind || ""] || "来源未标明";
}

export default function SourceBadge({ sourceKind, sourceLabel }: Props) {
  const kind = sourceKind || "";
  const label = DISPLAY[kind] || sourceLabel || "来源未标明";
  const tip = TIP[kind] || (sourceLabel ? `来源标识：${sourceLabel}` : "来源未标明");
  const cls = kind === "live_computed" || kind === "live_public"
    ? "sourceBadge live"
    : kind === "paper_aggregate"
      ? "sourceBadge paper"
      : "sourceBadge public";
  return <span className={cls} title={tip}>{label}</span>;
}
