// 开发预览：默认指向本地后端。生产部署时通过环境变量 NEXT_PUBLIC_API_BASE 覆盖。
const BASE=process.env.NEXT_PUBLIC_API_BASE ?? "http://127.0.0.1:8001/api/v1";
export async function apiGet<T>(path:string):Promise<T>{const r=await fetch(`${BASE}${path}`,{cache:"no-store"});if(!r.ok)throw new Error(`${r.status} ${await r.text()}`);return r.json()}
export async function apiPost<T>(path:string,body:unknown):Promise<T>{const r=await fetch(`${BASE}${path}`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});if(!r.ok)throw new Error(`${r.status} ${await r.text()}`);return r.json()}
