# Frontend-specific Codex instructions
- Never put sprint/development status in user-facing UI.
- One main scientific question per screen; avoid “AI command center” styling.
- Use color semantically: cyan=current data/layer; blue=support; amber=boundary/warning; red=contradiction/blocked claim; violet=higher-order semantics.
- Paper numbers must be fetched from backend/locked fixtures; do not hardcode manuscript statistics in page components.
- The 0.999 Lab interactive curve uses public synthetic/reversed fixtures or deterministic public inputs. Do not pretend it is a recomputation of confidential APPLIES active vectors.
