# RepLab v2.2 Academic Theme

浅色学术风主题的独立 GitHub 版本，无深色主题。功能与 v2.2 锁稿版完全一致，仅视觉风格改为灰白底 + 深蓝标题 + 青绿强调色，适配学术论文/汇报演示场景。

## Quick start

需要 Node.js 22+ 与 Python 3.12+。

```bash
# 1. 安装依赖并启动前后端（默认端口：前端 3000，后端 8000）
./start.sh

# 2. 打开 http://localhost:3000

# 3. 停止
./stop.sh
```

Windows 用 PowerShell：

```powershell
.\start.ps1
.\stop.ps1
```

> 首次启动会自动创建 `backend/.venv`、安装 Python 依赖、安装 npm 依赖，耗时约 1–2 分钟。

## 手动启动

```bash
cd backend
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\Activate.ps1
pip install fastapi "uvicorn[standard]" pydantic
export REPLAB_AGENT_MODE=mock   # 无需 OpenAI Key
CORS_ORIGINS="http://localhost:3000,http://127.0.0.1:3000" uvicorn app.main:app --host 127.0.0.1 --port 8000

cd web
export NEXT_PUBLIC_API_BASE=http://127.0.0.1:8000/api/v1
npm install
npm run dev
```

> 推荐直接跑 `./start.sh`（或 `.\start.ps1`），它会自动建 venv、装依赖、设 mock 模式与 CORS 并先后启动前后端。

## 构建验证

```bash
cd backend
python -m pytest tests -q
python scripts/validate_data.py

cd web
npm run build
```

## 主题说明

- `--canvas` `#F4F6F8`：浅灰白页面底
- `--panel` `#FFFFFF`：纯白卡片
- `--text` `#16323F`：深青黑主文字
- `--blue` `#1050A0`：深蓝，用于主按钮、标题强调
- `--cyan` `#0E7C86`：青绿，用于选中态、边框、图例
- `--amber` `#C8881E`：琥珀，用于参考线与边界提示
- 无深色模式、无 `/classic` 路由

## 文档索引

1. `STORY_EXPERIENCE_SPEC.md` — 研究案例与实验流程
2. `PRODUCT_SPEC.md` — 产品范围与模式
3. `UI_INTERACTION_SPEC.md` — 工作台布局与交互
4. `RUN_COMPARE_SPEC.md` — Run、Pin、Compare 机制
5. `API_CONTRACT.md` — 前后端契约
6. `DATA_SOURCE_POLICY_v2.2.md` — 数据来源与保密边界
7. `TEST_PLAN.md` — 验收测试

## 部署 FAQ

### 页面出现 "Failed to fetch"

这表示前端页面在浏览器里连不上后端 API。按下面顺序排查：

1. **后端是否真的起来了？**
   ```bash
   curl http://127.0.0.1:8000/api/v1/health
   ```
   如果无响应，先看 `backend.log` 最后 20 行：
   ```bash
   tail -20 backend.log        # macOS/Linux/Git Bash
   Get-Content backend.log -Tail 20   # PowerShell
   ```
   常见原因：`.venv` 创建失败、依赖安装被墙、端口 8000 被占用。

2. **端口是否被占用？**
   - 如果 8000 已被别的程序占用，后端会启动失败。换端口启动：
     ```bash
     # 后端改 8011
     cd backend
     CORS_ORIGINS="http://localhost:3000,http://127.0.0.1:3000" .venv/Scripts/python.exe -m uvicorn app.main:app --host 127.0.0.1 --port 8011

     # 前端同步改指向
     cd web
     echo "NEXT_PUBLIC_API_BASE=http://127.0.0.1:8011/api/v1" > .env.local
     npm run dev -- -p 3000
     ```

3. **CORS 跨域问题**
   - 后端默认放行 `localhost:3000/3100` 与 `127.0.0.1:3000/3100`。
   - 如果你用别的端口（如 `localhost:8080`）访问前端，启动后端时加入该来源：
     ```bash
     CORS_ORIGINS="http://localhost:8080,http://127.0.0.1:8080" uvicorn app.main:app --host 127.0.0.1 --port 8000
     ```
   - Windows PowerShell：
     ```powershell
     $env:CORS_ORIGINS="http://localhost:8080,http://127.0.0.1:8080"
     .venv/Scripts/python.exe -m uvicorn app.main:app --host 127.0.0.1 --port 8000
     ```

4. **前端请求地址是否正确？**
   - 检查 `web/.env.local`：
     ```
     NEXT_PUBLIC_API_BASE=http://127.0.0.1:8000/api/v1
     ```
   - 修改后需要**重启前端 dev server** 才生效。

### 想部署到局域网/服务器给其他人访问

- 后端：`uvicorn app.main:app --host 0.0.0.0 --port 8000`
- 前端：`.env.local` 里把 `NEXT_PUBLIC_API_BASE` 写成后端真实 IP，然后 `npm run build && npm run start`。
- 注意：本仓库面向本地演示，未做生产级安全加固，不要直接暴露到公网。

## Stack

- Next.js 16 / React 19 / TypeScript / Tailwind CSS v4
- FastAPI / Python 3.12+ / Pydantic / pytest
- Recharts
