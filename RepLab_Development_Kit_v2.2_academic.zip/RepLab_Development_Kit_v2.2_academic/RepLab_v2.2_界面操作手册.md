# RepLab v2.2 界面操作手册

> **适用版本**：RepLab v2.2（story-driven workspace）
> **访问地址**：`http://localhost:3100`（前端）+ `http://127.0.0.1:8001`（后端 API）
> **设计理念**：论文挑战模式——一个 10–15 分钟的科研叙事，连续 6 个实验卡 + 1 个 Epilogue，两次认知反转。

---

## 一、界面总览

### 1.1 布局结构

整个工作区是一个 CSS Grid 四行/三列布局（有 Ribbon 时为四行），从上到下、从左到右依次是：

```
┌──────────────────────────────────────────────────────────────┐
│  [① 故事导航 Ribbon]  01 可疑的 0.999 › 02 共同最小值 › …   │  ← 仅「研究案例」模式显示
├──────┬───────────────────────────────────┬───────────────────┤
│      │  [② 命令栏 Command Bar]           │                   │
│      │  [研究案例|自由实验] 数据集 关系 q  │                   │
│  ③   │  ▶运行 PinA 比较A/B 论文基线 导出  │       ⑤          │
│ 左侧 │                                   │    右侧           │
│ 实验 ├───────────────────────────────────┤  结论与证据        │
│ 控制 │  [④ 中央实验区 Center Lab]         │                   │
│ Rail │  ┌─────────────┬──────────────┐   │  · 来源标签        │
│      │  │ 研究问题     │ Suggested    │   │  · 临时结论(三选一)│
│      │  │ KPI 卡片 ×4  │ next probe   │   │  · 当前证据卡片栈  │
│      │  ├─────────────┴──────────────┤   │  · 解释边界        │
│      │  │ [实验画布]    │ [参数变更]   │   │  · Reviewer 审查  │
│      │  │ (5层Tab切换)  │ A/B比较      │   │                   │
│      │  └─────────────┬──────────────┘   │                   │
├──────┴────────────────┴──────────────────┴───────────────────┤
│  [⑥ 实验历史托盘 Run Tray]                                     │
│  R01·A  R02  R03 ...  |  [快速实验按钮组]                      │
└──────────────────────────────────────────────────────────────┘
```

**六大专区的功能定位：**

| 编号 | 区域名称 | DOM 类名 | 核心职责 |
|------|---------|----------|---------|
| ① | 故事导航 | `.storyRibbon` | 7 个幕的快速跳转与完成标记 |
| ② | 命令栏 | `.commandBar` | 模式切换 + 参数选择 + 运行/Pin/导出 |
| ③ | 左侧控制台 | `.labRail` | Representation 选择 / Population / Top-K / Stress 控制 / Research Case 列表 |
| ④ | 中央实验区 | `.centerLab` | 研究问题标题 + KPI 指标卡 + 五层证据可视化 + A/B 比较 |
| ⑤ | 右侧证据栏 | `.evidenceRail` | 来源证明 + 临时结论选择 + 证据卡片栈 + 解释边界 + Reviewer |
| ⑥ | 底部托盘 | `.runTray` | 运行历史 chip 流 + 快捷实验入口 |

---

## 二、各区域详解

### 2.1 ① 故事导航 Ribbon

**显示条件**：仅在「**研究案例**」模式下可见。切换到「自由实验」后此区域消失。

**外观**：一行胶囊形按钮，用 `›` 箭头连接：

```
[01 可疑的 0.999] › [02 共同最小值] › [03 活跃层差异] › [04 Top-K] › [05 敏感性] › [06 Null] › [07 Epilogue]
```

**三种状态**：
| 状态 | 样式 | 含义 |
|------|------|------|
| 当前激活 | 青色底 `#10354a` + 青色边框 + 白字 | 正在查看/操作的这一幕 |
| 已完成 | 灰蓝色文字 `#b7dbe4` | 历史记录中已存在该幕的运行结果 |
| 未触达 | 默认暗色 `#7898a7` | 尚未运行过 |

**交互**：点击任意幕按钮 → 自动将该幕的预设参数灌入左侧控制台和命令栏 → 自动标记 `dirty` → 触发自动运行。

**幕后编号与标签对照表**：

| 幕 ID | 显示标签 | 标题 | 核心问题 |
|-------|---------|------|---------|
| case-01 | `01 可疑的 0.999` | 可疑的 0.999 | ρ=0.999412 能说明可替代吗？ |
| case-02 | `02 共同最小值` | 623 个共同最小值 | 切到 Active 总体会怎样？ |
| case-03 | `03 活跃层差异` | 只改变覆盖，不改变活跃排序 | 加 z 能否推高全局 Spearman？ |
| case-04 | `04 Top-K` | 如果我要选 Top-K 呢？ | 头部选择是否仍然不同？ |
| case-05 | `05 敏感性` | 换关系、换阶数，现象还在吗？ | PROVIDES/q=3/q=4 下是否仍可见？ |
| case-06 | `06 Null` | 不同，不等于"异常" | 差异能否说明异常高阶组织？ |
| epilogue | `07 Epilogue` | Epilogue · 总体是估计对象的一部分 | MovieLens / DBLP 跨域迁移 |

---

### 2.2 ② 命令栏 Command Bar

位于 Ribbon 下方（无 Ribbon 时为最顶行）。包含以下元素，从左到右：

#### （A）模式切换器 `.modeSwitch`

```
┌─────────────┬─────────────┐
│  研究案例 ◄ │  自由实验    │
└─────────────┴─────────────┘
```

- **研究案例（Guided Case）**：默认模式。显示 Ribbon 导航 + Research Case 列表；每次切幕自动灌参数。
- **自由实验（Free Lab）**：隐藏 Ribbon 和 Case 列表；所有参数手动调节；底部托盘变为 R01/R02/R03… 实验历史流。

> **设计意图**（来自设计稿 Image 3）：Guided Case 只告诉学生"下一次最好只改哪个参数"；Free Lab 随时可以脱离故事自己折腾。底部不再是固定 Stage 1–6，而是 R01/R02/R03… 实验历史。用户可以 Pin R01 为 A，只改 Population，再跑 R02 为 B，然后页面直接回答 "What changed?"。

#### （B）数据集选择 `<select>`

当前可选数据集（由后端 `/workbench/options` 动态返回）：
- **shipbuilding**（造船企业 APPLIES 网络）— 默认
- **movielens_1997_q4**（MovieLens 评分）— Epilogue 使用
- **dblp**（DBLP 合作网络）— Epilogue 使用

切换数据集时自动联动：关系列表 → 第一个可用关系 → 第一个可用 q 值。

#### （C）关系选择 `<select>`

依赖数据集。shipbuilding 下可选：
- **APPLIES**（企业应用技术关系）— 默认
- **PROVIDES**（企业提供技术/产品关系）— Case 05 使用

#### （D）阶数 q `<select>`

依赖关系。APPLIES 下支持 q=2；PROVIDES 下可能支持更多。

#### （E）操作按钮组

| 按钮 | 文本 | 功能 | 启用条件 |
|------|------|------|---------|
| 主运行 | `▶ 运行实验` 或 `▶ 运行实验 *` | 向后端 POST `/experiment/run` 并刷新中央区 | 始终启用（`*` 表示参数已修改未运行） |
| Pin A | `Pin A` | 将当前运行结果固定为比较基线 A | 必须已有运行结果 |
| 比较 A/B | `比较 A/B` | 展开右侧「参数变更」面板的 A/B diff 视图 | 必须 Pin 了 A 且当前结果 ≠ A |
| 论文基线 | `论文基线` | 一键回到 Case-01 的初始配置 | 始终启用 |
| 导出 | `导出` | 将当前 A/B 比较 + claim + review 结果导出为 JSON 文件 | 始终启用（无数据时导出空壳） |

---

### 2.3 ③ 左侧实验控制台 `.labRail`

分为三个控制组：

#### （A）对象与表示 `.controlGroup`

```
Representation A    [degree k  ▾]   （禁用——固定为 degree/k）
Representation B    [provenance P₂ ▾] （禁用——固定为 P₂）
实验模式            [论文证据 ▾]
                    ┌ 论文证据 ─┐
                    │ 公开压力测试 │
                    └───────────┘
```

- **Representation A / B**：锁定不可改（本版本仅对比 degree-k 与 provenance-P₂）。
- **实验模式**：切换「论文证据」（paper）与「公开压力测试」（stress）。

  | 模式 | 行为 |
  |------|------|
  | 论文证据 | 从论文锁定的聚合统计取数；不执行实时计算 |
  | 公开压力测试 | 用公开合成 seed 向量实时计算；出现 z 滑块和 Scenario 选择 |

#### （B）实验变量 `.controlGroup`

```
Population     ┌──────┬──────┐
               │ Full │Active│
               └──────┴──────┘
Top-K          [10 ▾]          可选 5 / 10 / 20

（仅 stress 模式显示以下两项：）
Scenario       [完全反向 ▾]     可选 完全反向 / 微型网络
共同最小值 z  [═════════●══] 0    滑块范围 0–1000，步长 10

☐ Null evidence                复选框（仅 shipbuilding+APPLIES+q=2+paper 时启用）
```

**Population 分段按钮**：
- **Full**：完整总体（675 家企业）→ 全体 Spearman ρ ≈ 0.9994
- **Active**：活跃子总体（52 家企业）→ 活跃 Spearman ρ ≈ 0.7155

**z 滑块**（stress 专属）：拖动时右侧实时显示当前 z 值。z 代表向排名向量注入的"共同严格最小值"数量。

**Null evidence 复选框**：勾选后启用 Robustness 层（Monte Carlo p-value 检验）。

#### （C）Research Case 列表 `.caseList`

**仅研究案例模式显示**。列出全部 7 个幕，格式为：

```
┌──────────────────────────────┐
│ 01  可疑的 0.999             │  ← 当前选中（青色高亮）
│ 02  623 个共同最小值          │
│ 03  只改变覆盖，不改变活跃排序   │
│ 04  如果我要选 Top-K 呢？      │
│ 05  换关系、换阶数，现象还在吗？ │
│ 06  不同，不等于"异常"         │
│ 07  Epilogue                 │
└──────────────────────────────┘
```

点击任一幕 = 点击 Ribbon 上对应按钮 = 灌入预设参数并自动运行。

---

### 2.4 ④ 中央实验区 `.centerLab`

自上而下分三层：

#### （A）研究问题头部 `.researchQuestion`

```
┌──────────────────────────────────────────────────────────┐
│ RESEARCH CASE 01          [● 论文结果]                    │  ← 元信息行
│                                                          │
│ 可疑的 0.999                                            │  ← h1 标题（幕标题）
│ 675 家公司上的 Spearman ρ=0.999412，足够说明 degree 与    │  ← 问题陈述
│ P2 可以互相替代吗？                                      │
│                                                          │
│  │ Suggested next probe                                  │  ← 引导提示（仅 Guided）
│  │ 先不要改 relation 或 q。打开 Coverage，看看是谁在贡献   │
│  │ 这个全局统计。                                        │
└──────────────────────────────────────────────────────────┘
```

- **元信息行**：左侧显示 `RESEARCH CASE XX`（Free Lab 时显示 `FREE LAB`）；右侧显示来源徽章（`[● 论文结果]` / `[● 现场计算]` / `[● 公开数据]`）。
- **Suggested next probe**：仅 Guided 模式显示。每一幕都有不同的"下一步建议"，引导学生探索。

#### （B）KPI 指标卡 `.storyKpis`

根据当前幕的 `emphasis` 字段动态显示最多 4 张指标卡：

```
┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐
│ 总体 N   │ │ 全体     │ │ 活跃对象 │ │ 共同最小值│
│   675    │ │ Spearman │ │    52    │ │    623   │
└──────────┘ └──────────┘ └──────────┘ └──────────┘
```

各幕 emphasis 对照：

| 幕 | KPI 1 | KPI 2 | KPI 3 | KPI 4 |
|----|-------|-------|-------|-------|
| 01 | 总体 N = 675 | 全体 Spearman = 0.9994 | — | — |
| 02 | 活跃对象 = 52 | 共同最小值 = 623 | 占比 = 92.30% | 活跃 Spearman = 0.7155 |
| 03 | 活跃 Spearman | 全体 Spearman | Active ordering changed | — |
| 04 | 严格逆转率 | Top-10 Jaccard | — | — |
| 05 | 活跃 Spearman | 严格逆转率 | — | — |
| 06 | Observed ρ | Null mean | Monte Carlo p | Retained graphs |
| 07 | 全体 Spearman | 活跃 Spearman | inactive_share | — |

#### （C）实验画布 `.experimentPanel`

##### ① 五层 Tab 切换 `.layerTabs`

```
┌──────────┬────────────┬──────────┬───────────┬───────────┐
│ Coverage │ Association │ Decision │ Semantics │ Robustness│
└──────────┴────────────┴──────────┴───────────┴───────────┘
              ↑ 当前激活               ↑ 禁用（灰显）
```

| Tab | 内部 ID | 显示内容 | 何时可用 |
|-----|---------|---------|---------|
| Coverage | `coverage` | 总体构成条形图（Active vs Common Minimum 三元分解）+ Total/Active/CM 大数字 | 始终 |
| Association | `association` | Full ρ → Active ρ 对比大数字 + common-minimum share 百分比 | 始终（默认） |
| Decision | `decision` | 严格逆转率 + Top-K Jaccard | 始终 |
| Semantics | `semantics` | ΣP₂ / ΣS₂ / ΣM₂ 语义表示总量 | 后端返回时 |
| Robustness | `null` | Monte Carlo 区间 (2.5% / mean / 97.5%) + Observed + p-value | Null evidence 启用时 |

**注意**：Tab 按钮在后端 `availability` 字段控制禁用/启用。不可用时按钮灰显（opacity 28%）且不可点击。

##### ② 主视图 `.primaryVisual`

根据当前 Tab + 模式渲染不同内容：

**Paper 模式 + Association Tab（默认视图）**：
```
  Global vs active association

  ┌─────────────┐    ┌─────────────┐
  │ Full        │ →  │ Active      │
  │   0.9994    │    │   0.7155    │
  │ population  │    │ population  │
  └─────────────┘    └─────────────┘

  Common-minimum share: 92.30%. Population definition is part of the estimand.
```

**Paper 模式 + Coverage Tab**：
```
  Population composition

  ████████████████████████████████░░░░░░░
  ↑ Active (7.70%)                  ↑ CM (92.30%)

  ┌──────────┐ ┌──────────┐ ┌──────────┐
  │ Total    │ │ Active   │ │ Common   │
  │   675    │ │    52    │ │   623    │
  └──────────┘ └──────────┘ └──────────┘
```

**Paper 模式 + Decision Tab**：
```
  Decision-level evidence

  ┌──────────────────┐ ┌──────────────────┐
  │ Strict inversion  │ │ Top-10 Jaccard   │
  │     17.41%        │ │     0.375        │
  └──────────────────┘ └──────────────────┘
```

**Stress 模式**（实验模式 = 公开压力测试时）：
```
  共同最小值压力曲线                          Active rank links
  ┌────────────────────────────┐           ┌──────────────────┐
  │  📈 (LineChart)             │           │  1 ●——————— ● 1   │
  │  x轴: z  y轴: ρ ∈ [-1,1]  │           │  2 ●——————— ● 2   │
  │                            │           │  3 ●——————— ● 3   │
  │  曲线随 z 增大从 -1 升向 1  │           │  4 ●——————— ● 4   │
  │                            │           │  5 ●——————— ● 5   │
  └────────────────────────────┘           └──────────────────┘
  [● Active ordering changed: NO/YES]       ρ_active = ~1.0000

  本实验为公开确定性定理演示：在当前实验参数下实时计算共同最小值压力…
```

- **左半**：Recharts 折线图，x 为 z（共同最小值数量），y 为 global Spearman ρ。数据点来自 `PAD_PRESETS = [0,10,50,100,500,1000]` 的批量查询。
- **右半**：SVG 二部图 `RankLinksView`，展示 5 个活跃实体在两种表示下的 rank 置换连线。完全反向场景（reversed, z≥100）时连线交叉。
- **Invariant 徽章**：绿色标签显示 `Active ordering changed: YES/NO`——这是核心不变量检验。

**Null / Robustness 视图**：
```
  Fixed-margin robustness

  ┌──────────┐ ┌──────────┐ ┌──────────┐
  │ 2.5%     │ │ Null mean│ │ 97.5%    │
  │  -0.xxxx │ │  0.xxxx  │ │  0.xxxx  │
  └──────────┘ └──────────┘ └──────────┘
  ┌──────────┐
  │Observed  │
  │  0.xxxx  │
  └──────────┘

  Approx. two-sided Monte Carlo p = 0.1055
```

##### ③ 右侧辅助面板 `.secondaryVisual`

**默认状态**（未开启 A/B 比较）：
```
  参数变更
  ─────────────────────────────
  先运行一个基线并 Pin A，
  再改变一个条件运行 B。

  Current run    run-xxxxx
  来源           论文结果
```

**A/B 比较状态**（点击「比较 A/B」后展开）：
```
  参数变更
  ─────────────────────────────
  population     full → active        ← 改动的参数列表
  ─────────────────────────────
  可比指标
  ─────────────────────────────
  全体 Spearman   0.9994 → 0.9994  Δ 0.0000
  活跃 Spearman   0.7155 → 0.7155  Δ 0.0000
  严格逆转率      0.1741 → 0.1741  Δ 0.0000

  ⚠ 多个科学条件同时改变：这里只做描述性比较，不解释为单一参数效应。
```

---

### 2.5 ⑤ 右侧结论与证据栏 `.evidenceRail`

自上而下五个区块：

#### （A）来源证明 `.sourcebox`

```
┌──────────────────────────────────────────────┐
│ [● 论文结果]                                  │  ← SourceBadge（颜色区分来源类型）
│                                              │
│ 在完整企业总体中，Degree 与 P2 的 Spearman 相关 │  ← 动态生成的中文结论叙述
│ 为 0.9994；在 APPLIES 活跃企业中降至 0.7155。   │
│ 当前结果提示：总体相关性受到大量共同最小值的显著   │
│ 影响，不能仅依据全体相关系数判断两种表示等价。    │
│                                              │
│ 数据来源：论文中报告的聚合统计结果              │  ← 小字 muted
└──────────────────────────────────────────────┘
```

**SourceBadge 颜色编码**：

| 来源类型 | 显示文本 | 徽章颜色 | 悬浮提示（title） |
|---------|---------|---------|----------------|
| paper_aggregate | 论文结果 | 深蓝底 `#19273a` + 浅蓝字 `#9ecbff` | 来自锁定研究结果的聚合统计，本实验页面不进行记录级重算 |
| live_computed | 现场计算 | 深绿底 `#102f2d` + 青绿字 `#7ce1d1` | 由当前实验参数通过确定性 Python 核心实时计算 |
| public_summary / live_public | 公开数据 | 深紫底 `#261f36` + 淡紫字 `#c5adff` | 论文中中公开数据集的锁定聚合摘要 |

**结论叙述逻辑** (`evidenceNarrative`)：
- **Full + paper_aggregate**：给出全体 ρ + 活跃 ρ + 下降幅度 + "不能仅依据全体相关系数判断等价"
- **Active + paper_aggregate**：聚焦活跃层 ρ + 与全体对比 + "主要由共同最小值块贡献"
- **live_computed (Stress)**：报告当前 z 值 + 活跃排序不变性 + 全体 ρ 变化区间
- **public_summary**：声明来自公开数据集锁定聚合

#### （B）临时结论 `.claimBox`

```
  你的临时结论
  ┌─────────────────────────┐
  │ ○ 可以替代               │
  │ ○ 不可以替代             │
  │ ● 证据不足               │  ← 选中状态（青色高亮）
  └─────────────────────────┘
```

三选一单选按钮组。选择后作为 `user_provisional_claim` 字段传给 Reviewer。

| 选项 | 内部值 | 含义 |
|------|--------|------|
| 可以替代 | `replace` | 认为 degree 与 P2 在当前评估总体下可互换 |
| 不可以替代 | `not_replace` | 认为二者不可互换 |
| 证据不足 | `insufficient`（默认） | 认为当前证据不足以做判断 |

#### （C）当前证据卡片栈 `.evidenceStack`

```
  当前证据
  ┌─────────────────────┐
  │ COVERAGE            │
  │ 92.30% common minima│
  ├─────────────────────┤
  │ ASSOCIATION         │
  │ global ρ = 0.9994   │
  ├─────────────────────┤
  │ DECISION            │
  │ Top-10 J = 0.375    │
  ├─────────────────────┤
  │ ROBUSTNESS          │
  │ p = 0.1055          │
  └─────────────────────┘
```

每张卡片两行：上层为证据层标签（Coverage / Association / Decision / Semantics / Robustness），下层为具体数值。最多显示 4 张，由当前幕的 `emphasis` 决定展示哪些。

#### （D）解释边界 `.boundary`

```
  ┌─────────────────────────────────────────────┐
  │ 解释边界                                    │
  │                                             │
  │ Run the experiment before interpreting the   │  ← 默认文字（未运行时）
  │ claim.                                      │
  │                                             │
  │ ── 或运行后显示后端返回的 boundaries[0] ──   │
  └─────────────────────────────────────────────┘
```

金黄色边框（`#5b4a24` 边框 + `#2a2416` 底色），用于提醒用户"不要过度外推"。内容由后端 `boundaries` 数组动态返回。

#### （E） Reviewer 审查

```
  [提交一句话给 Reviewer 审查]     ← 按钮（无数据或审查中时禁用）

  ┌─────────────────────────────────────────────┐
  │ 允许的表述                                  │
  │ • Global agreement is strongly affected by   │
  │   the stated evaluation population.         │
  │ • The observed active-set Spearman is not    │
  │   extreme under the selected fixed-margin    │
  │   sampled reference ensemble.               │
  │                                             │
  │ 被拒绝的表述                                │
  │ • ρ=0.9994 证明两种表示等价                  │
  │ • p>0.05 证明不存在更高阶机制                │
  │                                             │
  │ 未决问题                                    │
  │ • Representation choice remains task-specific.│
  │                                             │
  │ 当前可用证据为论文报告的聚合统计，不含支持个体 │
  │ 级推断所需的记录级观测；本实验不对此作进一步推断。│
  └─────────────────────────────────────────────┘
```

**触发条件**：必须有运行结果（`data != null`）。点击后向后端 POST `/review/run`，携带当前选择的 claim 对应的问题文本。

**Reviewer 返回三个区块**：
- **允许的表述** (`allowed_claims`)：绿色/中性边框 —— 当前证据支持的谨慎表述
- **被拒绝的表述** (`blocked_claims`)：红色/警告边框 —— 过度推断、被明确反驳的说法
- **未决问题** (`unresolved`)：灰色边框 —— 证据不足以判断的开放问题

底部 muted 小字：证据范围免责声明（第三层帮助说明，不喧宾夺主）。

---

### 2.6 ⑥ 底部实验历史托盘 `.runTray`

三栏布局：`[标题列] [chip 流式区] [快速实验按钮]`

```
┌────────────┬─────────────────────────────────────┬──────────────────┐
│ 实验历史   │  [R01·A] [R02] [R03] [R04] ...     │  快速实验        │
│ 6/20       │                                     │                  │
│ [清空历史] │  R01·A    R02      R03             │ [完全反向压力]    │
│            │  APPLIES  APPLIES  APPLIES          │ [Top-K 5]        │
│            │  q2·full  q2·active q2·active       │ [Top-K 10]       │
│            │  Full Sp=  Active Sp=  ...          │ [Top-K 20]       │
│            │  0.999412 0.715480                 │ [PROVIDES]       │
│            │                                     │ [Null audit]     │
└────────────┴─────────────────────────────────────┴──────────────────┘
```

#### 运行历史 Chip `.runChip`

每个 chip 是一张圆角卡片（148px 固定宽），包含三行：

| 行 | 内容 | 示例 |
|----|------|------|
| 标题行（粗体） | `RXX` 序号 + `·A`（如被 Pin） | `R01·A` |
| 副标题 | 关系 + q + 总体 | `APPLIES q2 · full` |
| 小字头条 | 按 population 显示对应 Spearman | `Full Spearman=0.999412` |

**Chip 状态**：
- **当前选中**：青色边框（`.current`）—— 正在中央区显示的结果
- **已 Pin 为 A**：左侧紫色竖条（`.pinned`）—— 作为 A/B 比较的基线

**chipHeadline 逻辑**（验收手册 §4 要求）：
- `population=active/eligible` → 显示 `Active Spearman=x.xxxxxx`
- 其他 → 显示 `Full Spearman=x.xxxxxx`

**交互**：点击 chip → `restoreRun(r)` → 将该次运行的完整参数回灌到所有控制器 + 中央区切换到该次运行结果。

#### 清空历史

两步确认机制（验收手册 §9 要求）：
1. 点击 `清空历史` → 按钮变为 `确认清空` + `取消`
2. 点击 `确认清空` → 清空 history 数组 + 清除 Pin → 按钮恢复为 `清空历史`

#### 快速实验按钮 `.quickExperiments`

一键快捷操作（省去手动调参）：

| 按钮 | 操作效果 |
|------|---------|
| 完全反向压力 | mode→stress, scenario→reversed, z→500, pop→active |
| Top-K 5 | topK→5 |
| Top-K 10 | topK→10 |
| Top-K 20 | topK→20 |
| PROVIDES | relation→PROVIDES, q→2 |
| Null audit | nullEnabled→true |

点击后标记 `dirty` 但**不会自动运行**——用户需手动点「▶ 运行实验」。

---

## 三、研究案例模式——六幕叙事走读

以下是按照设计稿（Image 1）定义的 **Challenge 01–06 + Final** 完整操作流程。每一步都标注了具体要点的哪个 UI 元素。

> **前置条件**：打开页面后，Case-01 会自动加载并运行（首次加载的 `useEffect` 自动 applyMission + auto-run）。

---

### Challenge 01：你相信 0.999 吗？

**设计意图**：页面先只给 675 和 0.999412，让学生先做判断。"Degree 和 P₂ 是否基本等价？"

**当前幕状态**：
- Ribbon：`01 可疑的 0.999` [激活]
- 研究问题：「可疑的 0.999」/ "675 家公司上的 Spearman ρ=0.999412，足够说明 degree 与 P2 可以互相替代吗？"
- KPI：总体 N = 675 / 全体 Spearman = 0.9994
- 来源：[● 论文结果]

**操作步骤**：

1. **观察 KPI 卡片**：看到 `全体 Spearman = 0.9994` 和 `总体 N = 675`。
2. **看 Association 视图**：Full population 显示 `0.9994`，Active population 尚无数据（因为还是 full 总体）。
3. **在右侧「你的临时结论」里做一个选择**——此时大多数直觉会选"可以替代"。
4. **阅读 Suggested next probe**："先不要改 relation 或 q。打开 Coverage，看看是谁在贡献这个全局统计。"
5. **点击 Coverage Tab** → 看到总体构成条形图：Active 只占 ~7.7%，Common Minimum 占 92.3%。

**教学要点**：0.999 这个数字本身不解释任何东西——关键是谁在贡献它。

---

### Challenge 02：谁在制造 0.999？

**设计意图**：打开 Coverage，623/675 突然显示出来。此时共同最小值滑块解锁，学生亲手把 z 从 623 拉向 0，观察相关下降。

**操作步骤**：

1. **点击 Ribbon `02 共同最小值`**（或左侧 Case 列表的 `02`）→ 参数自动灌入。
2. **注意命令栏出现 `*`** → 自动运行。
3. **观察 KPI 变化**：现在显示 4 张卡——活跃对象=52 / 共同最小值=623 / 占比=92.30% / 活跃 Spearman=0.7155。
4. **Pin 当前结果为 A**：点击命令栏 `Pin A` → R01 chip 出现紫色竖条 `R01·A`。
5. **只改一个条件**：在左侧控制台将 Population 从 `Full` 切到 `Active`。
6. **点 `▶ 运行实验 *`** → 生成 R02。
7. **观察托盘 R02 chip**：应显示 `Active Spearman=0.715480`（验收手册 §4 要求的精确值）。
8. **点击 `比较 A/B`** → 右侧面板展开：
   - 参数变更：`population: full → active`
   - 可比指标：全体 Spearman 不变 / 活跃 Spearman 从 null → 0.7155
9. **回到 Association 视图**：现在能看到 Full → Active 的对比了。

**教学要点**：623 个共同最小值（占 92.30%）才是 0.999 的真正来源。一旦聚焦到 52 家活跃企业，ρ 断崖式下跌到 0.7155。

---

### Challenge 03：事实真的改变了吗？

**设计意图**：左边 global correlation 在变，右边 52 个 active ranking 一根线都没动。这里第一次真正"看见"论文定理。

**操作步骤**：

1. **点击 Ribbon `03 活跃层差异`** → 自动切换到 **stress 模式** + active 总体 + z=0。
2. **运行后观察主视图**：
   - 左侧：**共同最小值压力曲线**（LineChart，z 从 0 到 1000）
   - 右侧：**Active rank links** 二部图（5 个节点 + 连线）
   - 下方 invariant 徽章：`Active ordering changed: NO`
3. **将 z 滑块从 0 拖到 100** → 曲线上升，但 rank links 连线形状不变。
4. **继续拖到 500 / 1000** → global Spearman 从 -1.0000 一路上升到接近 1.0，但 **active ranking 始终不变**。
5. **观察 invariant 徽章**：始终显示 `NO`。

**教学要点**：这就是论文的核心定理——**增加共同最小值可以任意操纵全局相关系数，但活跃层的排序完全不受影响**。全局 ρ 是"假象"，活跃层 ρ 才是"真实信号"。

---

### Challenge 04：如果我要选前 10 家呢？

**设计意图**：切到 decision view。不是再给一个相关系数，而是两份 Top-10 名单摊开，Jaccard = 0.375。学生会自然发现："这已经不是统计数字差一点的问题了。"

**操作步骤**：

1. **点击 Ribbon `04 Top-K`** → 回到 paper 模式 + active 总体。
2. **确保 Top-K = 10**（默认就是 10）。
3. **运行后点击 Decision Tab**：
   - 严格逆转率：`17.41%`
   - Top-10 Jaccard：`0.375`
4. **尝试切换 Top-K 为 5 和 20**：观察 Jaccard 如何变化。
5. **在右侧临时结论更新你的判断**。

**教学要点**：即使忽略 Spearman 的"欺骗性"，从实际决策角度看，两种表示给出的 Top-10 名单重叠度不到 38%。这不是"差一点"的问题，是实质性的决策分歧。

---

### Challenge 05：那高阶网络是不是更厉害？

**设计意图**：故意设置的第二个陷阱。换关系类型、换嵌入阶数，观察"全局高相关 + 活跃层低相关"的现象是否为 APPLIES q=2 的偶然产物。

**操作步骤**：

1. **点击 Ribbon `05 敏感性`** → 自动设为 paper 模式 + Population 切到 `Active` + APPLIES q=2（此时 Association 证据卡显示 **active ρ = 0.715480**，即活跃总体的 Spearman）。
2. **按 Suggested probe 操作——一次只改一个条件**：
   - 先将 Relation 从 `APPLIES` 切到 `PROVIDES` → 运行
   - **关键读数**（Association 卡）：Global ρ = **0.9627** / **active ρ = 0.5987**（即活跃总体 Spearman）/ CM 占比 = **85.48%** / 活跃企业 = **98 家** / Inversion rate = **18.62%**
   - 再切回 `APPLIES`，将 q 从 2 改为 3 → 运行
   - 再改为 4 → 运行
3. **观察每次变化后 Association 和 Decision 层数据的差异**。
4. **在右侧记录你的临时结论**。

> 术语说明：界面左上角 `Population` 分段按钮 `[Full] [Active]` 选的是"在哪个总体上计算"；`Active` 表示只对活跃企业子总体计算。对应算出的 Spearman 在证据卡里标为 **active ρ**；运行历史 chip 头条为便于一眼识别，缩写为 **Active Spearman**（见验收手册 §4）。三者指的是同一个数。

**教学要点**：现象不是 APPLIES q=2 的偶然产物——在保持 Population=Active 的前提下切到 PROVIDES 后，活跃总体 Spearman（active ρ）不仅仍然低（**0.5987**），而且比 APPLIES 的 0.715480 **降得更厉害**；同时 Global ρ 也从 0.9994 降到 0.9627（PROVIDES 本身语义关联就弱于 APPLIES）。这排除了"巧合"解释：无论哪种语义关系、哪个嵌入阶数，活跃层与全局之间的系统性差异始终存在。

---

### Challenge 06：不同，不等于"异常"

**设计意图**：开启 Null，出现第二次反转。再用 Reviewer 审查过度结论。

**操作步骤**：

1. **点击 Ribbon `06 Null`** → 自动勾选 **Null evidence** 复选框。
2. **运行后点击 Robustness Tab**（现在启用了）：
   - 查看 2.5% / Null mean / 97.5% 区间
   - Observed ρ 与区间的关系
   - **Monte Carlo p ≈ 0.1055**
3. **关键解读**：p > 0.05 意味着在保留边际分布的零假设下，观察到这样的活跃层差异并不"异常"。
4. **在右侧选择一个临时结论**（比如之前选了"不可以替代"）。
5. **点击「提交一句话给 Reviewer 审查」**：
   - Reviewer 返回：你说的"不可以替代"太强了 → 降级为"全局一致受评估总体影响"
   - 同时拒绝："p>0.05 证明不存在更高阶机制"这种说法
6. **阅读 Reviewer 的未决问题**："表示选择取决于具体任务。"

**教学要点**：**第二次反转**——活跃层确实不同（第一次反转），但这种不同不一定意味着"异常高阶组织"（第二次反转把过度推断拉回来）。这就是科研语言的精确性。

---

### Final：你现在敢怎么写结论？

**设计意图**：给三句话让学生选。他自己做最终判断，然后 Reviewer 给证据审查。

**三句参考结论**（来自设计稿 Image 1）：

> 1. "两种表示**等价**；"
> 2. "**高阶**表示显著优于 Degree；"
> 3. "全局**高一致**受到**共同最小值影响**，但**活跃层存在差异**，且当前 **null evidence 不支持异常高阶组织**。"

**正确答案显然是第 3 句**——前两句都犯了单一数字过度推断的错误。

**操作步骤**：

1. **回顾全部 6 次运行的 chip**（R01–R06 在托盘中）。
2. **逐个点击回顾**每次的关键数据。
3. **在右侧最终确定你的临时结论**。
4. **最后一次提交 Reviewer**。
5. **导出完整实验记录**（命令栏 `导出`按钮）→ 下载 JSON 文件。

---

### Epilogue（第 7 幕）：跨域迁移

**设计意图**：MovieLens 与 DBLP 解释为什么 population construction 本身就是 estimand 的一部分。

**操作步骤**：

1. **点击 Ribbon `07 Epilogue`** → 数据集自动切换为 `movielens_1997_q4`。
2. **运行后观察**：MovieLens 的 overall/active/Q4 分层下 Spearman 表现。
3. **手动切换数据集为 `dblp`** → 观察 DBLP active-only 的情况。
4. **注意 Suggested probe**："这是 bounded transferability，不是 universal validation。"

---

## 四、自由实验模式

切换到「**自由实验**」后：

| 变化 | 说明 |
|------|------|
| Ribbon 导航 | **隐藏** |
| 左侧 Case 列表 | **隐藏** |
| 中央标题 | 固定为"自由实验" / "改变一个条件，运行，并与基线比较。" |
| Suggested probe | **不显示** |
| 所有参数 | 完全手动控制 |
| 底部托盘 | 变为纯实验历史流（R01/R02/R03…），不再关联幕 ID |

**典型工作流（来自设计稿 Image 3）**：

```
用户进入自由实验
  ↓
默认加载 Case-01 配置 → 运行 → R01 生成
  ↓
Pin R01 为 A
  ↓
只改 Population (Full → Active) → 运行 → R02 生成
  ↓
页面右侧直接回答 "What changed?"
  ↓
这就是"调试实验"的感觉
```

**自由实验适合**：
- 已经走过一遍 Guided Case，想独立验证某个特定组合
- 教学 Demo 中讲师想"现场演示如果改 XX 会怎样"
- 探索后端支持的边界情况（如非 shipbuilding 数据集的不同行为）

---

## 五、完整交互元素索引

| # | UI 元素 | 位置 | 类型 | 触发效果 |
|---|---------|------|------|---------|
| 1 | Ribbon 幕按钮 | ① 顶部导航 | button | `applyMission(mm)` → 灌参数 + auto-run |
| 2 | 模式切换「研究案例/自由实验」 | ② 最左侧 | button pair | `setSessionMode()` → 显隐 Ribbon/Case 列表 |
| 3 | 数据集下拉 | ② | `<select>` | 切 dataset → 联动 relation + q |
| 4 | 关系下拉 | ② | `<select>` | 切 relation → 联动 q |
| 5 | 阶数 q 下拉 | ② | `<select>` | 切 q |
| 6 | ▶ 运行实验 | ② | button | `run()` → POST /experiment/run → 刷新中央区 + 推入托盘 |
| 7 | Pin A | ② | button | `pinCurrent()` → 固定当前结果为基线 |
| 8 | 比较 A/B | ② | button | `setShowCompare(true)` → 展开右侧 diff 面板 |
| 9 | 论文基线 | ② | button | `resetBaseline()` → 回到 Case-01 |
| 10 | 导出 | ② | button | `exportRun()` → 下载 JSON |
| 11 | Representation A/B select | ③ 左侧 | `<select>` disabled | 锁定不可改 |
| 12 | 实验模式 select | ③ 左侧 | `<select>` | paper ↔ stress 切换 |
| 13 | Population Full/Active | ③ 左侧 | seg button pair | `setPopulation()` |
| 14 | Top-K select | ③ 左侧 | `<select>` | 5/10/20 |
| 15 | Scenario select | ③ 左侧（stress） | `<select>` | reversed / micro |
| 16 | z 滑块 | ③ 左侧（stress） | `<input range>` | 0–1000 |
| 17 | Null evidence checkbox | ③ 左侧 | `<input checkbox>` | 启用/禁用 Robustness 层 |
| 18 | Research Case 列表 | ③ 左侧（Guided） | button list | 同 #1 |
| 19 | 五层 Tab 按钮 | ④ 中央 | button group | `setLayer()` → 切换主视图 |
| 20 | 可以替代 / 不可以替代 / 证据不足 | ⑤ 右侧 | button group | `setClaim()` |
| 21 | 提交 Reviewer | ⑤ 右侧 | button | `runReview()` → POST /review/run |
| 22 | 运行历史 chip | ⑥ 底部 | button | `restoreRun(r)` → 回灌参数 + 切换显示 |
| 23 | 清空历史 | ⑥ 底部 | button (两步确认) | 清空 history + 清除 Pin |
| 24 | 快速实验按钮（6 个） | ⑥ 底部 | button | 一键设置常用参数组合 |

---

## 六、数据流与状态管理

```
用户操作（改参数 / 点运行 / 点幕）
        │
        ▼
  ┌─────────────┐
  │ React State │  dataset, relation, q, population, mode, z, ...
  └──────┬──────┘
         │ run() 打包 body
         ▼
  ┌──────────────────────────────────────┐
  │  POST /api/v1/experiment/run          │  ← FastAPI 后端
  │  返回 Run 对象（metrics + population  │
  │  + evidence + boundaries + source）   │
  └──────┬───────────────────────────────┘
         │ setData(result)
         ▼
  ┌──────────────────────────────────────┐
  │  中央实验区重新渲染                    │
  │  · KPI 卡片（从 metrics + population） │
  │  · 主视图（按 layer + mode 分支）      │
  │  · 右侧证据栏（evidenceNarrative 动态） │
  └──────┬───────────────────────────────┘
         │ setHistory(h => [...h, result])
         ▼
  ┌──────────────────────────────────────┐
  │  localStorage (replab.runSnapshots.v2)│  ← 持久化，最多 20 条
  │  底部托盘 chip 流重新渲染             │
  └──────────────────────────────────────┘
```

**关键不变量**：
- `dirty` 标记：参数被修改但尚未运行时为 `true`，运行按钮显示 `*` 后缀
- `pinnedId`：Pin A 的 run_id，A/B 比较的基线
- `ranMissionIds`：Set 类型，记录哪些幕已被运行过（控制 Ribbon 的 done 状态）

---

## 七、常见操作场景速查

### 场景 A：第一次打开页面（冷启动）

```
页面加载 → useEffect 拉取 options + story missions
  → 自动 applyMission(case-01) → dirty=true
  → auto-run → R01 生成 → 中央区显示 Full 总体数据
  → 托盘出现第一个 chip [R01·A 可选 Pin]
```

### 场景 B：完整的 Guided Case 走读（10–15 分钟）

```
依次点击 01→02→03→04→05→06→07
每步：观察 KPI → 看 Tab 视图 → 读 Suggested probe → 选临时结论
关键节点：
  02: Pin A → 切 Active → 生成 R02 → 比较 A/B
  03: 拖 z 滑块 → 看 rank links 不变
  06: 开 Null → 看 p=0.1055 → 提交 Reviewer
最终：导出 JSON
```

### 场景 C：Free Lab 调试

```
切到自由实验 → 手动设参数 → 运行 → Pin → 改一个变量 → 再运行 → 比较 A/B
典型用法："如果我把 PROVIDES q=3 的 Top-K 调到 20 会怎样？"
```

### 场景 D：课堂演示（讲师操作）

```
1. 预先跑完 6 幕（history 有 R01-R06）
2. 从 Case-01 开始，逐幕讲解
3. 每幕点击 chip 回溯，配合 A/B 比较面板
4. Case-06 时现场开启 Null 并提交 Reviewer
5. 最后展示导出的 JSON 作为"实验报告"
```

---

## 八、验收对齐

本手册描述的界面行为与以下文档保持一致：

| 文档 | 关键约束 |
|------|---------|
| `RepLab_UI锁稿与开发设计_v2.2.docx` | 布局规格（Grid 四行/三列）、Ribbon 七幕、五层 Tab |
| `RepLab_v2.2_理想操作说明与开发验收手册.docx` | 50 项 API 断言（Full N=675 ρ=0.999412 / Active 52 ρ=0.71548 / CM=623 92.30% / p=0.1055） |
| 设计稿 Image 1 | 六幕 Challenge 叙事结构 + Final 三句话 |
| 设计稿 Image 2 | 两次反转的认知设计（0.999 不是那么一致 / 活跃层不同也不能说高阶特殊） |
| 设计稿 Image 3 | Guided Case / Free Lab 双模式 + ExperimentConfig→RunSnapshot→EvidenceRecord 主干 |
| 设计稿 Image 4 | 7 步故事收成（Pin A/B 机制 / Coverage 揭示 / stress test / Top-K / sensitivity / Null / Epilogue） |

---

*手册版本：v2.2.1 | 对齐代码版本：story-20260816-v2.1 | 最后更新：2026-08-17*
