#!/usr/bin/env bash
set -e
ROOT="$(cd "$(dirname "$0")" && pwd)"
BACKEND_PORT="${REPLAB_BACKEND_PORT:-8000}"
FRONTEND_PORT="${REPLAB_FRONTEND_PORT:-3000}"
API_BASE="${NEXT_PUBLIC_API_BASE:-http://127.0.0.1:$BACKEND_PORT/api/v1}"
echo "==== RepLab v2.2 Academic 启动 ===="
# ---------- 后端 ----------
echo "[1/4] 准备后端 venv..."
BV="$ROOT/backend/.venv"
if [ ! -d "$BV" ]; then python3 -m venv "$BV"; fi
"$BV/bin/python" -m pip install --quiet --upgrade pip
"$BV/bin/python" -m pip install fastapi "uvicorn[standard]" pydantic
export REPLAB_AGENT_MODE=mock
export CORS_ORIGINS="http://localhost:$FRONTEND_PORT,http://127.0.0.1:$FRONTEND_PORT"
echo "[2/4] 启动后端 (端口 $BACKEND_PORT)..."
nohup "$BV/bin/python" -m uvicorn app.main:app --host 0.0.0.0 --port "$BACKEND_PORT" > "$ROOT/backend.log" 2>&1 &
# ---------- 前端 ----------
echo "[3/4] 安装前端依赖..."
cd "$ROOT/web"
export NEXT_PUBLIC_API_BASE="$API_BASE"
npm install --no-audit --no-fund
echo "[4/4] 启动前端 (端口 $FRONTEND_PORT)..."
nohup npm run dev -- -p "$FRONTEND_PORT" > "$ROOT/frontend.log" 2>&1 &
sleep 6
echo "==== 启动完成 ===="
echo "  前端界面: http://localhost:$FRONTEND_PORT"
echo "  后端文档: http://localhost:$BACKEND_PORT/docs"
echo "  停止服务: 运行 stop.sh"
