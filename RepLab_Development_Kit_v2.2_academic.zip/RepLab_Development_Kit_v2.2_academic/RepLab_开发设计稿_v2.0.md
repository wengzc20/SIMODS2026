# RepLab 开发设计稿 v2.0

**定位：论文配套的交互式网络表示实验台；投稿后扩展为本科生多智能体科研实验室。**

**设计原则：不是论文概览，不是静态数据大屏，不是 Agent 聊天室。首页必须允许用户调参数、运行实验、看到证据变化。**

## 1. 为什么需要 v2.0

上一版把“论文概览”放在首屏，虽然能清楚呈现 675 / 52 / 623 和 0.999412 / 0.715480，但交互性不足，更像论文可视化。新版本把主产品改成 **Experiment Workspace**：用户先配置实验，再运行，中央图形和右侧证据随配置变化。

同时降低界面密度：首屏最多 5 个 KPI、最多 2 个大图，复杂参数折叠，右侧只保留当前最关键的 3–4 条证据。

![RepLab 主实验台参考图](design/replab_workspace_reference_v2.png)

> 参考图只规定布局、交互层次和视觉气质，不要求逐像素复刻。最终实现应比参考图更疏朗。

## 2. 两阶段产品路线

### 2.1 两周投稿配套版

核心目标：论文读者可以直接“动论文里的条件”。

必须具备：

- Shipbuilding / MovieLens / DBLP 案例切换；
- relation / q / population / Top-K 参数；
- 0.999 共同最小值压力实验；
- Coverage / Association / Decision / Null 分层查看；
- Evidence & Review 面板；
- mock Reviewer，最好增加可选 live multi-agent review；
- JSON 导出；
- 数据来源和证据边界明确。

### 2.2 投稿后完整版

在同一个架构上增加：

- Micro Network Playground；
- Theorem Lab；
- 用户上传 affiliation 数据；
- live fixed-margin null sandbox；
- counterexample studio；
- 完整 Research Arena；
- agent benchmark；
- student research notebook。

## 3. 首页 = Experiment Workspace

### 3.1 整体布局

1600×900 参考布局：

```text
┌──────────────────────── Top Command Bar ────────────────────────────────┐
│ RepLab | Dataset | Relation | q | Mode | Run | Auto | Reset | Export   │
├───────────────┬──────────────────────────────────┬──────────────────────┤
│ 实验设置       │ KPI strip                        │ 证据与审查            │
│ 左参数栏       ├──────────────────────────────────┤ 右证据栏              │
│               │ Primary View | Secondary View    │                      │
│               │ 最多两个主图                       │                      │
├───────────────┴──────────────────────────────────┴──────────────────────┤
│ Setup → Coverage → Association → Decision → Null → Review             │
└────────────────────────────────────────────────────────────────────────┘
```

宽度建议：左 290 px，右 310 px，中间弹性。小于 1440 px 时右侧可以变抽屉。

### 3.2 顶部栏

必选：

- Dataset；
- Relation；
- q；
- 实验模式：论文证据 / 0.999 压力测试；
- 运行实验；
- Auto-run；
- Reset；
- Export；
- Help。

默认不显示模型选择器。模型和 Agent provider 放高级设置。

### 3.3 左侧参数栏

标题：**实验设置**。

默认展开：

1. 数据与表示；
2. 总体与排名。

默认折叠：

3. 指标与 Top-K；
4. Null；
5. Agent 审查。

数据与表示：dataset、relation、Representation A、Representation B、q。

总体与排名：full / active；压力测试时增加排序场景与共同最小值 z。

指标：Spearman、Kendall tau-b、Pearson、strict inversion、Top-K Jaccard。

Null：是否显示 null evidence；论文锁定案例中的 chains / retained 只读，不允许伪装成现场重跑。

### 3.4 中央区域

顶部 KPI 最多 5 个：

- Global Spearman；
- Active Spearman；
- Delta rho；
- Strict inversion；
- Top-K Jaccard。

下方不同时堆四五张图，而是通过 View tabs 切换：

- Coverage / Association；
- 共同最小值；
- 活跃排序；
- Null。

一屏最多两个大型图/视图。

### 3.5 右侧 Evidence & Review

顶部是当前限定性结论，例如：

> 全体相关受到共同最小值块显著影响；不能直接推出活跃层、决策层或语义等价。

下方只显示当前最关键的 3–4 条 evidence，例如：

- common-minimum share = 92.30%；
- active Spearman = 0.7155；
- strict inversion = 17.41%；
- null p = 0.1055。

再下方是 tabs：证据 / 审查意见 / 日志。日志默认隐藏。

### 3.6 底部阶段条

Setup → Coverage → Association → Decision → Null → Review。

它不是视频播放条，也不是开发进度。点击阶段会改变中央和右侧的关注内容。

## 4. 实验模式

### 4.1 Paper Evidence

读取 `data/paper_numbers.lock.json` 的稿件安全汇总结果。

支持：

- Shipbuilding APPLIES q2：完整证据；
- PROVIDES / UNION：关系敏感性；
- APPLIES q3/q4：阶数敏感性；
- MovieLens all / 1997 Q4 / 1998 Q1；
- DBLP active-only。

如果某一层没有数据，必须显示 unavailable/disabled，而不是借用另一个 case 的数值。

### 4.2 0.999 Stress Test

交互式 theorem demo，使用 public/synthetic active vectors。

参数：

- micro；
- perfectly reversed；
- z = 0…1000；
- 后续可加 random/custom。

必须同时显示：

```text
active_spearman     固定
active_ordering     不变
global_spearman     随 z 改变
```

严禁声称这条 slider 是 52 家 APPLIES 企业的真实 padding trajectory，因为公开包没有这些活跃向量。

## 5. 数据诚实原则

稿件最终锁定值全部来自：

`data/paper_numbers.lock.json`

前端不得手写这些论文数字。

不能公开/不能构造：

- APPLIES 企业行级记录；
- 企业名和真实实体排行；
- 企业特定 schema；
- 没有保存的 randomized edge realizations；
- 由 null summary 人工合成的“看起来像真实”的直方图。

如果只有 null quantiles，就画：2.5% — mean/median — 97.5% + observed marker，而不是伪造完整分布。

## 6. 技术栈

### 6.1 Frontend

- Next.js 16 App Router；
- React 19.2；
- TypeScript strict；
- Tailwind CSS v4；
- Recharts；
- native SVG rank-link。

### 6.2 Backend

- Python 3.12+；
- FastAPI；
- Pydantic v2；
- pytest；
- 数学 core 与 HTTP/Agent 严格分离。

### 6.3 Agent

- OpenAI Agents SDK 可选；
- 两周版优先 code-orchestrated specialist agents；
- live 模式不是论文 demo 的依赖；
- Agent 只能解释 EvidenceRecord，不得“凭语言模型重新计算论文统计量”。

## 7. 代码结构

```text
RepLab_Development_Kit_v2.0/
├── PRODUCT_SPEC.md
├── UI_INTERACTION_SPEC.md
├── TECH_ARCHITECTURE.md
├── API_CONTRACT.md
├── DATA_GUIDE.md
├── AGENT_DESIGN.md
├── TASKS_2W.md
├── TEST_PLAN.md
├── design/
├── data/
├── backend/
│   └── app/
│       ├── core/
│       ├── services/
│       └── agents/
└── web/
    ├── app/
    └── components/
```

`backend/app/core` 不能 import OpenAI SDK、FastAPI、数据库 session。

## 8. 关键前端状态

```ts
export type ExperimentConfig = {
  datasetId: string;
  relation: string;
  q: number;
  representationA: string;
  representationB: string;
  population: "full" | "active" | "eligible";
  mode: "paper" | "stress";
  stressScenario?: "micro" | "reversed";
  z?: number;
  topK: number;
  metrics: string[];
  nullEnabled: boolean;
  reviewerEnabled: boolean;
};
```

UI 使用 `draftConfig` 和 `lastRunConfig` 分离。用户修改参数以后出现轻量 dirty state；只有点击“运行实验”才更新正式 evidence，除非用户开启 Auto-run。

## 9. 核心 API

### GET `/api/v1/workbench/options`

返回所有支持的 dataset / relation / q / representation / metric 组合。

### POST `/api/v1/experiment/run`

示例请求：

```json
{
  "dataset_id": "shipbuilding",
  "relation": "APPLIES",
  "q": 2,
  "representation_a": "k",
  "representation_b": "P2",
  "population": "full",
  "mode": "paper",
  "top_k": 10,
  "metrics": ["spearman", "strict_inversion", "topk_jaccard"],
  "null_enabled": true,
  "reviewer_enabled": false
}
```

核心响应：

```json
{
  "run_id": "...",
  "availability": {
    "coverage": true,
    "association": true,
    "decision": true,
    "null": true
  },
  "metrics": {
    "global_spearman": 0.999412,
    "active_spearman": 0.71548,
    "gap": 0.283932,
    "strict_inversion_rate": 0.1741,
    "topk_jaccard": 0.375,
    "null_p": 0.1055
  },
  "evidence": [],
  "boundaries": []
}
```

### POST `/api/v1/lab/padding`

只用于公开/合成 stress vectors。

## 10. 多智能体具体设计

两周版建议 4+1：

- Coverage Agent；
- Statistics Agent；
- Decision Agent；
- Reviewer Agent；
- Orchestrator。

Null Agent 可以作为第 5 个 specialist，如果 live Agent 部分进度足够。

推荐顺序：

```python
coverage = run_coverage_agent(evidence)
stats = run_statistics_agent(evidence)
decision = run_decision_agent(evidence)
review = run_reviewer(evidence, [coverage, stats, decision])
```

每个 Agent 返回结构化输出：

```json
{
  "agent": "StatisticsAgent",
  "summary": "...",
  "evidence_ids": ["assoc-001"],
  "supported_claims": [],
  "blocked_claims": [],
  "unresolved": []
}
```

Reviewer 必须拒绝：

- “rho=0.9994 所以两个表示等价”；
- “recorded zero 就是真实不存在”；
- “p=0.1055 所以没有高阶机制”。

这套 Agent 训练能覆盖：tool calling、code orchestration、specialist agents、structured output、evidence provenance、reviewer/evaluator、tracing、human-in-the-loop。

## 11. 两周实现优先级

P0：

1. Experiment Workspace shell；
2. options/run API；
3. parameter state；
4. Stress Test；
5. locked paper cases；
6. Evidence rail；
7. mock Reviewer；
8. JSON export；
9. scientific regression tests。

P1：

- live Agents；
- better rank-link；
- richer chart interactions；
- local run history。

两周明确不做：

- 用户上传；
- 真正重跑 4000 retained null graphs；
- 完整 network editor；
- MCP/A2A；
- 登录；
- 云数据库。

## 12. 验收标准

科学回归必须精确通过：

- 675 / 52 / 623；
- 0.999412 / 0.715480；
- 17.41%；
- Top-10 0.375；
- null p=0.1055；
- MovieLens / DBLP 锁定值。

UI：

- 首页能调参数；
- 首屏最多 2 个大图；
- advanced controls 折叠；
- 没有“两周冲刺计划”；
- 没有 token/Agent 数量等装饰指标；
- unsupported evidence 不串 case；
- 不伪造 shipbuilding entity-level plots。

代码：

```bash
python scripts/validate_data.py
python -m pytest backend/tests -q
cd web && npm run lint && npm run build
```

## 13. 包中已经完成的骨架

v2.0 开发包已经包含：

- 最新界面参考图；
- 参数型首页 React skeleton；
- `/workbench/options`；
- `/experiment/run`；
- 原有 deterministic core；
- paper number lock；
- stress-test data；
- mock/live review 骨架；
- API 和 scientific regression tests。

当前容器已验证数据 validator 与 Python backend tests。前端依赖安装需在正常 npm 网络环境下再执行 lint/build。
