# RepLab Agent Design v2.1

## Two-week objective
The two-week product should not look like an “agent show.”

P0 agent role:
- **Scientific Reviewer** only.

Optional P1:
- Coverage Analyst
- Statistics Analyst

The main story is driven by the user’s experiments and deterministic evidence.

## Reviewer contract
Input:
- user claim
- current RunSnapshot
- pinned A/B diff if available
- EvidenceRecords
- interpretation boundaries

Output:
- status: Supported / Qualified / Unsupported / Not evaluated
- evidence_ids
- concise reason
- blocked overclaim(s)
- unresolved question(s)

Reviewer must block at least:
- global correlation alone proves representation redundancy;
- recorded zero means true structural absence;
- p>0.05 proves no higher-order mechanism exists;
- APPLIES null audit tests the common-minimum mechanism;
- external cases prove universal prevalence;
- larger q is intrinsically better.

## Future continuity
The full Research Arena can later add specialist agents without changing the evidence model.

Preferred pattern:
- deterministic Orchestrator controls scientific steps;
- specialists inspect assigned evidence scopes;
- Reviewer runs after specialists;
- user makes final scientific judgment.

A2A is deferred until agents are genuinely independent services. MCP is deferred until external tool/data providers justify the protocol boundary.
