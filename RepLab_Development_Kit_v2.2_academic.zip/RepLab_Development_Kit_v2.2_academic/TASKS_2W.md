# RepLab v2.1 Two-Week Build Plan

Internal development planning only. Never show this in the user product.

## P0 scientific experience

### P0-01 Story/workbench shell
- home opens Guided Research Case;
- mode toggle Guided / Free;
- top command bar + left controls + center canvas + right claim/evidence + bottom run tray;
- no static paper-overview homepage.

### P0-02 Manuscript story metadata
- load `data/story_missions.json`;
- implement current mission title/question/suggested probe;
- progressive emphasis only; never falsify data availability.

### P0-03 RunSnapshot + local run tray
- every successful run creates RunSnapshot;
- persist up to 20 in localStorage;
- restore config;
- pin/unpin A.

### P0-04 Pin A / Compare B
- parameter diff;
- metric diff;
- warning for multiple scientific dimensions changed;
- no invalid causal wording.

### P0-05 APPLIES population case
- R01 full vs R02 active;
- 675 / 52 / 623;
- 0.999412 / 0.715480;
- common-minimum 92.30%;
- evidence boundaries.

### P0-06 Public 0.999 theorem stress test
- reversed + micro scenarios;
- z slider;
- Spearman recomputation;
- active ordering invariant status;
- public/synthetic label.

### P0-07 Decision case
- K 5/10/20;
- manuscript-locked Jaccard;
- inversion rate;
- explicit “descriptive; no frozen decision-level null distribution” note.

### P0-08 Sensitivity case
- relation APPLIES/PROVIDES/UNION;
- APPLIES q2/q3/q4;
- disable unsupported layers rather than reusing APPLIES q2 evidence.

### P0-09 Null challenge
- APPLIES q2 only;
- actual quantile band + observed marker;
- 4 chains / 4000 retained / p=.1055 / ESS / Rhat metadata;
- no fake histogram if retained values are absent from the dev pack.

### P0-10 External epilogue
- MovieLens all/Q4/Q1 contrast;
- DBLP active-only contrast;
- transferability boundary.

### P0-11 Claim + mock Reviewer
- store initial claim;
- review custom final claim against evidence IDs;
- blocked-claim regression tests.

### P0-12 Export
- export config, A/B snapshots, diff, evidence IDs, claim, review.

## Recommended 14-day sequence
Day 1: shell + visual tokens + Guided/Free mode.  
Day 2: story metadata + question banner + scientific layer tabs.  
Day 3: RunSnapshot + localStorage run tray.  
Day 4: Pin A / Compare B + parameter diff.  
Day 5: APPLIES full/active story.  
Day 6: stress-test curve and invariant view.  
Day 7: decision K controls.  
Day 8: relation and q sensitivity.  
Day 9: semantics evidence + availability rules.  
Day 10: frozen null summary and reviewer boundary.  
Day 11: MovieLens/DBLP epilogue.  
Day 12: mock reviewer + claim workflow.  
Day 13: export + scientific regression.  
Day 14: demo rehearsal, responsive cleanup, freeze.

## Explicit non-goals
- raw APPLIES entity graph
- recomputing frozen 4000-graph audit
- user upload
- full network editor
- theorem proof editor
- full multi-agent arena
- database/auth
- MCP/A2A implementation
- elaborate report generator

These remain compatible future extensions, not dependencies of the submission companion.
