# RepLab API Contract v2.1

Base: `/api/v1`

## GET /health
Returns backend status, paper lock version, and live-agent availability.

## GET /workbench/options
Returns supported datasets, relation/q availability, representations, metrics, Top-K locks, and stress scenarios.

Important shipbuilding relation/q matrix:
```json
{
  "APPLIES": [2,3,4],
  "PROVIDES": [2],
  "UNION": [2]
}
```
The frontend must not offer unsupported q values for a selected relation.

## GET /story/missions
Returns declarative guided-case metadata from `data/story_missions.json`.

The story layer is presentation metadata only. It does not contain hidden numerical results used for computation.

## POST /experiment/run

Request example:
```json
{
  "session_mode": "guided",
  "story_mission_id": "case-02",
  "dataset_id": "shipbuilding",
  "relation": "APPLIES",
  "q": 2,
  "representation_a": "k",
  "representation_b": "P2",
  "population": "active",
  "mode": "paper",
  "top_k": 10,
  "null_enabled": false,
  "reviewer_enabled": false
}
```

Response example shape:
```json
{
  "run_id": "run-a1b2c3d4e5",
  "created_at": "2026-08-16T10:20:30+00:00",
  "source_kind": "paper_aggregate",
  "story": {
    "id": "case-02",
    "title": "623 个共同最小值",
    "question": "...",
    "suggested_probe": "...",
    "layer_tags": ["coverage","association"]
  },
  "config": {},
  "availability": {
    "coverage": true,
    "association": true,
    "decision": true,
    "semantics": true,
    "null": false
  },
  "population": {},
  "metrics": {},
  "evidence": [],
  "boundaries": [],
  "source_version": "paper-20260813-final-draft"
}
```

### Scientific availability rules
- PROVIDES and UNION locked paper evidence: q=2 only.
- APPLIES q=3/q=4: active order sensitivity only; do not leak APPLIES q=2 null evidence.
- APPLIES q=2 null evidence: frozen active-set Spearman audit only.
- MovieLens: no APPLIES null evidence.
- DBLP: active-only population; no natural coverage replication.

## POST /lab/padding

Request:
```json
{"mode":"reversed","z":500}
```

Response contains active/global Spearman and invariant status.

This endpoint uses public/synthetic active vectors. It is not an APPLIES reconstruction.

## POST /review/run
Mock reviewer is P0. Live reviewer is optional.
Reviewer may only interpret EvidenceRecords and boundaries. It may not invent or overwrite statistics.

## Client-side RunSnapshot
Pin/Compare/history is P0 and is intentionally client-side for the two-week build. See `RUN_COMPARE_SPEC.md`.
