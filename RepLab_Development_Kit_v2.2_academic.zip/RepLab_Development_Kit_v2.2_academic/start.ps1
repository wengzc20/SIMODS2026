﻿# RepLab v2.2 Academic 一键启动（Windows PowerShell）
$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path

$BackendPort  = if ($env:REPLAB_BACKEND_PORT)  { $env:REPLAB_BACKEND_PORT }  else { "8000" }
$FrontendPort = if ($env:REPLAB_FRONTEND_PORT) { $env:REPLAB_FRONTEND_PORT } else { "3000" }
$ApiBase = if ($env:NEXT_PUBLIC_API_BASE) { $env:NEXT_PUBLIC_API_BASE } else { "http://127.0.0.1:$BackendPort/api/v1" }

Write-Host "==== RepLab v2.2 Academic 启动 ====" -ForegroundColor Cyan

# ---------- 后端 ----------
Write-Host "[1/4] 准备后端 Python 虚拟环境..." -ForegroundColor Yellow
$BV = Join-Path $Root "backend\.venv"
if (-not (Test-Path $BV)) { python -m venv $BV }
& "$BV\Scripts\python.exe" -m pip install --quiet --upgrade pip
& "$BV\Scripts\python.exe" -m pip install fastapi "uvicorn[standard]" pydantic

$env:REPLAB_AGENT_MODE = "mock"   # 默认 mock 审查器，无需 OpenAI Key
$env:CORS_ORIGINS = "http://localhost:$FrontendPort,http://127.0.0.1:$FrontendPort"
Write-Host "[2/4] 启动后端 (端口 $BackendPort)..." -ForegroundColor Yellow
Start-Process -NoNewWindow -FilePath "$BV\Scripts\python.exe" `
  -ArgumentList "-m","uvicorn","app.main:app","--host","0.0.0.0","--port",$BackendPort `
  -WorkingDirectory (Join-Path $Root "backend") `
  -RedirectStandardOutput (Join-Path $Root "backend.log") `
  -RedirectStandardError  (Join-Path $Root "backend.err")

# ---------- 前端 ----------
Write-Host "[3/4] 安装前端依赖 (npm install)..." -ForegroundColor Yellow
Set-Location (Join-Path $Root "web")
$env:NEXT_PUBLIC_API_BASE = $ApiBase
& npm install --no-audit --no-fund

Write-Host "[4/4] 启动前端 (端口 $FrontendPort)..." -ForegroundColor Yellow
# npm 在 Windows 上是 npm.cmd 批处理垫片，Start-Process 无法直接执行，须经 cmd.exe /c
Start-Process -NoNewWindow -FilePath "cmd.exe" `
  -ArgumentList "/c","npm run dev -- -p $FrontendPort" `
  -WorkingDirectory (Join-Path $Root "web") `
  -RedirectStandardOutput (Join-Path $Root "frontend.log") `
  -RedirectStandardError  (Join-Path $Root "frontend.err")

Start-Sleep -Seconds 6
Write-Host ""
Write-Host "==== 启动完成 ====" -ForegroundColor Green
Write-Host "  前端界面:  http://localhost:$FrontendPort"
Write-Host "  后端文档:  http://localhost:$BackendPort/docs"
Write-Host "  停止服务:  运行 stop.ps1"
Write-Host ""
Write-Host "如要从其他电脑访问本机，请见《部署说明.md》设置 CORS_ORIGINS 与 NEXT_PUBLIC_API_BASE。"
