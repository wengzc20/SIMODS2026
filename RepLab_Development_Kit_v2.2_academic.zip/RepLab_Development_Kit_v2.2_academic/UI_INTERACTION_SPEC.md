# RepLab UI & Interaction Specification v2.1

## 1. Desktop target
Reference: 1600×900. Minimum P0 desktop width: 1280.

### Grid
- top bar: 64 px
- main body: remaining height minus run tray
- left rail: 268–288 px
- right rail: 290–314 px
- center: flexible
- run tray: 92–104 px
- gaps: 14–16 px

At 1280–1439 px, right rail becomes a drawer. Do not cram all three columns.

## 2. Visual language
Dark scientific lab, lower density than the prior dashboard.

Suggested tokens:
- canvas `#07131C`
- panel `#0B1C27`
- panel-2 `#102634`
- border `#183B4A`
- cyan for active experiment controls
- blue for statistical evidence
- violet for representation semantics
- amber for evidence boundaries
- red only for reviewer rejection/contradiction
- green for verified invariant/check

Avoid cyberpunk glow. Use whitespace and hierarchy.

## 3. Top command bar
Left to right:

- RepLab
- mode switch: `研究案例 | 自由实验`
- Dataset
- Relation
- q
- `运行实验`
- `Pin A`
- `比较`
- `恢复论文基线`
- `导出`

In Guided Case, dataset/relation/q remain visible but may be constrained by the current case. The user can switch to Free Lab at any time.

## 4. Research question banner
Top of center canvas.

Example:
> **Research Case 02 · 623 个共同最小值**  
> 只把总体从 full 改成 active，会发生什么？

Right side:
- `Suggested next probe`
- one concise instruction

The banner is not a tutorial modal. It should feel like a lab notebook task card.

## 5. Left Lab Controls
Title: `Lab Controls` / `实验控制`.

### Group A — 对象与表示
- dataset
- relation
- representation A
- representation B
- q

### Group B — 实验变量
- population
- Top-K
- stress scenario when applicable
- z slider when applicable
- null toggle when applicable

### Group C — Advanced (collapsed)
- metric selector
- auto-run for deterministic stress mode
- reviewer mode
- provenance details

At most 6 controls visible at once.

## 6. Center Experiment Canvas

### 6.1 KPI strip
Maximum 4 at once.
Priority changes with research case.

Case 1:
- global Spearman
- N

Case 2:
- global Spearman
- active Spearman
- common-minimum share
- Δρ

Case 4:
- active Spearman
- inversion rate
- Top-K Jaccard

Case 6:
- observed active Spearman
- null mean
- p-value
- retained graphs

### 6.2 Scientific layer tabs
`Coverage | Association | Decision | Semantics | Robustness`

The five tabs correspond directly to the manuscript framework.
Disabled layers show a tooltip explaining data availability.

### 6.3 Primary visualization
Only one dominant chart.

Supported P0 visual forms:
- population composition bar
- global vs active slope/dumbbell
- padding curve
- Top-K Jaccard bars
- relation/q sensitivity line or grouped dots
- null quantile band + observed marker
- external population contrast

Do not fabricate APPLIES row-level scatter/rank links.

### 6.4 Secondary panel
Contextual only:
- parameter diff
- invariant status
- semantic totals
- null diagnostics
- current config

### 6.5 What changed?
Appears when A is pinned and B is current.

Example:
```
Changed parameter
Population    full → active

Comparable evidence
Spearman      0.9994 → 0.7155
Δ             -0.2839

Unchanged
Relation      APPLIES
q             2
```

If multiple scientific dimensions changed, display a warning.

## 7. Right Claim & Evidence rail

### 7.1 Your Claim
At the beginning of the story:
`可以替代 | 不可以替代 | 证据不足`

Allow one-sentence custom claim.

Keep the initial claim visible so the user can see whether later evidence changes their judgment.

### 7.2 Evidence cards
Each card shows:
- layer tag
- result
- population
- source kind
- evidence ID

### 7.3 Interpretation Boundary
One concise amber card.

Examples:
- `Recorded zero under APPLIES is not verified structural absence.`
- `p>0.05 does not prove absence of higher-order mechanisms.`

### 7.4 Reviewer
Button: `请 Reviewer 审查这句话`

Reviewer output:
- Supported / Qualified / Unsupported / Not evaluated
- evidence IDs
- one short reason
- blocked overclaim if applicable

## 8. Bottom Run Tray

Do not use a fixed Stage 1–6 bar.

Instead show:
`R01 APPLIES q2 full ρ=.9994`  
`R02 APPLIES q2 active ρ=.7155`  
`R03 reversed z=500 ρ=.9998`

Pinned A gets a small `A` badge. Current run gets cyan border.

Click a run:
- restore config
- inspect snapshot
- pin/unpin
- export

The run tray is the strongest visual cue that the user is *doing experiments*.

## 9. Guided story navigation
A compact case navigator may sit above the run tray or in the question banner:

`01 0.999 → 02 Coverage → 03 Counterfactual → 04 Decision → 05 Sensitivity → 06 Null → Epilogue`

It should be subtle. It is not the main interaction; Run/Compare is.

## 10. Key interaction examples

### Example A — Population debugging
1. Start R01 full/APPLIES/q2.
2. Pin A.
3. Change only Population → Active.
4. Workspace becomes dirty.
5. Run R02.
6. `What changed?` highlights one controlled change and the Spearman difference.

### Example B — Theorem stress test
1. Choose public reversed scenario.
2. Set z=0 and run.
3. Pin A.
4. Drag z to 500; Auto-run may be enabled.
5. Global Spearman approaches 1 while Active ordering changed remains NO.

### Example C — Null challenge
1. Return to APPLIES q2 active.
2. Enable Null evidence.
3. Run.
4. Show actual frozen null summary.
5. Reviewer blocks “no higher-order mechanism exists.”

## 11. Accessibility
- keyboard accessible controls
- support/attack status uses text + icon, not color alone
- every chart has text summary
- tabular numerals
- focus state visible
- sliders have numeric input alternative


## v2.2 source-aware override
See `UI_FINAL_LOCK_v2.2.md`. The visual reference is now locked in two states: Paper Evidence and Live Stress. Source badge/provenance is mandatory. Any previous mockup containing a shipbuilding entity scatter or named company ranking is non-authoritative.
