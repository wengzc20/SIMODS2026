# Compatibility note
Use `TASKS_2W.md` for the current paper-companion implementation plan.
