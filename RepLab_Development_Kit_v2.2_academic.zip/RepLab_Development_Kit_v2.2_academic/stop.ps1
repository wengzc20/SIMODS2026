# RepLab v2.2 Academic 停止（Windows PowerShell）
$ErrorActionPreference = "SilentlyContinue"
$BackendPort  = if ($env:REPLAB_BACKEND_PORT)  { $env:REPLAB_BACKEND_PORT }  else { "8000" }
$FrontendPort = if ($env:REPLAB_FRONTEND_PORT) { $env:REPLAB_FRONTEND_PORT } else { "3000" }
function Kill-Port($port){
  $conn = Get-NetTCPConnection -LocalPort $port -ErrorAction SilentlyContinue
  if($conn){ $conn | ForEach-Object { Stop-Process -Id $_.OwningProcess -Force }; Write-Host "已停止端口 $port" }
  else { Write-Host "端口 $port 无进程" }
}
Kill-Port $BackendPort
Kill-Port $FrontendPort
